/******     STRONGLY CONNECTED COMPONENTS OF A GRAPH      ******/
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define NS 8

void explore(int s);void exploret(int s);
void drawing(void); void drawingt(void);
void pause(void);
void putpixel(int xe, int ye, Uint32 c);
Uint32 getpixel(int xe, int ye);
void circle( int xo, int yo, int R, Uint32 c);
void filldisc(int xo, int yo, int R,Uint32 c);
void line(int x0,int y0, int x1,int y1, Uint32 c);
void arrow(int x1, int y1, int x2, int y2, Uint32 c);
void linewithwidth(int x1, int y1, int x2, int y2, int epaisseur,Uint32 c);
int x[NS],y[NS],xorig,yorig,pas,v[NS][NS],nbv[NS],fin[NS],compteurf,d[NS];
int vv[NS][NS],nbvv[NS],sommet[NS],icolor;
SDL_Surface * screen; Uint32 white,coulor[NS],color[6];
SDL_Surface *texte;  SDL_Rect position;TTF_Font *police=NULL;char chiffre[2000];
SDL_Color cblack={0,0,0};

int main(int argc, char ** argv)
{  int i,j;
   SDL_Init(SDL_INIT_VIDEO);
   screen=SDL_SetVideoMode(800,600,32, SDL_HWSURFACE|SDL_DOUBLEBUF);
   white=SDL_MapRGB(screen->format,255,255,255);
   color[0]=SDL_MapRGB(screen->format,0,0,0);
   color[1]=SDL_MapRGB(screen->format,255,0,0);
   color[2]=SDL_MapRGB(screen->format,0,250,0);
   color[3]=SDL_MapRGB(screen->format,0,0,250);
   color[4]=SDL_MapRGB(screen->format,255,255,0);
   color[5]=SDL_MapRGB(screen->format,200,200,200);
   SDL_FillRect(screen,0,white);
   TTF_Init();  police=TTF_OpenFont("times.ttf",25);

xorig=50;yorig=50; pas=150;
for(i=0;i<NS;i++) {x[i]=xorig+pas*(i%4); y[i]=yorig+pas*(i/4);}
v[0][0]=4; nbv[0]=1;
v[1][0]=0; nbv[1]=1;
v[2][0]=1;v[2][1]=3; nbv[2]=2;
v[3][0]=6;nbv[3]=1;
v[4][0]=1;nbv[4]=1;
v[5][0]=1;v[5][1]=2;v[5][2]=4;v[5][3]=6; nbv[5]=4;
v[6][0]=2;v[6][1]=5;nbv[6]=2;
v[7][0]=3;v[7][1]=6; nbv[7]=2;
for(i=0;i<NS;i++) for(j=0;j<nbv[i];j++)  vv[v[i][j]][nbvv[v[i][j]]++]=i;
drawing();SDL_Flip(screen); pause();

for(i=0;i<NS;i++) if (d[i]==0)  explore(i);
for(i=0;i<NS;i++)
{ sprintf( chiffre," (%d %d)",i,fin[i]);  texte=TTF_RenderText_Solid(police,chiffre,cblack);
       position.x=30+60*i; position.y=400;
       SDL_BlitSurface(texte,NULL,screen,&position);
}

for (i=0;i<NS;i++) {sommet[NS-1-fin[i]]=i;}
for (i=0;i<NS;i++)
{ sprintf( chiffre,"%d",sommet[i]);  texte=TTF_RenderText_Solid(police,chiffre,cblack);
       position.x=30+60*i; position.y=450;
       SDL_BlitSurface(texte,NULL,screen,&position);
}
SDL_Flip(screen); pause();SDL_FillRect(screen,0,white);

drawingt();SDL_Flip(screen); pause();

icolor=1;
for (i=0;i<NS;i++) {d[i]=0; sommet[NS-1-fin[i]]=i;}
for(i=0;i<NS;i++) if (d[sommet[i]]==0)
{exploret(sommet[i]);icolor++; }

SDL_Flip(screen); pause();SDL_FillRect(screen,0,white);

drawing();SDL_Flip(screen); pause();

for(i=0;i<NS;i++) { filldisc(x[i],y[i],10,coulor[i]);
                   }

SDL_Flip(screen); pause();  TTF_CloseFont(police); TTF_Quit();  return 0;
}

void explore(int s)
{int i,neighbor;
d[s]=1; filldisc(x[s],y[s],5,color[1]);
for(i=0;i<nbv[s];i++)
  { neighbor=v[s][i];
    if (d[neighbor]==0)
      { linewithwidth(x[s],y[s],x[neighbor],y[neighbor],2,color[1]);  explore(neighbor);  }
  }
fin[s]=compteurf++;
}

void exploret(int s)
{ int i,neighbor;
d[s]=1; coulor[s]=color[icolor];filldisc(x[s],y[s],6,color[icolor]);
for(i=0;i<nbvv[s];i++)
  { neighbor=vv[s][i];   if (d[neighbor]==0)
      {  linewithwidth(x[s],y[s],x[neighbor],y[neighbor],2,color[icolor]);
          exploret(neighbor);
      }
  }
}

void drawing(void)
{  int i,j;
  for(i=0;i<NS;i++)
    { filldisc(x[i],y[i],4,color[0]);
       sprintf( chiffre," %d",i);  texte=TTF_RenderText_Solid(police,chiffre,cblack);
       position.x=x[i]-25; position.y=y[i]-35;
       SDL_BlitSurface(texte,NULL,screen,&position);
    }
  for(i=0;i<NS;i++) for(j=0;j<nbv[i];j++)   arrow(x[i], y[i], x[v[i][j]] , y[v[i][j]], color[0]);
}

void drawingt(void)
{  int i,j;
   for(i=0;i<NS;i++)   filldisc(x[i],y[i],2,color[0]);
  for(i=0;i<NS;i++) for(j=0;j<nbvv[i];j++)
    arrow(x[i], y[i], x[vv[i][j]] , y[vv[i][j]], color[0]);
 }

void pause(void)
{
    SDL_Event evenement;
    do   SDL_WaitEvent(&evenement);
    while(evenement.type != SDL_QUIT && evenement.type != SDL_KEYDOWN);
}

void putpixel(int xe, int ye, Uint32 c)
{ Uint32 * numerocase;
numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;    *numerocase=c;
}

Uint32 getpixel(int xe, int ye)
{ Uint32 * numerocase;
   numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;   return (*numerocase);
}

void arrow(int x1, int y1, int x2, int y2, Uint32 c)
{
int dx,dy;
float xf1,yf1,xf2,yf2,d,dx1,dy1,ndx1,ndy1,ndx2,ndy2,angle=M_PI/6.;
line(x1,y1,x2,y2,c);
dx=x2-x1; dy=y2-y1;       d=sqrt(dx*dx+dy*dy);
if (d!=0.)      /* si le vecteur n’est pas nul */
{ dx1=10.*(float)dx/d; dy1=10.*(float)dy/d;
   ndx1=dx1*cos(angle)-dy1*sin(angle);
   ndy1=dx1*sin(angle)+dy1*cos(angle);
   xf1=0.3*x1+0.7*x2; yf1=0.3*y1+0.7*y2;     xf2=xf1-ndx1; yf2=yf1-ndy1;
   line(xf1,yf1,xf2,yf2,c);
   ndx2=dx1*cos(-angle)-dy1*sin(-angle);
   ndy2=dx1*sin(-angle)+dy1*cos(-angle);
   xf2=xf1-ndx2; yf2=yf1-ndy2;    line(xf1,yf1,xf2,yf2,c);
}
else    /* if null vector, circle from point to itself */
     {circle(x1+10,y1,10,c); line(x1+20,y1,x1+23,y1-6,c);
      line(x1+20,y1,x1+15,y1-5,c);
     }
}

void linewithwidth(int x1, int y1, int x2, int y2, int epaisseur,Uint32 c)
{
int dx,dy;
float k,xf1,yf1,xf2,yf2,d,dx1,dy1,ndx1,ndy1,ndx2,ndy2,angle=M_PI/2.;
line(x1,y1,x2,y2,c);
dx=x2-x1; dy=y2-y1;       d=sqrt(dx*dx+dy*dy);
if (d!=0.)      /* si le vecteur n’est pas nul */
{ dx1=(float)epaisseur*(float)dx/d; dy1=(float)epaisseur*(float)dy/d;
   ndx1=dx1*cos(angle)-dy1*sin(angle);
   ndy1=dx1*sin(angle)+dy1*cos(angle);
   ndx2=dx1*cos(-angle)-dy1*sin(-angle);
   ndy2=dx1*sin(-angle)+dy1*cos(-angle);
   for(k=0;k<=1.;k+=0.1/d)
   {
   xf1=(1.-k)*x1+k*x2; yf1=(1.-k)*y1+k*y2;
   xf2=xf1-ndx1; yf2=yf1-ndy1;  line(xf1,yf1,xf2,yf2,c);
   xf2=xf1-ndx2; yf2=yf1-ndy2;    line(xf1,yf1,xf2,yf2,c);
   }
}
}

void circle( int xo, int yo, int R, Uint32 c)
  {
      int x, y, F, F1, F2,newx,newy;
      x=xo; y=yo+R; F=0;
      if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,c);
      if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, c);
      while( y>yo)
         {
             F1=F+2*(x-xo)+1; F2=F-2*(y-yo)+1;
             if ( abs(F1)<abs(F2))  { x+=1; F=F1;}
             else {y-=1; F=F2;}
             if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,c);
              newx=2*xo-x ; newy=2*yo-y ;
             if (x<800 && x>=0 && newy>=0 && newy<600) putpixel(x, newy,c);
             if (newx<800 && newx>=0 && y>=0 && y<600) putpixel( newx,y,c);
             if (newx<800 && newx>=0 && newy>=0 && newy<600) putpixel(newx,
             newy, c);
         }
       if (xo+R<800 && xo+R>=0 && yo>=0 && yo<600) putpixel(xo+R,yo,c);
       if (xo-R<800 && xo-R>=0 && yo>=0 && yo<600) putpixel(xo-R,yo, c);
  }

void filldisc( int xo, int yo, int R, Uint32 c)
  {
      int x, y, F, F1, F2,newx,newy,xx;
      x=xo; y=yo+R; F=0;
      if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,c);
      if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, c);
      while( y>yo)
         {
             F1=F+2*(x-xo)+1; F2=F-2*(y-yo)+1;
             if ( abs(F1)<abs(F2))  { x+=1; F=F1;}
             else {y-=1; F=F2;}
             newx=2*xo-x ; newy=2*yo-y ;
             for(xx=newx; xx<=x; xx++)if (xx<800 && xx>=0 && y>=0 && y<600 )
             putpixel(xx,y,c);
             for(xx=newx; xx<=x; xx++)if (xx<800 && xx>=0 && newy>=0 && newy<600 )
             putpixel(xx,newy,c);
         }
       if (xo+R<800 && xo+R>=0&& y>=0 && y<600) putpixel(xo+R,yo,c);
       if (xo-R<800 && xo-R>=0&& y>=0 && y<600) putpixel(xo-R,yo, c);
  }
/**  ligne en marches d'escalier */
void line(int x0,int y0, int x1,int y1, Uint32 c)
{
int dx,dy,x,y,residu,absdx,absdy,pasx,pasy,i;
dx=x1-x0; dy=y1-y0;  residu=0;       x=x0;y=y0;  if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
if (dx>0) pasx=1;else pasx=-1; if (dy>0) pasy=1; else pasy=-1;
absdx=abs(dx);absdy=abs(dy);
if (dx==0) for(i=0;i<absdy;i++) { y+=pasy;
                                                    if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c); }
else if(dy==0) for(i=0;i<absdx;i++){ x+=pasx;
                                                         if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);  }
else if (absdx==absdy)
   for(i=0;i<absdx;i++) {x+=pasx; if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
                                     y+=pasy;
                                     if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
                                     }
else if (absdx>absdy)
          for(i=0;i<absdx;i++)
			  { x+=pasx; if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
			     residu+=absdy;
			     if(residu >= absdx) {residu -=absdx; y+=pasy;
	                              		        if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
			                                    }
			  }
else for(i=0;i<absdy;i++)
             {y+=pasy; if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
               residu +=absdx;
              if (residu>=absdy)   {residu -= absdy;x +=pasx;
                                              if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
                                             }
             }
}


