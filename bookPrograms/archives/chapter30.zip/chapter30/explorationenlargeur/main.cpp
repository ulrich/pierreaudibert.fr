/*************     BREADTH FIRST EXPLORATION     **************/
/*************                 Fig. 30-9                                       **************/

#include <SDL/SDL.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <dos.h>
#include <math.h>
#define N 40
#define NN (N*N)
#define xorig 20
#define yorig 5
#define step 15

void pause(void);
void putpixel(int xe, int ye, Uint32 couleur);
Uint32 getpixel(int xe, int ye);
void circle( int xo, int yo, int R, Uint32 couleur);
void filldisc(int xo, int yo, int R,Uint32 couleur);
void line(int x0,int y0, int x1,int y1, Uint32 c);
void linewithwidth(int x1, int y1, int x2, int y2, int epaisseur,Uint32 c);
void graphe(void);
void add(int u);
void ssearch(int s);
void remove(void);
void chemin (int s, int v);
void initialdrawing(void);
void pathdrawing(int s,int v);
void pathdrawing1(int s,int v);
int pred[NN],d[NN],f[NN+1],colorpoint[NN];
int ii,tab[NN],neighbor[NN][NN+1],ttab[NN][NN];
SDL_Surface * screen;
Uint32 white,finished,notyetreached,reached,color[4];

/*************************    programme principal    **********************/
int main(int argc, char ** argv)
{  int j,start,end, i,nbneighbor;
   SDL_Init(SDL_INIT_VIDEO);
   screen=SDL_SetVideoMode(800,600,32, SDL_HWSURFACE|SDL_DOUBLEBUF);
   white=SDL_MapRGB(screen->format,255,255,255);
   notyetreached=SDL_MapRGB(screen->format,255,255,255);
   finished=SDL_MapRGB(screen->format,0,0,0);
   reached=SDL_MapRGB(screen->format,255,0,0);
   color[0]=SDL_MapRGB(screen->format,0,0,0);
   color[1]=SDL_MapRGB(screen->format,255,0,0);
   color[2]=SDL_MapRGB(screen->format,0,250,0);
   color[3]=SDL_MapRGB(screen->format,0,0,250);

   SDL_FillRect(screen,0,white);  srand(time(NULL));
/*******************      random graph        ***************/
for(i=0;i<NN;i++)
  { ttab[i][i]=0;
     if (i%N!=0)  ttab[i][i-1]=rand()%2;
     if (i%N!=N-1)  ttab[i][i+1]=rand()%2;
     if (i>N)  ttab[i][i-N]=rand()%2;
     if (i<NN-N)  ttab[i][i+N]=rand()%2;

     if (i%N!=0 && i>N)  ttab[i-1][i-N]=rand()%2;
     if (i%N!=N-1 && i<NN-N)  ttab[i+1][i+N]=rand()%2;
     if (i>N && i%N!=N-1)  ttab[i+1][i-N]=rand()%2;
     if (i%N!=0 && i<NN-N)  ttab[i-1][i+N]=rand()%2;
  }
ttab[0][1]=1;ttab[1][0]=1;
for(j=0;j<N-1;j++)
   {ttab[N/2][j]=0; ttab[j][N/2]=0; ttab[N/2][j+N]=0; ttab[j+N][N/2]=0;
     ttab[N/4][j]=0; ttab[j][N/4]=0;ttab[3*N/4][j]=0; ttab[j][3*N/4]=0;
   }
for(i=0;i<NN;i++) for(j=0;j<NN;j++) ttab[i][j]=ttab[j][i];
for(i=0;i<NN;i++)
   { nbneighbor=0;
     for(j=0;j<NN;j++)
     if (ttab[i][j]==1 && i!=j) {neighbor[i][nbneighbor]=j; nbneighbor++;  }
     neighbor[i][nbneighbor]=1000;
   }
initialdrawing();
start=0;  ssearch(start);
end=NN-1;
pathdrawing(start,end);
SDL_Flip(screen); pause();  return 0;
}

/*****************************/

void ssearch(int s)
{ int i,j;
for(i=0;i<NN;i++)  if (i!=s)
    { colorpoint[i]=notyetreached; d[i]=1000;pred[i]=1000;  }
colorpoint[s]=reached; d[s]=0; pred[s]=1000;
filldisc(xorig+step*(s%N),yorig+step*(s/N),1,color[1]);
f[0]=s; f[1]=1000;
while (f[0]!=1000)
  { i=f[0];
     j=0;
    while (neighbor[i][j]!=1000)
      { if (colorpoint[neighbor[i][j]]==notyetreached)
          { colorpoint[neighbor[i][j]]=reached; d[neighbor[i][j]]=d[i]+1;pred[neighbor[i][j]]=i;
            add(neighbor[i][j]);
            linewithwidth(xorig+step*(neighbor[i][j]%N), yorig+step*(neighbor[i][j]/N),
                  xorig+step*(pred[neighbor[i][j]]%N), yorig+step*(pred[neighbor[i][j]]/N), 1,color[1]);
            filldisc(xorig+step*(neighbor[i][j]%N),yorig+step*(neighbor[i][j]/N),1,color[1]);
          }
        j++;
      }
   remove();colorpoint[i]=finished;
   filldisc(xorig+step*(i%N),yorig+step*(i/N),2,color[1]);
   SDL_Flip(screen); SDL_Delay(0);
 }
}

void remove(void)
{ int i=0;
   do {  f[i]=f[i+1];  i++; }
   while (f[i]!=1000);
}

void add(int u)
{  int i=0;
   while (f[i]!=1000) i++;
   f[i]=u; f[i+1]=1000;
}

void pathdrawing1(int s,int v)
{
if (v==s) {tab[ii++]=s;}
else if (pred[v]==1000)       filldisc(10,10,5,color[2]);
else
   { pathdrawing1(s, pred[v]);
      tab[ii++]=v;
   }
}

void pathdrawing(int s,int v)
{
int i;
pathdrawing1 (s,v);
circle(xorig+step*(s%N),yorig+step*(s/N),step/8,color[3]);
circle(xorig+step*(v%N),yorig+step*(v/N),step/8,color[3]);
for(i=0;i<ii-1;i++) { linewithwidth( xorig+step*(tab[i]%N),yorig+step*(tab[i]/N),
                            xorig+step*(tab[i+1]%N),yorig+step*(tab[i+1]/N),1,color[3]);
                            }
for(i=0;i<ii;i++)  {  filldisc(xorig+step*(tab[i]%N),yorig+step*(tab[i]/N),1,color[3]);}
}

void initialdrawing(void)
{ int i,j;
   for(i=0;i<NN;i++) filldisc(xorig+step*(i%N),yorig+step*(i/N),0,color[0]);
   for(i=0;i<NN;i++)
     { j=0;
       while(neighbor[i][j]!=1000)
       { linewithwidth(xorig+step*(i%N),yorig+step*(i/N),
               xorig+step*(neighbor[i][j]%N),yorig+step*(neighbor[i][j]/N),0,color[0]);
          j++;
       }
     }
}

void pause(void)
{
    SDL_Event evenement;
    do   SDL_WaitEvent(&evenement);
    while(evenement.type != SDL_QUIT && evenement.type != SDL_KEYDOWN);
}

void putpixel(int xe, int ye, Uint32 couleur)
{ Uint32 * numerocase;
numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;    *numerocase=couleur;
}

Uint32 getpixel(int xe, int ye)
{ Uint32 * numerocase;
   numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;   return (*numerocase);
}

void linewithwidth(int x1, int y1, int x2, int y2, int epaisseur,Uint32 c)
{
int dx,dy;
float k,xf1,yf1,xf2,yf2,d,dx1,dy1,ndx1,ndy1,ndx2,ndy2,angle=M_PI/2.;
line(x1,y1,x2,y2,c);
dx=x2-x1; dy=y2-y1;       d=sqrt(dx*dx+dy*dy);
if (d!=0.)
{ dx1=(float)epaisseur*(float)dx/d; dy1=(float)epaisseur*(float)dy/d;
   ndx1=dx1*cos(angle)-dy1*sin(angle);
   ndy1=dx1*sin(angle)+dy1*cos(angle);
   ndx2=dx1*cos(-angle)-dy1*sin(-angle);
   ndy2=dx1*sin(-angle)+dy1*cos(-angle);
   for(k=0;k<=1.;k+=0.1/d)
   {
   xf1=(1.-k)*x1+k*x2; yf1=(1.-k)*y1+k*y2;
   xf2=xf1-ndx1; yf2=yf1-ndy1;  line(xf1,yf1,xf2,yf2,c);
   xf2=xf1-ndx2; yf2=yf1-ndy2;    line(xf1,yf1,xf2,yf2,c);
   }
}
}

void circle( int xo, int yo, int R, Uint32 couleur)
  {
      int x, y, F, F1, F2,newx,newy;
      x=xo; y=yo+R; F=0;
      if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
      if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, couleur);
      while( y>yo)
         {
             F1=F+2*(x-xo)+1; F2=F-2*(y-yo)+1;
             if ( abs(F1)<abs(F2))  { x+=1; F=F1;}
             else {y-=1; F=F2;}
             if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
              newx=2*xo-x ; newy=2*yo-y ;
             if (x<800 && x>=0 && newy>=0 && newy<600) putpixel(x, newy,couleur);
             if (newx<800 && newx>=0 && y>=0 && y<600) putpixel( newx,y,couleur);
             if (newx<800 && newx>=0 && newy>=0 && newy<600) putpixel(newx,
             newy, couleur);
         }
       if (xo+R<800 && xo+R>=0 && yo>=0 && yo<600) putpixel(xo+R,yo,couleur);
       if (xo-R<800 && xo-R>=0 && yo>=0 && yo<600) putpixel(xo-R,yo, couleur);
  }

void filldisc( int xo, int yo, int R, Uint32 couleur)
  {
      int x, y, F, F1, F2,newx,newy,xx;
      x=xo; y=yo+R; F=0;
      if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
      if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, couleur);
      while( y>yo)
         {
             F1=F+2*(x-xo)+1; F2=F-2*(y-yo)+1;
             if ( abs(F1)<abs(F2))  { x+=1; F=F1;}
             else {y-=1; F=F2;}
             newx=2*xo-x ; newy=2*yo-y ;
             for(xx=newx; xx<=x; xx++)if (xx<800 && xx>=0 && y>=0 && y<600 )
             putpixel(xx,y,couleur);
             for(xx=newx; xx<=x; xx++)if (xx<800 && xx>=0 && newy>=0 && newy<600 )
             putpixel(xx,newy,couleur);
         }
       if (xo+R<800 && xo+R>=0&& y>=0 && y<600) putpixel(xo+R,yo,couleur);
       if (xo-R<800 && xo-R>=0&& y>=0 && y<600) putpixel(xo-R,yo, couleur);
  }

void line(int x0,int y0, int x1,int y1, Uint32 c)
{
int dx,dy,x,y,residu,absdx,absdy,pasx,pasy,i;
dx=x1-x0; dy=y1-y0;  residu=0;       x=x0;y=y0;  putpixel(x,y,c);
if (dx>0) pasx=1;else pasx=-1; if (dy>0) pasy=1; else pasy=-1;
absdx=abs(dx);absdy=abs(dy);
if (dx==0) for(i=0;i<absdy;i++) { y+=pasy;
                                                    putpixel(x,y,c); }
else if(dy==0) for(i=0;i<absdx;i++){ x+=pasx;
                                                         putpixel(x,y,c);  }
else if (absdx==absdy)
   for(i=0;i<absdx;i++) {x+=pasx; y+=pasy;
                                     putpixel(x,y,c);
                                     }
else if (absdx>absdy)
          for(i=0;i<absdx;i++)
			  { x+=pasx; residu+=absdy;
			     if(residu >= absdx) {residu -=absdx; y+=pasy;}
			     putpixel(x,y,c);
			  }
else for(i=0;i<absdy;i++)
             {y+=pasy; residu +=absdx;
              if (residu>=absdy)   {residu -= absdy;x +=pasx;}
              putpixel(x,y,c);
             }
}















