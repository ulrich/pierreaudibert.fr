/***************             RISING SHAPES           *********************/
/***************                  Fig. 30-16                   *********************/
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
void pause(void);
void putpixel(int xe, int ye, Uint32 c);
Uint32 getpixel(int xe, int ye);
void circle( int xo, int yo, int R, Uint32 c);
void filldisc(int xo, int yo, int R,Uint32 c);
void line(int x0,int y0, int x1,int y1, Uint32 c);
void linewithwidth(int x1, int y1, int x2, int y2, int width,Uint32 c);
void pred(int ii,int level);
int a[10][1000],b[10][1000],L[1000],x,y,step;
SDL_Surface * screen; Uint32 white,color[9];  SDL_Color cblack={0,0,0};
SDL_Surface *texte;  SDL_Rect position;TTF_Font *police=NULL;char chiffre[2000];

int main(int argc, char ** argv)
{ int etape,i,k,xorig=60,yorig=70,xoo,yoo ,qqq;
   SDL_Init(SDL_INIT_VIDEO);
   screen=SDL_SetVideoMode(800,600,32, SDL_HWSURFACE|SDL_DOUBLEBUF);
   white=SDL_MapRGB(screen->format,255,255,255);
   color[0]=SDL_MapRGB(screen->format,0,0,0);
   color[1]=SDL_MapRGB(screen->format,255,0,0);
   color[4]=SDL_MapRGB(screen->format,150,50,150);
   color[2]=SDL_MapRGB(screen->format,0,250,0);
   color[5]=SDL_MapRGB(screen->format,150,200,150);
   color[3]=SDL_MapRGB(screen->format,0,0,250);
   color[6]=SDL_MapRGB(screen->format,150,150,200);
   color[7]=SDL_MapRGB(screen->format,255,255,0);
   color[8]=SDL_MapRGB(screen->format,200,200,200);
   SDL_FillRect(screen,0,white);
   TTF_Init();  police=TTF_OpenFont("times.ttf",20);

a[1][0]=0;a[1][1]=1;a[1][2]=2; L[1]=3;

for(etape=2;etape<8;etape++)
{  step=60/etape;
  sprintf( chiffre,"%d",etape);
   texte=TTF_RenderText_Solid(police,chiffre,cblack);
   position.x=10; position.y=10;
   SDL_BlitSurface(texte,NULL,screen,&position);
k=0;
for(i=0;i<L[etape-1];i++)
  {
    if (a[etape-1][i]==0)
      { a[etape][k]=0;a[etape][k+1]=2;
	     b[etape][k]=i;b[etape][k+1]=i;k+=2;  }
    if (a[etape-1][i]==1)
      { a[etape][k]=1;a[etape][k+1]=2;
	     b[etape][k]=i;b[etape][k+1]=i;k+=2;   }
    if (a[etape-1][i]==2)
      { a[etape][k]=0;a[etape][k+1]=1;a[etape][k+2]=2;
	     b[etape][k]=i;b[etape][k+1]=i;
	     b[etape][k+2]=i; k+=3; }
  }
L[etape]=k;
xoo=xorig;yoo=yorig;
for(i=0;i<L[etape];i++)
     {
     x=xoo;y=yoo;  filldisc(xoo,yoo,3,color[1]);
     pred(i,etape);
     if (etape<=4) qqq=40;if (etape>4) qqq=20;
     xoo+=step*etape+qqq; if (xoo>750) {xoo=xorig; yoo+=step*etape+15;}
     if (yoo>560) { SDL_Flip(screen); pause(); SDL_FillRect(screen,0,white);
                           xoo=xorig; yoo=70;}
     }
SDL_Flip(screen); pause(); SDL_FillRect(screen,0,white);
}
SDL_Flip(screen); pause();  TTF_CloseFont(police); TTF_Quit();  return 0;
}

void pred(int ii,int level)
{ int previousindex,trait;
  if (level>1)
    { previousindex=b[level][ii];
       pred(previousindex,level-1);
    }
  trait=a[level][ii];
  if (trait==0) { linewithwidth(x,y,x+step,y,1,color[0]);filldisc(x+step,y, 2,color[0]);  x+=step;}
  if (trait==1) { linewithwidth(x,y,x-step,y,1,color[0]);filldisc(x-step,y, 2,color[0]); x-=step;}
  if (trait==2) { linewithwidth(x,y,x,y-step,1,color[0]);filldisc(x,y-step, 2,color[0]); y-=step;}
}

void pause(void)
{
    SDL_Event evenement;
    do   SDL_WaitEvent(&evenement);
    while(evenement.type != SDL_QUIT && evenement.type != SDL_KEYDOWN);
}

void putpixel(int xe, int ye, Uint32 c)
{ Uint32 * numerocase;
numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;    *numerocase=c;
}

Uint32 getpixel(int xe, int ye)
{ Uint32 * numerocase;
   numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;   return (*numerocase);
}


void linewithwidth(int x1, int y1, int x2, int y2, int width,Uint32 c)
{
int dx,dy;
float k,xf1,yf1,xf2,yf2,d,dx1,dy1,ndx1,ndy1,ndx2,ndy2,angle=M_PI/2.;
line(x1,y1,x2,y2,c);
dx=x2-x1; dy=y2-y1;       d=sqrt(dx*dx+dy*dy);
if (d!=0.)
{ dx1=(float)width*(float)dx/d; dy1=(float)width*(float)dy/d;
   ndx1=dx1*cos(angle)-dy1*sin(angle);
   ndy1=dx1*sin(angle)+dy1*cos(angle);
   ndx2=dx1*cos(-angle)-dy1*sin(-angle);
   ndy2=dx1*sin(-angle)+dy1*cos(-angle);
   for(k=0;k<=1.;k+=0.1/d)
   {
   xf1=(1.-k)*x1+k*x2; yf1=(1.-k)*y1+k*y2;
   xf2=xf1-ndx1; yf2=yf1-ndy1;  line(xf1,yf1,xf2,yf2,c);
   xf2=xf1-ndx2; yf2=yf1-ndy2;    line(xf1,yf1,xf2,yf2,c);
   }
}
}

void circle( int xo, int yo, int R, Uint32 c)
  {
      int x, y, F, F1, F2,newx,newy;
      x=xo; y=yo+R; F=0;
      if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,c);
      if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, c);
      while( y>yo)
         {
             F1=F+2*(x-xo)+1; F2=F-2*(y-yo)+1;
             if ( abs(F1)<abs(F2))  { x+=1; F=F1;}
             else {y-=1; F=F2;}
             if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,c);
              newx=2*xo-x ; newy=2*yo-y ;
             if (x<800 && x>=0 && newy>=0 && newy<600) putpixel(x, newy,c);
             if (newx<800 && newx>=0 && y>=0 && y<600) putpixel( newx,y,c);
             if (newx<800 && newx>=0 && newy>=0 && newy<600) putpixel(newx,
             newy, c);
         }
       if (xo+R<800 && xo+R>=0 && yo>=0 && yo<600) putpixel(xo+R,yo,c);
       if (xo-R<800 && xo-R>=0 && yo>=0 && yo<600) putpixel(xo-R,yo, c);
  }

void filldisc( int xo, int yo, int R, Uint32 c)
  {
      int x, y, F, F1, F2,newx,newy,xx;
      x=xo; y=yo+R; F=0;
      if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,c);
      if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, c);
      while( y>yo)
         {
             F1=F+2*(x-xo)+1; F2=F-2*(y-yo)+1;
             if ( abs(F1)<abs(F2))  { x+=1; F=F1;}
             else {y-=1; F=F2;}
             newx=2*xo-x ; newy=2*yo-y ;
             for(xx=newx; xx<=x; xx++)if (xx<800 && xx>=0 && y>=0 && y<600 )
             putpixel(xx,y,c);
             for(xx=newx; xx<=x; xx++)if (xx<800 && xx>=0 && newy>=0 && newy<600 )
             putpixel(xx,newy,c);
         }
       if (xo+R<800 && xo+R>=0&& y>=0 && y<600) putpixel(xo+R,yo,c);
       if (xo-R<800 && xo-R>=0&& y>=0 && y<600) putpixel(xo-R,yo, c);
  }
/**  ligne en marches d'escalier */
void line(int x0,int y0, int x1,int y1, Uint32 c)
{
int dx,dy,x,y,residu,absdx,absdy,pasx,pasy,i;
dx=x1-x0; dy=y1-y0;  residu=0;       x=x0;y=y0;  if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
if (dx>0) pasx=1;else pasx=-1; if (dy>0) pasy=1; else pasy=-1;
absdx=abs(dx);absdy=abs(dy);
if (dx==0) for(i=0;i<absdy;i++) { y+=pasy;
                                                    if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c); }
else if(dy==0) for(i=0;i<absdx;i++){ x+=pasx;
                                                         if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);  }
else if (absdx==absdy)
   for(i=0;i<absdx;i++) {x+=pasx; if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
                                     y+=pasy;
                                     if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
                                     }
else if (absdx>absdy)
          for(i=0;i<absdx;i++)
			  { x+=pasx; if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
			     residu+=absdy;
			     if(residu >= absdx) {residu -=absdx; y+=pasy;
	                              		        if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
			                                    }
			  }
else for(i=0;i<absdy;i++)
             {y+=pasy; if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
               residu +=absdx;
              if (residu>=absdy)   {residu -= absdy;x +=pasx;
                                              if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
                                             }
             }
}



