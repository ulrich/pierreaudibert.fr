/****************    DEPTH FIRST EXPLORATION           ******************/
/****************        like a pedestrian who sees                   ******************/
                                   /*****    Fig. 30-3    *****/

#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define N 8
#define YES 1
#define NO 0
void visit(int i);
void pause(void);
void putpixel(int xe, int ye, Uint32 couleur);
Uint32 getpixel(int xe, int ye);
void circle( int xo, int yo, int R, Uint32 couleur);
void filldisc(int xo, int yo, int R,Uint32 couleur);
void line(int x0,int y0, int x1,int y1, Uint32 c);
void arrow(int x1, int y1, int x2, int y2, Uint32 c);
void linewithwidth(int x1, int y1, int x2, int y2, int epaisseur,Uint32 c);
SDL_Surface * screen; Uint32 white,color[9];  SDL_Color cblack={0,0,0};
SDL_Surface *texte;  SDL_Rect position;TTF_Font *police=NULL;char chiffre[2000];
int x[N],y[N],n[N][N],nbn[N],alreadyseen[N],pred[N],l[8],k=0;
int finished[N];

int main(int argc, char ** argv)
{ int i,j,start;
   SDL_Init(SDL_INIT_VIDEO);
   screen=SDL_SetVideoMode(800,600,32, SDL_HWSURFACE|SDL_DOUBLEBUF);
   white=SDL_MapRGB(screen->format,255,255,255);
   color[0]=SDL_MapRGB(screen->format,0,0,0);
   color[1]=SDL_MapRGB(screen->format,255,0,0);
   color[4]=SDL_MapRGB(screen->format,150,50,150);
   color[2]=SDL_MapRGB(screen->format,0,250,0);
   color[5]=SDL_MapRGB(screen->format,150,200,150);
   color[3]=SDL_MapRGB(screen->format,0,0,250);
   color[6]=SDL_MapRGB(screen->format,150,150,200);
   color[7]=SDL_MapRGB(screen->format,255,255,0);
   color[8]=SDL_MapRGB(screen->format,200,200,200);
   SDL_FillRect(screen,0,white);
   TTF_Init();  police=TTF_OpenFont("times.ttf",20);
/**********    innitial conditions    ****************/
x[0]=200;y[0]=40;  x[1]=100;y[1]=200;  x[2]=400;y[2]=40;  x[3]=300;y[3]=400;
x[4]=100;y[4]=400;  x[5]=400;y[5]=200;  x[6]=240;y[6]=300;  x[7]=200;y[7]=200;

n[0][0]=1;n[0][1]=2;n[0][2]=5;n[0][3]=7;n[1][0]=0;n[1][1]=4;n[1][2]=7;n[2][0]=0;
n[3][0]=4;n[3][1]=5;n[3][2]=6;n[4][0]=1;n[4][1]=3;n[4][2]=6;n[4][3]=7;
n[5][0]=0;n[5][1]=3;n[5][2]=6;n[6][0]=3;n[6][1]=4;n[6][2]=5;n[7][0]=0;n[7][1]=1;n[7][2]=4;

nbn[0]=4;nbn[1]=3;nbn[2]=1;nbn[3]=3;nbn[4]=4;nbn[5]=3;nbn[6]=3;nbn[7]=3;
/**************   graph drawing    *****************/
for(i=0;i<N;i++)
  {
   for(j=0;j<nbn[i];j++)  linewithwidth(x[i],y[i],x[n[i][j]],y[n[i][j]],1,color[8]);
   sprintf( chiffre,"%d",i);
   texte=TTF_RenderText_Solid(police,chiffre,cblack);
   position.x=x[i]+15; position.y=y[i]-2;
   SDL_BlitSurface(texte,NULL,screen,&position);
  }
SDL_Flip(screen); pause();

start=0;
visit(start);
SDL_Flip(screen); pause();  TTF_CloseFont(police); TTF_Quit();  return 0;
}
/*******************    fonction de visite     *************************/
void visit(int i)
{ int j,neighbor;
  alreadyseen[i]=YES; circle(x[i],y[i],4,color[1]);
  for(j=0;j<nbn[i];j++)
   {
    neighbor=n[i][j];
    if (alreadyseen[neighbor]==NO)
      {pred[neighbor]=i;
       arrow(x[i],y[i],x[neighbor],y[neighbor],color[1]);
       SDL_Flip(screen); pause();
       visit(neighbor);
      }
   }
  arrow(x[i]+7,y[i]+7,x[pred[i]]+7,y[pred[i]]+7,color[1]);
  finished[i]=YES; circle(x[i],y[i],8,color[1]);
  SDL_Flip(screen); pause();
}

void pause(void)
{
    SDL_Event evenement;
    do   SDL_WaitEvent(&evenement);
    while(evenement.type != SDL_QUIT && evenement.type != SDL_KEYDOWN);
}

void putpixel(int xe, int ye, Uint32 couleur)
{ Uint32 * numerocase;
numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;    *numerocase=couleur;
}

Uint32 getpixel(int xe, int ye)
{ Uint32 * numerocase;
   numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;   return (*numerocase);
}

void linewithwidth(int x1, int y1, int x2, int y2, int epaisseur,Uint32 c)
{
int dx,dy;
float k,xf1,yf1,xf2,yf2,d,dx1,dy1,ndx1,ndy1,ndx2,ndy2,angle=M_PI/2.;
line(x1,y1,x2,y2,c);
dx=x2-x1; dy=y2-y1;       d=sqrt(dx*dx+dy*dy);
if (d!=0.)      /* si le vecteur n’est pas nul */
{ dx1=(float)epaisseur*(float)dx/d; dy1=(float)epaisseur*(float)dy/d;
   ndx1=dx1*cos(angle)-dy1*sin(angle);
   ndy1=dx1*sin(angle)+dy1*cos(angle);
   ndx2=dx1*cos(-angle)-dy1*sin(-angle);
   ndy2=dx1*sin(-angle)+dy1*cos(-angle);
   for(k=0;k<=1.;k+=0.1/d)
   {
   xf1=(1.-k)*x1+k*x2; yf1=(1.-k)*y1+k*y2;
   xf2=xf1-ndx1; yf2=yf1-ndy1;  line(xf1,yf1,xf2,yf2,c);
   xf2=xf1-ndx2; yf2=yf1-ndy2;    line(xf1,yf1,xf2,yf2,c);
   }
}
}

void circle( int xo, int yo, int R, Uint32 couleur)
  {
      int x, y, F, F1, F2,newx,newy;
      x=xo; y=yo+R; F=0;
      if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
      if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, couleur);
      while( y>yo)
         {
             F1=F+2*(x-xo)+1; F2=F-2*(y-yo)+1;
             if ( abs(F1)<abs(F2))  { x+=1; F=F1;}
             else {y-=1; F=F2;}
             if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
              newx=2*xo-x ; newy=2*yo-y ;
             if (x<800 && x>=0 && newy>=0 && newy<600) putpixel(x, newy,couleur);
             if (newx<800 && newx>=0 && y>=0 && y<600) putpixel( newx,y,couleur);
             if (newx<800 && newx>=0 && newy>=0 && newy<600) putpixel(newx,
             newy, couleur);
         }
       if (xo+R<800 && xo+R>=0 && yo>=0 && yo<600) putpixel(xo+R,yo,couleur);
       if (xo-R<800 && xo-R>=0 && yo>=0 && yo<600) putpixel(xo-R,yo, couleur);
  }

void filldisc( int xo, int yo, int R, Uint32 couleur)
  {
      int x, y, F, F1, F2,newx,newy,xx;
      x=xo; y=yo+R; F=0;
      if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
      if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, couleur);
      while( y>yo)
         {
             F1=F+2*(x-xo)+1; F2=F-2*(y-yo)+1;
             if ( abs(F1)<abs(F2))  { x+=1; F=F1;}
             else {y-=1; F=F2;}
             newx=2*xo-x ; newy=2*yo-y ;
             for(xx=newx; xx<=x; xx++)if (xx<800 && xx>=0 && y>=0 && y<600 )
             putpixel(xx,y,couleur);
             for(xx=newx; xx<=x; xx++)if (xx<800 && xx>=0 && newy>=0 && newy<600 )
             putpixel(xx,newy,couleur);
         }
       if (xo+R<800 && xo+R>=0&& y>=0 && y<600) putpixel(xo+R,yo,couleur);
       if (xo-R<800 && xo-R>=0&& y>=0 && y<600) putpixel(xo-R,yo, couleur);
  }
/**  ligne en marches d'escalier */
void line(int x0,int y0, int x1,int y1, Uint32 c)
{
int dx,dy,x,y,residu,absdx,absdy,pasx,pasy,i;
dx=x1-x0; dy=y1-y0;  residu=0;       x=x0;y=y0;  if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
if (dx>0) pasx=1;else pasx=-1; if (dy>0) pasy=1; else pasy=-1;
absdx=abs(dx);absdy=abs(dy);
if (dx==0) for(i=0;i<absdy;i++) { y+=pasy;
                                                    if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c); }
else if(dy==0) for(i=0;i<absdx;i++){ x+=pasx;
                                                         if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);  }
else if (absdx==absdy)
   for(i=0;i<absdx;i++) {x+=pasx; if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
                                     y+=pasy;
                                     if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
                                     }
else if (absdx>absdy)
          for(i=0;i<absdx;i++)
			  { x+=pasx; if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
			     residu+=absdy;
			     if(residu >= absdx) {residu -=absdx; y+=pasy;
	                              		        if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
			                                    }
			  }
else for(i=0;i<absdy;i++)
             {y+=pasy; if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
               residu +=absdx;
              if (residu>=absdy)   {residu -= absdy;x +=pasx;
                                              if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
                                             }
             }
}

void arrow(int x1, int y1, int x2, int y2, Uint32 c)
{
int dx,dy;
float xf1,yf1,xf2,yf2,d,dx1,dy1,ndx1,ndy1,ndx2,ndy2,angle=M_PI/6.;
line(x1,y1,x2,y2,c);
dx=x2-x1; dy=y2-y1;       d=sqrt(dx*dx+dy*dy);
if (d!=0.)      /* si le vecteur n’est pas nul */
{ dx1=10.*(float)dx/d; dy1=10.*(float)dy/d;
   ndx1=dx1*cos(angle)-dy1*sin(angle);
   ndy1=dx1*sin(angle)+dy1*cos(angle);
   xf1=0.3*x1+0.7*x2; yf1=0.3*y1+0.7*y2;     xf2=xf1-ndx1; yf2=yf1-ndy1;
   line(xf1,yf1,xf2,yf2,c);
   ndx2=dx1*cos(-angle)-dy1*sin(-angle);
   ndy2=dx1*sin(-angle)+dy1*cos(-angle);
   xf2=xf1-ndx2; yf2=yf1-ndy2;    line(xf1,yf1,xf2,yf2,c);
}
/**
else    si le vecteur est nul, on dessine un cercle du point vers lui-même
     {circle(x1+10,y1,10,c); line(x1+20,y1,x1+23,y1-6,c);
      line(x1+20,y1,x1+15,y1-5,c);
     }
*/
}


