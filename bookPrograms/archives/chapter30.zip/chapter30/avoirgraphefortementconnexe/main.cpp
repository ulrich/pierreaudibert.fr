/*********       FROM A NON DIRECTED GRAPH
                       TO A STONGLY CONNECTED GRAPH               **********/
 /*****************          Fig 30-26                 ************************/

#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define NS 20
#define xorig 50
#define yorig 100
#define pas 100
void explore(int s);
void drawing(void);
void pause(void);
void putpixel(int xe, int ye, Uint32 couleur);
Uint32 getpixel(int xe, int ye);
void circle( int xo, int yo, int R, Uint32 couleur);
void filldisc(int xo, int yo, int R,Uint32 couleur);
void line(int x0,int y0, int x1,int y1, Uint32 c);
void fleche(int x1, int y1, int x2, int y2, Uint32 c);
void linewithwidth(int x1, int y1, int x2, int y2, int epaisseur,Uint32 c);
void arrowwithwidth(int x1, int y1, int x2, int y2, int e,Uint32 c);
SDL_Surface * ecran; Uint32 blanc,color[9];  SDL_Color couleurnoire={0,0,0};
SDL_Surface *texte;  SDL_Rect position;TTF_Font *police=NULL;char chiffre[2000];
int d[NS][NS],x[NS],y[NS],dejavu[NS],count=1,pred[NS];
int n,nd;

int main(int argc, char ** argv)
{  int i,j,k;
   SDL_Init(SDL_INIT_VIDEO);
   ecran=SDL_SetVideoMode(800,600,32, SDL_HWSURFACE|SDL_DOUBLEBUF);
   blanc=SDL_MapRGB(ecran->format,255,255,255);
   color[0]=SDL_MapRGB(ecran->format,0,0,0);
   color[1]=SDL_MapRGB(ecran->format,255,0,0);
   color[4]=SDL_MapRGB(ecran->format,150,50,150);
   color[2]=SDL_MapRGB(ecran->format,0,250,0);
   color[5]=SDL_MapRGB(ecran->format,150,200,150);
   color[3]=SDL_MapRGB(ecran->format,0,0,250);
   color[6]=SDL_MapRGB(ecran->format,150,150,200);
   color[7]=SDL_MapRGB(ecran->format,255,255,0);
   color[8]=SDL_MapRGB(ecran->format,200,200,200);
   SDL_FillRect(ecran,0,blanc);
   TTF_Init();  police=TTF_OpenFont("times.ttf",20);

for(i=0;i<NS;i++) {x[i]=xorig+pas*(i%4);y[i]=yorig+pas*(i/4);}
for(i=0;i<NS;i++) for(j=0;j<NS;j++) d[i][j]=100;
for(i=0;i<NS;i+=2) {d[i][(i+1)%NS]=1; d[(i+1)%NS][i]=1; }
for(i=0;i<NS-4;i++) {d[i][i+4]=1; d[i+4][i]=1;}
for(i=0;i<NS;i++) d[i][i]=0;
d[5][6]=1; d[6][5]=1;
d[13][14]=1; d[14][13]=1;

for(i=0;i<NS;i++)
   {  filldisc(x[i],y[i],4,color[0] );
	   sprintf( chiffre,"%d",i);
       texte=TTF_RenderText_Solid(police,chiffre,couleurnoire);
       position.x=x[i]+7; position.y=y[i]+4;
       SDL_BlitSurface(texte,NULL,ecran,&position);
	   circle(x[i]+16,y[i]+15,12,color[0]);
                  }
drawing(); SDL_Flip(ecran); pause();

dejavu[0]=1; explore(0);
for(i=0;i<NS;i++)
   {
      sprintf( chiffre,"%d",dejavu[i]);
       texte=TTF_RenderText_Solid(police,chiffre,couleurnoire);
       position.x=x[i]+7; position.y=y[i]+25;
       SDL_BlitSurface(texte,NULL,ecran,&position);
   }
for(i=1;i<NS;i++) linewithwidth(x[i],y[i],x[pred[i]],y[pred[i]],2,color[1]);
SDL_Flip(ecran); pause();

for(i=1;i<NS;i++) if (dejavu[i]>dejavu[pred[i]])
   {arrowwithwidth(x[pred[i]], y[pred[i]],x[i] , y[i],3, color[1]); d[i][pred[i]]=100;
   }
SDL_Flip(ecran); pause();

k=0;
for(i=0;i<NS;i++) for(j=0;j<NS;j++)
if (d[i][j]==1 && pred[j]!=i && dejavu[i]>dejavu[j])
{

arrowwithwidth(x[i], y[i],x[j], y[j],3,color[1]);
}
for(i=0;i<NS;i++) filldisc(x[i],y[i],5,color[2] );
sprintf( chiffre,"STRONGLY CONNECTED GRAPH");
       texte=TTF_RenderText_Solid(police,chiffre,couleurnoire);
       position.x=400; position.y=50
       ;
       SDL_BlitSurface(texte,NULL,ecran,&position);
SDL_Flip(ecran); pause();  TTF_CloseFont(police); TTF_Quit();  return 0;
}

void explore(int s)
{
int j,voisin;
dejavu[s]=count++;
for(j=0;j<NS;j++) if (d[s][j]==1 && dejavu[j]==0)
  {voisin=j; pred[voisin]=s; explore(voisin);}
}

void drawing(void)
{  int i,j;
for(i=0;i<NS;i++) for(j=0;j<NS;j++) if (d[i][j]==1)
 { arrowwithwidth(x[i],y[i],x[j],y[j],0,color[0]); }
}

void pause(void)
{
    SDL_Event evenement;
    do   SDL_WaitEvent(&evenement);
    while(evenement.type != SDL_QUIT && evenement.type != SDL_KEYDOWN);
}

void putpixel(int xe, int ye, Uint32 couleur)
{ Uint32 * numerocase;
numerocase= (Uint32 *)(ecran->pixels)+xe+ye*ecran->w;    *numerocase=couleur;
}

Uint32 getpixel(int xe, int ye)
{ Uint32 * numerocase;
   numerocase= (Uint32 *)(ecran->pixels)+xe+ye*ecran->w;   return (*numerocase);
}

void linewithwidth(int x1, int y1, int x2, int y2, int epaisseur,Uint32 c)
{
int dx,dy;
float k,xf1,yf1,xf2,yf2,d,dx1,dy1,ndx1,ndy1,ndx2,ndy2,angle=M_PI/2.;
line(x1,y1,x2,y2,c);
dx=x2-x1; dy=y2-y1;       d=sqrt(dx*dx+dy*dy);
if (d!=0.)      /* si le vecteur n’est pas nul */
{ dx1=(float)epaisseur*(float)dx/d; dy1=(float)epaisseur*(float)dy/d;
   ndx1=dx1*cos(angle)-dy1*sin(angle);
   ndy1=dx1*sin(angle)+dy1*cos(angle);
   ndx2=dx1*cos(-angle)-dy1*sin(-angle);
   ndy2=dx1*sin(-angle)+dy1*cos(-angle);
   for(k=0;k<=1.;k+=0.1/d)
   {
   xf1=(1.-k)*x1+k*x2; yf1=(1.-k)*y1+k*y2;
   xf2=xf1-ndx1; yf2=yf1-ndy1;  line(xf1,yf1,xf2,yf2,c);
   xf2=xf1-ndx2; yf2=yf1-ndy2;    line(xf1,yf1,xf2,yf2,c);
   }
}
}

void circle( int xo, int yo, int R, Uint32 couleur)
  {
      int x, y, F, F1, F2,newx,newy;
      x=xo; y=yo+R; F=0;
      if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
      if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, couleur);
      while( y>yo)
         {
             F1=F+2*(x-xo)+1; F2=F-2*(y-yo)+1;
             if ( abs(F1)<abs(F2))  { x+=1; F=F1;}
             else {y-=1; F=F2;}
             if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
              newx=2*xo-x ; newy=2*yo-y ;
             if (x<800 && x>=0 && newy>=0 && newy<600) putpixel(x, newy,couleur);
             if (newx<800 && newx>=0 && y>=0 && y<600) putpixel( newx,y,couleur);
             if (newx<800 && newx>=0 && newy>=0 && newy<600) putpixel(newx,
             newy, couleur);
         }
       if (xo+R<800 && xo+R>=0 && yo>=0 && yo<600) putpixel(xo+R,yo,couleur);
       if (xo-R<800 && xo-R>=0 && yo>=0 && yo<600) putpixel(xo-R,yo, couleur);
  }

void filldisc( int xo, int yo, int R, Uint32 couleur)
  {
      int x, y, F, F1, F2,newx,newy,xx;
      x=xo; y=yo+R; F=0;
      if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
      if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, couleur);
      while( y>yo)
         {
             F1=F+2*(x-xo)+1; F2=F-2*(y-yo)+1;
             if ( abs(F1)<abs(F2))  { x+=1; F=F1;}
             else {y-=1; F=F2;}
             newx=2*xo-x ; newy=2*yo-y ;
             for(xx=newx; xx<=x; xx++)if (xx<800 && xx>=0 && y>=0 && y<600 )
             putpixel(xx,y,couleur);
             for(xx=newx; xx<=x; xx++)if (xx<800 && xx>=0 && newy>=0 && newy<600 )
             putpixel(xx,newy,couleur);
         }
       if (xo+R<800 && xo+R>=0&& y>=0 && y<600) putpixel(xo+R,yo,couleur);
       if (xo-R<800 && xo-R>=0&& y>=0 && y<600) putpixel(xo-R,yo, couleur);
  }
/**  ligne en marches d'escalier */
void line(int x0,int y0, int x1,int y1, Uint32 c)
{
int dx,dy,x,y,residu,absdx,absdy,pasx,pasy,i;
dx=x1-x0; dy=y1-y0;  residu=0;       x=x0;y=y0;  if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
if (dx>0) pasx=1;else pasx=-1; if (dy>0) pasy=1; else pasy=-1;
absdx=abs(dx);absdy=abs(dy);
if (dx==0) for(i=0;i<absdy;i++) { y+=pasy;
                                                    if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c); }
else if(dy==0) for(i=0;i<absdx;i++){ x+=pasx;
                                                         if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);  }
else if (absdx==absdy)
   for(i=0;i<absdx;i++) {x+=pasx; if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
                                     y+=pasy;
                                     if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
                                     }
else if (absdx>absdy)
          for(i=0;i<absdx;i++)
			  { x+=pasx; if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
			     residu+=absdy;
			     if(residu >= absdx) {residu -=absdx; y+=pasy;
	                              		        if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
			                                    }
			  }
else for(i=0;i<absdy;i++)
             {y+=pasy; if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
               residu +=absdx;
              if (residu>=absdy)   {residu -= absdy;x +=pasx;
                                              if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
                                             }
             }
}

void arrowwithwidth(int x1, int y1, int x2, int y2, int e,Uint32 c)
{
int dx,dy;
float xf1,yf1,xf2,yf2,d,dx1,dy1,ndx1,ndy1,ndx2,ndy2,angle=M_PI/6.;
linewithwidth(x1,y1,x2,y2,e,c);
dx=x2-x1; dy=y2-y1;       d=sqrt(dx*dx+dy*dy);
if (d!=0.)      /* si le vecteur n’est pas nul */
{ dx1=10.*(float)dx/d; dy1=10.*(float)dy/d;
   ndx1=dx1*cos(angle)-dy1*sin(angle);
   ndy1=dx1*sin(angle)+dy1*cos(angle);
   xf1=0.3*x1+0.7*x2; yf1=0.3*y1+0.7*y2;     xf2=xf1-ndx1; yf2=yf1-ndy1;
   linewithwidth(xf1,yf1,xf2,yf2,e,c);
   ndx2=dx1*cos(-angle)-dy1*sin(-angle);
   ndy2=dx1*sin(-angle)+dy1*cos(-angle);
   xf2=xf1-ndx2; yf2=yf1-ndy2;    linewithwidth(xf1,yf1,xf2,yf2,e,c);
}
/**
else    if null vector, drawing of a circle from point to itself
     {circle(x1+10,y1,10,c); line(x1+20,y1,x1+23,y1-6,c);
      line(x1+20,y1,x1+15,y1-5,c);
     }
*/
}


