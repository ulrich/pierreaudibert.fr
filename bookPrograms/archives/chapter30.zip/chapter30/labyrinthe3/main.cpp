/**********************             MAZE  ***        **********************/
/**********************             Fig. 30-5              *********************/
#include <SDL/SDL.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#define xorig 120
#define yorig 450
#define pas 20
void laby(void);
void uturn(int x, int y,int d);
void square(int x,int y, int d);
void stroke(int x,int y,int d);
void rightangle(int x,int y, int d);
void pause(void);
void putpixel(int xe, int ye, Uint32 c);
Uint32 getpixel(int xe, int ye);
void circle( int xo, int yo, int R, Uint32 c);
void filldisc( int xo, int yo, int R, Uint32 c);
void line(int x0,int y0, int x1,int y1, Uint32 c);
void rectangle(int x1,int y1, int x2, int y2, Uint32 c);
void floodfill( int x,int y, Uint32 cr,Uint32 cb);
SDL_Surface * screen; Uint32 white,red,blue,c1,c2,c3;

int main(int argc, char ** argv)
{
int x,y,dir,olddir,oldx,oldy,interdit,i,cumul,compteur[4],newx,newy,yd,xd,k;
    SDL_Init(SDL_INIT_VIDEO);
    screen=SDL_SetVideoMode(800,600,32, SDL_HWSURFACE|SDL_DOUBLEBUF);
    white=SDL_MapRGB(screen->format,255,255,255);
    red=SDL_MapRGB(screen->format,255,0,0);
    blue=SDL_MapRGB(screen->format,150,150,255);
    c1=SDL_MapRGB(screen->format,255,100,100);
    c2=SDL_MapRGB(screen->format,55,250,0);
    c3=SDL_MapRGB(screen->format,55,0,250);
    SDL_FillRect(screen,0,white);

laby();

xd=xorig+pas*11.5; x=xd;  yd=yorig-pas*17.5; y=yd;  circle(x,y,2,blue); olddir=3;

for(;;)
  { oldx=x;oldy=y; interdit=(olddir+2)%4;

   for(i=0;i<4;i++) compteur[i]=0;
   for(i=(interdit+1)%4;i<(interdit+1)%4+3;i++)
     {
     if (i%4==0 && getpixel(x+pas,y)!=blue && getpixel(x+pas,y)!=c2) compteur[0]=1;
     if (i%4==1 && getpixel(x,y-pas)!=blue && getpixel(x,y-pas)!=c2) compteur[1]=1;
     if (i%4==2 && getpixel(x-pas,y)!=blue && getpixel(x-pas,y)!=c2) compteur[2]=1;
     if (i%4==3 && getpixel(x,y+pas)!=blue && getpixel(x,y+pas)!=c2) compteur[3]=1;
     }
   cumul=0;
   for(i=0;i<4;i++) cumul+=compteur[i];
   if (cumul==0)
     {	 dir=interdit; uturn(x,y,dir); filldisc(x,y,1,c2);
     }
   else if (cumul>1)
     {  rectangle(x-pas/10,y-pas/10,x+pas/10,y+pas/10,blue);   floodfill(x,y,c3,blue);
         i=(interdit+3)%4;
	    while(compteur[i]==0) i=(i+3)%4;
	    dir=i;
	    if (dir==olddir) {stroke(x,y,dir);}
		else if(dir==(olddir+1)%4)  square(x,y,dir);
		else if (olddir==(dir+1)%4) rightangle(x,y,dir);
		if (dir==0) x+=pas;  else if (dir==1) y-=pas; else if (dir==2) x-=pas;  else if (dir==3) y+=pas;
	 }
   else if (cumul==1)
     { i=0; while (compteur[i]==0) i++;
		dir=i;
        if (getpixel(x,y)==white)   filldisc(x,y,1,c1);  else        filldisc(x,y,1,c2);
        if (dir==0) {newx=x+pas;newy=y;}    else if (dir==1) {newy=y-pas;newx=x;}
	    else if (dir==2) {newx=x-pas;newy=y;}   else if (dir==3) {newy=y+pas;newx=x;}
        if (getpixel(newx,newy)==c3 && getpixel(x,y)==c1)
		  { dir=interdit;
			 filldisc(x,y,1,c2);
			 uturn(x,y,dir);
			 if (dir==0) x+=pas;  else if (dir==1) y-=pas;   else if (dir==2) x-=pas; else if (dir==3) y+=pas;
		  }
		else
	     {	if (dir==olddir) {stroke(x,y,dir);   }
			else if(dir==(olddir+1)%4)  square(x,y,dir);
            else if (olddir==(dir+1)%4) rightangle(x,y,dir);
		    if (dir==0) x+=pas;  else if (dir==1) y-=pas;   else if (dir==2) x-=pas;   else if (dir==3) y+=pas;
	     }
   }

olddir=dir;
 SDL_Flip(screen);SDL_Delay(50);
  if (x==xd && y==yd)        { stroke(xd,yd,1); /**floodfill(xd-pas/4,yd+pas,red,red);
                                               filldisc(x-pas/4,y+pas,5,blue); */  break;}
  }
SDL_Flip(screen);pause();return 0;
}

void laby(void)
{rectangle(0,0,640,480,blue);
rectangle(xorig+pas,yorig-pas*3,xorig+pas*3,yorig-pas*6,blue);
floodfill(xorig+pas*2,yorig-pas*4,blue,blue);
rectangle(xorig+pas*1,yorig-pas*1,xorig+pas*9,yorig-pas*2,blue);
rectangle(xorig+pas*4,yorig-pas*2,xorig+pas*6,yorig-pas*4,blue);
line(xorig+pas*4+1,yorig-pas*2,xorig+pas*6-1,yorig-pas*2,white);
floodfill(xorig+pas*5,yorig-pas*2,blue,blue);
rectangle(xorig+pas*7,yorig-pas*3,xorig+pas*15,yorig-pas*4,blue);
rectangle(xorig+pas*10,yorig-pas*1,xorig+pas*12,yorig-pas*3,blue);
line(xorig+pas*10+1,yorig-pas*3,xorig+pas*12-1,yorig-pas*3,white);
floodfill(xorig+pas*11,yorig-pas*3,blue,blue);
rectangle(xorig+pas*13,yorig-pas*1,xorig+pas*21,yorig-pas*2,blue);
rectangle(xorig+pas*16,yorig-pas*2,xorig+pas*18,yorig-pas*4,blue);
line(xorig+pas*16+1,yorig-pas*2,xorig+pas*18-1,yorig-pas*2,white);
floodfill(xorig+pas*17,yorig-pas*2,blue,blue);
rectangle(xorig+pas*19,yorig-pas*3,xorig+pas*21,yorig-pas*6,blue);
floodfill(xorig+pas*20,yorig-pas*4,blue,blue);
rectangle(xorig+pas*4,yorig-pas*5,xorig+pas*9,yorig-pas*6,blue);
floodfill(xorig+pas*6,yorig-pas*5.5,blue,blue);
rectangle(xorig+pas*13,yorig-pas*5,xorig+pas*18,yorig-pas*6,blue);
floodfill(xorig+pas*15,yorig-pas*5.5,blue,blue);
rectangle(xorig+pas*7,yorig-pas*7,xorig+pas*15,yorig-pas*8,blue);
rectangle(xorig+pas*10,yorig-pas*5,xorig+pas*12,yorig-pas*7,blue);
line(xorig+pas*10+1,yorig-pas*7,xorig+pas*12-1,yorig-pas*7,white);
floodfill(xorig+pas*11,yorig-pas*7,blue,blue);
rectangle(xorig+pas*4,yorig-pas*7,xorig+pas*6,yorig-pas*10,blue);
floodfill(xorig+pas*5,yorig-pas*8.5,blue,blue);
rectangle(xorig+pas*7,yorig-pas*9,xorig+pas*15,yorig-pas*12,blue);
floodfill(xorig+pas*11,yorig-pas*10,blue,blue);
rectangle(xorig+pas*16,yorig-pas*7,xorig+pas*18,yorig-pas*10,blue);
floodfill(xorig+pas*17,yorig-pas*8.5,blue,blue);
rectangle(xorig+pas*4,yorig-pas*11,xorig+pas*6,yorig-pas*16,blue);
rectangle(xorig+pas*6,yorig-pas*13,xorig+pas*9,yorig-pas*14,blue);
line(xorig+pas*6,yorig-pas*13-1,xorig+pas*6,yorig-pas*14+1,white);
floodfill(xorig+pas*6,yorig-pas*13.5,blue,blue);
rectangle(xorig+pas*7,yorig-pas*15,xorig+pas*15,yorig-pas*16,blue);
rectangle(xorig+pas*10,yorig-pas*13,xorig+pas*12,yorig-pas*15,blue);
line(xorig+pas*10+1,yorig-pas*15,xorig+pas*12-1,yorig-pas*15,white);
floodfill(xorig+pas*11,yorig-pas*15,blue,blue);
rectangle(xorig+pas*13,yorig-pas*13,xorig+pas*16,yorig-pas*14,blue);
rectangle(xorig+pas*16,yorig-pas*11,xorig+pas*18,yorig-pas*16,blue);
line(xorig+pas*16,yorig-pas*13-1,xorig+pas*16,yorig-pas*14+1,white);
floodfill(xorig+pas*16,yorig-pas*13.5,blue,blue);
rectangle(xorig+pas*1,yorig-pas*14,xorig+pas*3,yorig-pas*16,blue);
floodfill(xorig+pas*2,yorig-pas*15,blue,blue);
rectangle(xorig+pas*19,yorig-pas*14,xorig+pas*21,yorig-pas*16,blue);
floodfill(xorig+pas*20,yorig-pas*15,blue,blue);
rectangle(xorig+pas*1,yorig-pas*17,xorig+pas*3,yorig-pas*19,blue);
floodfill(xorig+pas*2,yorig-pas*18,blue,blue);
rectangle(xorig+pas*19,yorig-pas*17,xorig+pas*21,yorig-pas*19,blue);
floodfill(xorig+pas*20,yorig-pas*18,blue,blue);
rectangle(xorig+pas*4,yorig-pas*17,xorig+pas*9,yorig-pas*19,blue);
floodfill(xorig+pas*6,yorig-pas*18,blue,blue);
rectangle(xorig+pas*14,yorig-pas*17,xorig+pas*18,yorig-pas*19,blue);
floodfill(xorig+pas*16,yorig-pas*18,blue,blue);
line(xorig,yorig-pas*13,xorig,yorig-pas*20,blue);
line(xorig,yorig-pas*13,xorig+pas*3,yorig-pas*13,blue);
line(xorig+pas*3,yorig-pas*13,xorig+pas*3,yorig-pas*7,blue);
line(xorig+pas*3,yorig-pas*7,xorig,yorig-pas*7,blue);
line(xorig,yorig-pas*7,xorig,yorig,blue);
line(xorig,yorig,xorig+pas*22,yorig,blue);
line(xorig+pas*22,yorig,xorig+pas*22,yorig-pas*7,blue);
line(xorig+pas*22,yorig-pas*7,xorig+pas*19,yorig-pas*7,blue);
line(xorig+pas*19,yorig-pas*7,xorig+pas*19,yorig-pas*13,blue);
line(xorig+pas*19,yorig-pas*13,xorig+pas*22,yorig-pas*13,blue);
line(xorig+pas*22,yorig-pas*13,xorig+pas*22,yorig-pas*20,blue);
line(xorig,yorig-pas*20,xorig+pas*10,yorig-pas*20,blue);
line(xorig+pas*13,yorig-pas*20,xorig+pas*22,yorig-pas*20,blue);
line(xorig+pas*13,yorig-pas*20,xorig+pas*13,yorig-pas*17,blue);
line(xorig+pas*10,yorig-pas*20,xorig+pas*10,yorig-pas*17,blue);
line(xorig+pas*10,yorig-pas*17,xorig+pas*11,yorig-pas*17,blue);
line(xorig+pas*11,yorig-pas*17,xorig+pas*11,yorig-pas*18,blue);
line(xorig+pas*11,yorig-pas*18,xorig+pas*12,yorig-pas*18,blue);
line(xorig+pas*12,yorig-pas*18,xorig+pas*12,yorig-pas*17,blue);
line(xorig+pas*12,yorig-pas*17,xorig+pas*13,yorig-pas*17,blue);
line(xorig+pas*12,yorig-pas*17,xorig+pas*13,yorig-pas*17,blue);
line(xorig+pas*13,yorig-pas*17,xorig+pas*13,yorig-pas*20,blue);
floodfill(10,10,blue,blue);
SDL_Flip(screen); pause();
}

void uturn(int x, int y,int d)
{
if (d==0)
  { rectangle(x-pas/4,y-pas/4,x+pas/2,y-pas/2,red);  floodfill(x+pas/8,y-3*pas/8,red,red);
    rectangle(x-pas/4,y+pas/4,x+pas/2,y+pas/2,red);   floodfill(x+pas/8,y+3*pas/8,red,red);
    rectangle(x-pas/2,y-pas/2,x-pas/4,y+pas/2,red);   floodfill(x-3*pas/8,y,red,red);
  }
else if (d==2)
  { rectangle(x+pas/4,y-pas/4,x-pas/2,y-pas/2,red);  floodfill(x-pas/8,y-3*pas/8,red,red);
    rectangle(x+pas/4,y+pas/4,x-pas/2,y+pas/2,red);  floodfill(x-pas/8,y+3*pas/8,red,red);
    rectangle(x+pas/2,y-pas/2,x+pas/4,y+pas/2,red);  floodfill(x+3*pas/8,y,red,red);
  }
else if (d==1)
  { rectangle(x-pas/4,y+pas/4,x-pas/2,y-pas/2,red);  floodfill(x-3*pas/8,y-pas/8,red,red);
    rectangle(x+pas/4,y+pas/4,x+pas/2,y-pas/2,red);   floodfill(x+3*pas/8,y-pas/8,red,red);
    rectangle(x-pas/2,y+pas/2,x+pas/2,y+pas/4,red);  floodfill(x,y+3*pas/8,red,red);
  }
else if (d==3)
  { rectangle(x-pas/4,y-pas/4,x-pas/2,y+pas/2,red);   floodfill(x-3*pas/8,y+pas/8,red,red);
    rectangle(x+pas/4,y-pas/4,x+pas/2,y+pas/2,red);  floodfill(x+3*pas/8,y+pas/8,red,red);
    rectangle(x-pas/2,y-pas/2,x+pas/2,y-pas/4,red);  floodfill(x,y-3*pas/8,red,red);
  }
}

void stroke(int x,int y,int d)
{
if (d==0)  { rectangle(x-pas/2,y-pas/2, x+pas/2,y-pas/4,red);
                  floodfill(x,y-3*pas/8,red,red);
                  line(x+pas/2,y-pas/4,x+pas/4,y,red); line(x+pas/4,y-pas/4,x+pas/4,y,red);
                  line(x+pas/2,y-pas/2,x+pas/4,y-3*pas/4,red); line(x+pas/4,y-pas/2,x+pas/4,y-3*pas/4,red);
                  }
else if (d==2)  { rectangle(x-pas/2,y+pas/2, x+pas/2,y+pas/4,red);
                       floodfill(x,y+3*pas/8,red,red);
                       line(x-pas/2,y+pas/2,x-pas/4,y+3*pas/4,red); line(x-pas/4,y+pas/2,x-pas/4,y,red);
                       line(x-pas/2,y+pas/4,x-pas/4,y,red); line(x-pas/4,y+pas/2,x-pas/4,y+3*pas/4,red);
                       }
else if (d==1) { rectangle(x-pas/2,y-pas/2, x-pas/4,y+pas/2,red);
                          floodfill(x-3*pas/8,y,red,red);
                          line(x-pas/4,y-pas/2,x,y-pas/4,red);line(x-pas/4,y-pas/4,x,y-pas/4,red);
                          line(x-pas/2,y-pas/2,x-3*pas/4,y-pas/4,red);line(x-3*pas/4,y-pas/4,x-pas/2,y-pas/4,red);
                          }
else if (d==3) { rectangle(x+pas/2,y-pas/2, x+pas/4,y+pas/2,red);
                        floodfill(x+3*pas/8,y,red,red);
                        line(x+pas/4,y+pas/2,x,y+pas/4,red);line(x+pas/4,y+pas/4,x,y+pas/4,red);
                        line(x+pas/2,y+pas/2,x+3*pas/4,y+pas/4,red);line(x+3*pas/4,y+pas/4,x+pas/2,y+pas/4,red);
                         }
}

void square(int x,int y, int d)
{
if (d==0) { rectangle(x+pas/4,y-pas/4,x+pas/2,y-pas/2,red); floodfill(x+3*pas/8,y-3*pas/8,red,red); }
else if (d==1) { rectangle(x-pas/4,y-pas/4,x-pas/2,y-pas/2,red);  floodfill(x-3*pas/8,y-3*pas/8,red,red);  }
else if (d==2) { rectangle(x-pas/4,y+pas/4,x-pas/2,y+pas/2,red); floodfill(x-3*pas/8,y+3*pas/8,red,red); }
else if (d==3) { rectangle(x+pas/4,y+pas/4,x+pas/2,y+pas/2,red); floodfill(x+3*pas/8,y+3*pas/8,red,red); }
}

void rightangle(int x,int y, int d)
{
if (d==0)
  { rectangle(x-pas/4,y-pas/4,x+pas/2,y-pas/2,red);  floodfill(x+pas/8,y-3*pas/8,red,red);
    rectangle(x-pas/4,y-pas/4,x-pas/2,y+pas/2,red);  floodfill(x-3*pas/8,y+pas/8,red,red);
    rectangle(x-pas/4,y-pas/4,x-pas/2,y-pas/2,red);  floodfill(x-3*pas/8,y-3*pas/8,red,red);
  }
else if (d==1)
  { rectangle(x-pas/4,y+pas/4,x-pas/2,y-pas/2,red);    floodfill(x-3*pas/8,y+pas/8,red,red);
    rectangle(x-pas/4,y+pas/4,x+pas/2,y+pas/2,red);   floodfill(x+pas/8,y+3*pas/8,red,red);
    rectangle(x-pas/4,y+pas/4,x-pas/2,y+pas/2,red);  floodfill(x-3*pas/8,y+3*pas/8,red,red);
  }
else if (d==2)
  { rectangle(x+pas/4,y+pas/4,x+pas/2,y-pas/2,red);  floodfill(x+3*pas/8,y-pas/8,red,red);
   rectangle(x+pas/4,y+pas/4,x-pas/2,y+pas/2,red);   floodfill(x-pas/8,y+3*pas/8,red,red);
    rectangle(x+pas/4,y+pas/4,x+pas/2,y+pas/2,red);  floodfill(x+3*pas/8,y+3*pas/8,red,red);
  }
else if (d==3)
  { rectangle(x+pas/4,y-pas/4,x-pas/2,y-pas/2,red);  floodfill(x-pas/8,y-3*pas/8,red,red);
    rectangle(x+pas/4,y-pas/4,x+pas/2,y+pas/2,red);  floodfill(x+3*pas/8,y+pas/8,red,red);
    rectangle(x+pas/4,y-pas/4,x+pas/2,y-pas/2,red);  floodfill(x+3*pas/8,y-3*pas/8,red,red);
  }
}

/****************************************/
void floodfill( int x,int y, Uint32 cr,Uint32 cb)
{   int xg,xd,xx;
    if (getpixel(x,y) !=cb && getpixel(x,y) !=cr)
    { putpixel(x,y,cr);
    xg=x-1;
    while(xg>0 && getpixel(xg,y)!=cb)  {putpixel(xg,y,cr); xg--;}
    xd=x+1;
    while(xd<800 && getpixel(xd,y)!=cb)  {putpixel(xd,y,cr); xd++ ;}
    for(xx=xg; xx<xd;xx++)
    { if (y>1 ) {floodfill(xx,y-1,cr,cb);}
       if (y<599 ) {floodfill(xx,y+1,cr,cb);}

    }
    }
}

void pause(void)
{
    SDL_Event evenement;
    do   SDL_WaitEvent(&evenement);
    while(evenement.type != SDL_QUIT && evenement.type != SDL_KEYDOWN);
}


void putpixel(int xe, int ye, Uint32 c)
{ Uint32 * numerocase;
numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;    *numerocase=c;
}

Uint32 getpixel(int xe, int ye)
{ Uint32 * numerocase;
   numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;   return (*numerocase);
}

void circle( int xo, int yo, int R, Uint32 c)
  {
      int x, y, F, F1, F2,newx,newy;
      x=xo; y=yo+R; F=0;
      if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,c);
      if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, c);
      while( y>yo)
         {
             F1=F+2*(x-xo)+1; F2=F-2*(y-yo)+1;
             if ( abs(F1)<abs(F2))  { x+=1; F=F1;}
             else {y-=1; F=F2;}
             if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,c);
              newx=2*xo-x ; newy=2*yo-y ;
             if (x<800 && x>=0 && newy>=0 && newy<600) putpixel(x, newy,c);
             if (newx<800 && newx>=0 && y>=0 && y<600) putpixel( newx,y,c);
             if (newx<800 && newx>=0 && newy>=0 && newy<600) putpixel(newx,
             newy, c);
         }
       if (xo+R<800 && xo+R>=0) putpixel(xo+R,yo,c);
       if (xo-R<800 && xo-R>=0) putpixel(xo-R,yo, c);
  }


void filldisc( int xo, int yo, int R, Uint32 c)
  {
      int x, y, F, F1, F2,newx,newy,xx;
      x=xo; y=yo+R; F=0;
      if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,c);
      if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, c);
      while( y>yo)
         {
             F1=F+2*(x-xo)+1; F2=F-2*(y-yo)+1;
             if ( abs(F1)<abs(F2))  { x+=1; F=F1;}
             else {y-=1; F=F2;}
             newx=2*xo-x ; newy=2*yo-y ;
             for(xx=newx; xx<=x; xx++)if (xx<800 && xx>=0 && y>=0 && y<600 )
             putpixel(xx,y,c);
             for(xx=newx; xx<=x; xx++)if (xx<800 && xx>=0 && newy>=0 && newy<600 )
             putpixel(xx,newy,c);
         }
       if (xo+R<800 && xo+R>=0&& y>=0 && y<600) putpixel(xo+R,yo,c);
       if (xo-R<800 && xo-R>=0&& y>=0 && y<600) putpixel(xo-R,yo, c);
  }
/**  ligne en marches d'escalier */
void line(int x0,int y0, int x1,int y1, Uint32 c)
{
int dx,dy,x,y,residu,absdx,absdy,pasx,pasy,i;
dx=x1-x0; dy=y1-y0;  residu=0;       x=x0;y=y0;  if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
if (dx>0) pasx=1;else pasx=-1; if (dy>0) pasy=1; else pasy=-1;
absdx=abs(dx);absdy=abs(dy);
if (dx==0) for(i=0;i<absdy;i++) { y+=pasy;
                                                    if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c); }
else if(dy==0) for(i=0;i<absdx;i++){ x+=pasx;
                                                         if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);  }
else if (absdx==absdy)
   for(i=0;i<absdx;i++) {x+=pasx; if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
                                     y+=pasy;
                                     if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
                                     }
else if (absdx>absdy)
          for(i=0;i<absdx;i++)
			  { x+=pasx; if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
			     residu+=absdy;
			     if(residu >= absdx) {residu -=absdx; y+=pasy;
	                              		        if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
			                                    }
			  }
else for(i=0;i<absdy;i++)
             {y+=pasy; if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
               residu +=absdx;
              if (residu>=absdy)   {residu -= absdy;x +=pasx;
                                              if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
                                             }
             }
}

void rectangle(int x1,int y1, int x2, int y2, Uint32 c)
{
    line(x1,y1,x2,y1,c);line(x1,y2,x2,y2,c);line(x1,y1,x1,y2,c);line(x2,y2,x2,y1,c);
}

