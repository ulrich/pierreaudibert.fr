/*************************    MAZE    ******************************/
/***********************       Fig. 30-11 ... 14          ********************/
#include <SDL/SDL.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <dos.h>
#define pas 8
#define L 74
#define nbpoints 30
void carre(int ii, int jj , int q, int c) ;
void pause(void);
void putpixel(int xe, int ye, Uint32 c);
Uint32 getpixel(int xe, int ye);
void circle( int xo, int yo, int R, Uint32 c);
void filldisc(int xo, int yo, int R,Uint32 c);
void line(int x0,int y0, int x1,int y1, Uint32 c);
void fleche(int x1, int y1, int x2, int y2, Uint32 c);
void linewithwidth(int x1, int y1, int x2, int y2, int width,Uint32 c);
void rectangle(int x0,int y0, int x1, int y1,int e,int col);
void floodfill( int x,int y, Uint32 cr,Uint32 cb);
SDL_Surface * ecran; Uint32 blanc,color[9];

int main(int argc, char ** argv)
{  int i,dir,x,y,xd,yd,dx,dy,c,hasard;int fini,icolor;
   int right,front,left,direction,newx,newy,dxdr,dydr,dxde,dyde,dxga,dyga,newdirection;
   SDL_Init(SDL_INIT_VIDEO);srand(time(NULL));
   ecran=SDL_SetVideoMode(800,600,32, SDL_HWSURFACE|SDL_DOUBLEBUF);
   blanc=SDL_MapRGB(ecran->format,255,255,255);
   color[0]=SDL_MapRGB(ecran->format,0,0,0);
   color[1]=SDL_MapRGB(ecran->format,255,0,0);
   color[4]=SDL_MapRGB(ecran->format,250,50,50);
   color[2]=SDL_MapRGB(ecran->format,0,250,0);
   color[5]=SDL_MapRGB(ecran->format,150,200,150);
   color[3]=SDL_MapRGB(ecran->format,0,0,250);
   color[6]=SDL_MapRGB(ecran->format,150,150,200);
   color[7]=SDL_MapRGB(ecran->format,255,255,0);
   color[8]=SDL_MapRGB(ecran->format,200,200,200);
   SDL_FillRect(ecran,0,blanc);
rectangle(0,0,pas*L,pas*L,1,color[0]);
SDL_Flip(ecran); pause();
for(c=0;c<nbpoints;c++)
    { x=rand()%(L-15)+10; y = rand()%(L-10)+5; putpixel(pas*x,pas*y,color[0]);   }

for(;;)
   {   fini=1;
       for(x=0;x<=L;x++) for(y=0;y<=L;y++) if (getpixel(pas*x,pas*y)!=color[0] )
          {fini=0; break;}
    do
      { x=rand()%(L+1);y=rand()%(L+1);
      }
    while(getpixel(pas*x,pas*y)==color[0] && fini==0);
    if (x==0)
     { dx=1;dy=0;
        if (getpixel(pas,pas*y)==0 && y>0 && y<L)
        linewithwidth(0,pas*y,pas,pas*y,1,color[0]);
     }
   else if (x==L && y>0 && y<L)
     { dx=-1;dy=0;
        if (getpixel(pas*x+pas*dx,pas*y+pas*dy)==color[0])
       linewithwidth(pas*x,pas*y,pas*x+pas*dx,pas*y+pas*dy,1,color[0]);
  }
else if (y==0 && x>0 && x<L)
  {dx=0;dy=1;
  if (getpixel(pas*x+pas*dx,pas*y+pas*dy)==color[0])
  linewithwidth(pas*x,pas*y,pas*x+pas*dx,pas*y+pas*dy,1,color[0]);
  }
else if (y==L && x>0 && x<L)
  {dx=0;dy=-1;
  if (getpixel(pas*x+pas*dx,pas*y+pas*dy)==color[0])
  linewithwidth(pas*x,pas*y,pas*x+pas*dx,pas*y+pas*dy,1,color[0]);
  }
else if (x>0 && y>0 && x<L && y<L)
  { i=1;
    do
      { i++;
        hasard=rand()%4;
        if (hasard==0 /* || hasard==1 || hasard==2 || hasard==3*/) dir=0;
        else if (hasard==1) dir=1;
        else if (hasard==2) dir=2;
        else if (hasard==3) dir=3;
        dx=((dir+1)%2)*(1-dir);dy=(dir%2)*(dir-2);
      }
    while(i<=5 && getpixel(pas*x+pas*dx,pas*y+pas*dy)!=color[0]);
    if (i<5) {  linewithwidth(pas*x,pas*y,pas*x+pas*dx,pas*y+pas*dy,1,color[0]); }
  if (fini==1) break;
  }
/**SDL_Flip(ecran);*/
}
SDL_Flip(ecran);pause();


rectangle(0,0,pas*L,pas*L,1,blanc);
icolor=1;
for(x=1;x<L;x++)  for(y=1;y<L;y++)
if (getpixel(pas*x,pas*y)==color[0])
{

floodfill(pas*x,pas*y,color[icolor],blanc);
icolor++;  if (icolor==9) icolor=1;
}
rectangle(0,0,pas*L,pas*L,1,color[0]);
SDL_Flip(ecran); pause();
/**************************  exploration    *******************************/
xd=pas/2;yd=pas/2;
x=xd;y=yd;direction=3;
carre(x,y,6,color[1]);
carre(pas*L-pas/2,pas*L-pas/2,6,color[4]);
for(;;)
{
right=(direction-1+4)%4;
dxdr=((right+1)%2)*(1-right);dydr=(right%2)*(right-2);
front=direction;
dxde=((front+1)%2)*(1-front);dyde=(front%2)*(front-2);
left=(direction+1)%4;
dxga=((left+1)%2)*(1-left);dyga=(left%2)*(left-2);

if (getpixel(x+pas*dxdr/2,y+pas*dydr/2)==blanc)
  { newx=x+pas*dxdr;newy=y+pas*dydr;newdirection=right; }
else if (getpixel(x+pas*dxde/2,y+pas*dyde/2)==blanc)
  { newx=x+pas*dxde;newy=y+pas*dyde;newdirection=front;}
else if (getpixel(x+pas/2*dxga,y+pas/2*dyga)==blanc)
  { newx=x+pas*dxga;newy=y+pas*dyga;newdirection=left;
 }
else {newx=x;newy=y; newdirection=(direction+2)%4; }

if (getpixel(newx,newy)==color[4]) break;
if (getpixel(newx,newy)==color[1])
  { carre(newx,newy,6,color[7]);/*SDL_Flip(ecran); pause(); */
     SDL_Flip(ecran); carre(x,y,6,blanc); }
else {  carre(newx,newy,6,color[7]);/*SDL_Flip(ecran); pause();*/ SDL_Flip(ecran); SDL_Delay(0);
           carre(x,y,6,color[1]); }
x=newx;y=newy; direction=newdirection;
}

for(x=1;x<L;x++) for(y=1;y<L;y++)  floodfill(pas*x,pas*y,color[0],blanc);
rectangle(0,0,pas*L,pas*L,1,color[0]);

for(x=0;x<L;x++)  for(y=0;y<L;y++)
if (getpixel(pas*x+pas/2,pas*y+pas/2)==color[1]
    || getpixel(pas*x+pas/2,pas*y+pas/2)==color[7]  || getpixel(pas*x+pas/2,pas*y+pas/2)==color[4] )
carre(pas*x+pas/2,pas*y+pas/2,3,color[1]);
SDL_Flip(ecran); pause();  return 0;
}

void rectangle(int x0,int y0, int x1, int y1,int e,int col)
{
    linewithwidth(x0,y0,x1,y0,e,col);
    linewithwidth(x0,y0,x0,y1,e,col);
    linewithwidth(x0,y1,x1,y1,e,col);
    linewithwidth(x1,y0,x1,y1,e,col);
}

void carre(int ii, int jj , int q,int c)
{
int i,j;
for(i=ii-pas/q;i<=ii+pas/q;i++)
for(j=jj-pas/q;j<=jj+pas/q;j++)
putpixel(i,j,c);
}

void pause(void)
{
    SDL_Event evenement;
    do   SDL_WaitEvent(&evenement);
    while(evenement.type != SDL_QUIT && evenement.type != SDL_KEYDOWN);
}

void putpixel(int xe, int ye, Uint32 c)
{ Uint32 * numerocase;
numerocase= (Uint32 *)(ecran->pixels)+xe+ye*ecran->w;    *numerocase=c;
}

Uint32 getpixel(int xe, int ye)
{ Uint32 * numerocase;
   numerocase= (Uint32 *)(ecran->pixels)+xe+ye*ecran->w;   return (*numerocase);
}


void linewithwidth(int x1, int y1, int x2, int y2, int width,Uint32 c)
{
int dx,dy;
float k,xf1,yf1,xf2,yf2,d,dx1,dy1,ndx1,ndy1,ndx2,ndy2,angle=M_PI/2.;
line(x1,y1,x2,y2,c);
dx=x2-x1; dy=y2-y1;       d=sqrt(dx*dx+dy*dy);
if (d!=0.)
{ dx1=(float)width*(float)dx/d; dy1=(float)width*(float)dy/d;
   ndx1=dx1*cos(angle)-dy1*sin(angle);
   ndy1=dx1*sin(angle)+dy1*cos(angle);
   ndx2=dx1*cos(-angle)-dy1*sin(-angle);
   ndy2=dx1*sin(-angle)+dy1*cos(-angle);
   for(k=0;k<=1.;k+=0.1/d)
   {
   xf1=(1.-k)*x1+k*x2; yf1=(1.-k)*y1+k*y2;
   xf2=xf1-ndx1; yf2=yf1-ndy1;  line(xf1,yf1,xf2,yf2,c);
   xf2=xf1-ndx2; yf2=yf1-ndy2;    line(xf1,yf1,xf2,yf2,c);
   }
}
}

void circle( int xo, int yo, int R, Uint32 c)
  {
      int x, y, F, F1, F2,newx,newy;
      x=xo; y=yo+R; F=0;
      if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,c);
      if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, c);
      while( y>yo)
         {
             F1=F+2*(x-xo)+1; F2=F-2*(y-yo)+1;
             if ( abs(F1)<abs(F2))  { x+=1; F=F1;}
             else {y-=1; F=F2;}
             if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,c);
              newx=2*xo-x ; newy=2*yo-y ;
             if (x<800 && x>=0 && newy>=0 && newy<600) putpixel(x, newy,c);
             if (newx<800 && newx>=0 && y>=0 && y<600) putpixel( newx,y,c);
             if (newx<800 && newx>=0 && newy>=0 && newy<600) putpixel(newx,
             newy, c);
         }
       if (xo+R<800 && xo+R>=0 && yo>=0 && yo<600) putpixel(xo+R,yo,c);
       if (xo-R<800 && xo-R>=0 && yo>=0 && yo<600) putpixel(xo-R,yo, c);
  }

void filldisc( int xo, int yo, int R, Uint32 c)
  {
      int x, y, F, F1, F2,newx,newy,xx;
      x=xo; y=yo+R; F=0;
      if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,c);
      if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, c);
      while( y>yo)
         {
             F1=F+2*(x-xo)+1; F2=F-2*(y-yo)+1;
             if ( abs(F1)<abs(F2))  { x+=1; F=F1;}
             else {y-=1; F=F2;}
             newx=2*xo-x ; newy=2*yo-y ;
             for(xx=newx; xx<=x; xx++)if (xx<800 && xx>=0 && y>=0 && y<600 )
             putpixel(xx,y,c);
             for(xx=newx; xx<=x; xx++)if (xx<800 && xx>=0 && newy>=0 && newy<600 )
             putpixel(xx,newy,c);
         }
       if (xo+R<800 && xo+R>=0&& y>=0 && y<600) putpixel(xo+R,yo,c);
       if (xo-R<800 && xo-R>=0&& y>=0 && y<600) putpixel(xo-R,yo, c);
  }
/**  ligne en marches d'escalier */
void line(int x0,int y0, int x1,int y1, Uint32 c)
{
int dx,dy,x,y,residu,absdx,absdy,pasx,pasy,i;
dx=x1-x0; dy=y1-y0;  residu=0;       x=x0;y=y0;  if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
if (dx>0) pasx=1;else pasx=-1; if (dy>0) pasy=1; else pasy=-1;
absdx=abs(dx);absdy=abs(dy);
if (dx==0) for(i=0;i<absdy;i++) { y+=pasy;
                                                    if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c); }
else if(dy==0) for(i=0;i<absdx;i++){ x+=pasx;
                                                         if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);  }
else if (absdx==absdy)
   for(i=0;i<absdx;i++) {x+=pasx; if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
                                     y+=pasy;
                                     if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
                                     }
else if (absdx>absdy)
          for(i=0;i<absdx;i++)
			  { x+=pasx; if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
			     residu+=absdy;
			     if(residu >= absdx) {residu -=absdx; y+=pasy;
	                              		        if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
			                                    }
			  }
else for(i=0;i<absdy;i++)
             {y+=pasy; if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
               residu +=absdx;
              if (residu>=absdy)   {residu -= absdy;x +=pasx;
                                              if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
                                             }
             }
}

void floodfill( int x,int y, Uint32 cr,Uint32 cb)
{   int xg,xd,xx;
    if (getpixel(x,y) !=cb && getpixel(x,y) !=cr)
    { putpixel(x,y,cr);
    xg=x-1;
    while(xg>0 && getpixel(xg,y)!=cb)  {putpixel(xg,y,cr); xg--;}
    xd=x+1;
    while(xd<800 && getpixel(xd,y)!=cb)  {putpixel(xd,y,cr); xd++ ;}
    for(xx=xg; xx<xd;xx++)
    { if (y>1 ) {floodfill(xx,y-1,cr,cb);}
       if (y<599 ) {floodfill(xx,y+1,cr,cb);}

    }
    }
}

