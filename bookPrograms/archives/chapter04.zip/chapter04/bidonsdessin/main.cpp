/**************          THREE CONTAINERS    (drawings)       **************/
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <stdio.h>
#include <math.h>
#define N  3
#define OUI 1
#define NON 0
void tree(int i,int level);
int belonginglistofpredecessors(int j, int i);
void dessin (int * cc);
void pause(void);
void putpixel(int xe, int ye, Uint32 couleur);
Uint32 getpixel(int xe, int ye);
void line(int x0,int y0, int x1,int y1, Uint32 c);
void linewithwidth(int x1, int y1, int x2, int y2, int width,Uint32 c);
int predecessor[100]; int max[N]={10,5,3};
int xorig,yorig,base=40,h=6,count;
SDL_Surface * screen, *rectangle; Uint32 white,black,red;
SDL_Surface *texte;  SDL_Rect position;TTF_Font *police=NULL;char chiffre[2000];
SDL_Color cblack={0,0,0};

int main(int argc, char ** argv)
{  SDL_Init(SDL_INIT_VIDEO);
    screen=SDL_SetVideoMode(800,600,32, SDL_HWSURFACE|SDL_DOUBLEBUF);
    white=SDL_MapRGB(screen->format,255,255,255);
    black=SDL_MapRGB(screen->format,0,0,0);
    red=SDL_MapRGB(screen->format,255,0,0);
    SDL_FillRect(screen,0,white);
    TTF_Init(); police=TTF_OpenFont("times.ttf",20);

    tree(10000*max[0],1);

    SDL_Flip(screen);pause(); TTF_CloseFont(police); TTF_Quit();  return 0;
}

void tree(int i,int level)
{ int j,k,ii;int ni; int c[N],r[N],ccc[N]; int nc[N],nr[N];
   c[0]=(int)(i/10000); r[0]=max[0]-c[0];
   c[1]=(int)(i/100)%100; r[1]=max[1]-c[1];
   c[2]=(int)(i%100); r[2]=max[2]-c[2];
   if (c[2]==2 )
    { xorig=20; yorig= max[0]*h+40; count++;
       sprintf( chiffre,"%d",count);
       texte=TTF_RenderText_Solid(police,chiffre,cblack);
       position.x=20; position.y=10;
       SDL_BlitSurface(texte,NULL,screen,&position);
       for (k=2;k<=level;k++)
          { ccc[0]= (int)(predecessor[k]/10000) ;  ccc[1]= (int)(predecessor[k]/100)%100;
             ccc[2]= (int)(predecessor[k]%100);    dessin(ccc);
          }
       dessin(c);
       pause(); SDL_FillRect(screen,0,white);
     }
   else for(j=0;j<N;j++)  for(k=0;k<N;k++)  if (k!=j)
   if (c[j]>0 && c[j]<=r[k])
     { nc[j]=0; nr[j]=max[j];   nr[k]=r[k]-c[j]; nc[k]=c[k]+c[j];
        for(ii=0;ii<N;ii++) if (ii!=j && ii!=k)   { nc[ii]=c[ii]; nr[ii]=r[ii];}
        ni= nc[0]*10000+nc[1]*100+nc[2];
        if (belonginglistofpredecessors(ni,level)==NON)
	             { predecessor[level+1]=i; tree(ni,level+1);}
     }
   else if (r[k]>0 && c[j]>=r[k])
     { nc[j]=c[j]-r[k]; nr[j]=r[j]+r[k];  nr[k]=0; nc[k]=max[k];
       for(ii=0;ii<N;ii++) if (ii!=j && ii!=k)   { nc[ii]=c[ii]; nr[ii]=r[ii];}
       ni= nc[0]*10000+nc[1]*100+ nc[2];
       if (belonginglistofpredecessors(ni,level)==NON)
                 { predecessor[level+1]=i; tree(ni,level+1);}
     }
}

int belonginglistofpredecessors(int j, int level)
{  int k;
    for(k=level;k>=2;k--)  if (j==predecessor[k]) return OUI;
    return NON;
}

void dessin (int * cc)
{  int xb1,xb2,xb3,height1,height2,height3,q; SDL_Rect position;
    xb1=xorig;  xb2=xb1+base+10; xb3=xb2+base+10;
    linewithwidth(xb1,yorig,xb1+base,yorig,1,black);
    linewithwidth(xb1,yorig,xb1,yorig-max[0]*h,1,black);
    linewithwidth(xb1+base,yorig,xb1+base,yorig-max[0]*h,1,black);   height1=cc[0];
    for(q=0;q<height1;q++)
      {  rectangle= SDL_CreateRGBSurface(SDL_DOUBLEBUF,base-4,h-2,32,0,0,0,0);
          position.x= xb1+2; position.y=yorig-4-q*h;
         SDL_FillRect(rectangle,NULL,red);
         SDL_BlitSurface(rectangle,NULL,screen,&position);
       }
    linewithwidth(xb2,yorig,xb2+base,yorig,1,black);
    linewithwidth(xb2,yorig,xb2,yorig-max[1]*h,1,black);
    linewithwidth(xb2+base,yorig,xb2+base,yorig-max[1]*h,1,black);   height2=cc[1];
    for(q=0;q<height2;q++)
      { rectangle= SDL_CreateRGBSurface(SDL_DOUBLEBUF,base-4,h-2,32,0,0,0,0);
         position.x= xb2+2; position.y=yorig-4-q*h;
         SDL_FillRect(rectangle,NULL,red);
         SDL_BlitSurface(rectangle,NULL,screen,&position);
       }
    linewithwidth(xb3,yorig,xb3+base,yorig,1,black);
    linewithwidth(xb3,yorig,xb3,yorig-max[2]*h,1,black);
    linewithwidth(xb3+base,yorig,xb3+base,yorig-max[2]*h,1,black);   height3=cc[2];
    for(q=0;q<height3;q++)
      { rectangle= SDL_CreateRGBSurface(SDL_HWSURFACE|SDL_DOUBLEBUF,base-4,h-2,32,0,0,0,0);
         position.x= xb3+2; position.y=yorig-4-q*h;
         SDL_FillRect(rectangle,NULL,red);
         SDL_BlitSurface(rectangle,NULL,screen,&position);
       }
    SDL_Flip(screen);
    SDL_FreeSurface(rectangle);
    xorig+=3*base +50;
    if (xorig>800-3*base-50) { xorig=20;   yorig+=max[0]*h+15;}
    if (yorig>600-max[0]*h-15)
           {  pause(); SDL_FillRect(screen,0,white); xorig=20; yorig=max[0]*h+10;}
}

void pause(void)
{  SDL_Event evenement;
    do   SDL_WaitEvent(&evenement);
    while(evenement.type != SDL_QUIT && evenement.type != SDL_KEYDOWN);
}


void putpixel(int xe, int ye, Uint32 couleur)
{ Uint32 * numerocase;
   numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;    *numerocase=couleur;
}

Uint32 getpixel(int xe, int ye)
{ Uint32 * numerocase;
   numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;   return (*numerocase);
}

void line(int x0,int y0, int x1,int y1, Uint32 c)
{
int dx,dy,x,y,residu,absdx,absdy,pasx,pasy,i;
dx=x1-x0; dy=y1-y0;  residu=0;       x=x0;y=y0;  putpixel(x,y,c);
if (dx>0) pasx=1;else pasx=-1; if (dy>0) pasy=1; else pasy=-1;
absdx=abs(dx);absdy=abs(dy);
if (dx==0) for(i=0;i<absdy;i++) { y+=pasy;
                                                    putpixel(x,y,c); }
else if(dy==0) for(i=0;i<absdx;i++){ x+=pasx;
                                                         putpixel(x,y,c);  }
else if (absdx==absdy)
   for(i=0;i<absdx;i++) {x+=pasx; y+=pasy;
                                     putpixel(x,y,c);
                                     }
else if (absdx>absdy)
          for(i=0;i<absdx;i++)
			  { x+=pasx; residu+=absdy;
			     if(residu >= absdx) {residu -=absdx; y+=pasy;}
			     putpixel(x,y,c);
			  }
else for(i=0;i<absdy;i++)
             {y+=pasy; residu +=absdx;
              if (residu>=absdy)   {residu -= absdy;x +=pasx;}
              putpixel(x,y,c);
             }
}

void linewithwidth(int x1, int y1, int x2, int y2, int width,Uint32 c)
{
int dx,dy;
float k,xf1,yf1,xf2,yf2,d,dx1,dy1,ndx1,ndy1,ndx2,ndy2,angle=M_PI/2.;
line(x1,y1,x2,y2,c);
dx=x2-x1; dy=y2-y1;       d=sqrt(dx*dx+dy*dy);
if (d!=0.)      /* si le vecteur n’est step nul */
{ dx1=(float)width*(float)dx/d; dy1=(float)width*(float)dy/d;
   ndx1=dx1*cos(angle)-dy1*sin(angle);
   ndy1=dx1*sin(angle)+dy1*cos(angle);
   ndx2=dx1*cos(-angle)-dy1*sin(-angle);
   ndy2=dx1*sin(-angle)+dy1*cos(-angle);
   for(k=0;k<=1.;k+=0.1/d)
   {
   xf1=(1.-k)*x1+k*x2; yf1=(1.-k)*y1+k*y2;
   xf2=xf1-ndx1; yf2=yf1-ndy1;  line(xf1,yf1,xf2,yf2,c);
   xf2=xf1-ndx2; yf2=yf1-ndy2;    line(xf1,yf1,xf2,yf2,c);
   }
}
}




