/**********         DOMINOES ON A RECTANGULAR GRID          ***********/
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define M 6
#define N 4          /** MN even */
#define MN (M*N)
#define step 15
#define pi 3.14159
int belonginglistofpredecessors(int x, int xx,int etage);
void explore(int x, int L);
void drawing(int etage);
void square(int x1,int x2);
void pause(void);
void putpixel(int xe, int ye, Uint32 couleur);
Uint32 getpixel(int xe, int ye);
void line(int x0,int y0, int x1,int y1, Uint32 c);
void linewithwidth(int x1, int y1, int x2, int y2, int width,Uint32 c);
int count, pred[MN];
int xorig=20;int yorig=50;
SDL_Surface * screen; Uint32 white,red,blue;
SDL_Surface *texte; SDL_Rect position;
TTF_Font *police=NULL;SDL_Color cblack={0,0,0};char chiffre[200];

int main(int argc, char ** argv)
{
   double cumul,F,cos1,cos2,cos12,cos22; int j,k;
   SDL_Init(SDL_INIT_VIDEO); TTF_Init();
   screen=SDL_SetVideoMode(800,600,32, SDL_HWSURFACE|SDL_DOUBLEBUF);
   white=SDL_MapRGB(screen->format,255,255,255);
   blue=SDL_MapRGB(screen->format,0,0,250);
   red=SDL_MapRGB(screen->format,255,0,0);
   SDL_FillRect(screen,0,white);
   police=TTF_OpenFont("times.ttf",20);
   sprintf( chiffre,"M*N =  %d*%d",M,N);
   texte=TTF_RenderText_Solid(police,chiffre,cblack);
   position.x=10; position.y=10;
   SDL_BlitSurface(texte,NULL,screen,&position);

   count=0;
   explore(1,1);
   explore(M,1);

    /** theoretical result  */
   cumul=1.;
   for(j=1;j<=M;j++)
   for(k=1;k<=N;k++)
     { cos1=cos((double)j*pi/((double)M+1.));
        cos2=cos((double)k*pi/((double)N+1.));
        cos12=cos1*cos1;cos22=cos2*cos2;
        F=cos12+cos22;
        cumul*=F;
      }
   cumul=sqrt(sqrt(cumul));  cumul=cumul*pow(2.,((double)M*(double)N/2.));
   sprintf( chiffre,"Number of tilings (theoretic and experimental)=  %3.0lf   %d",cumul,count);
   texte=TTF_RenderText_Solid(police,chiffre,cblack);
   position.x=30; position.y=550;
   SDL_BlitSurface(texte,NULL,screen,&position);

   SDL_Flip(screen); pause(); TTF_CloseFont(police); TTF_Quit();  return 0;
}

void explore(int x, int etage)
{ int i,nbsuccessor,x1,x2,newx1,newx2,successor[2];
   if (etage==MN/2)
    { count++;
       x1=x/MN;x2=x%MN;
       drawing(etage);
       square(x1,x2);
       xorig+=M*step+20; if (xorig>800-M*step) {yorig+=N*step+20; xorig=20;}
       if (yorig>600-N*step)  { SDL_Flip(screen); pause();  SDL_FillRect(screen,0,white);
                                             xorig=20; yorig=20;
                                          }
     }
   else
     { nbsuccessor=0;
        x1=x/MN;x2=x%MN;
        newx1=x1+1;
        if (newx1==x2) newx1++;
        while(belonginglistofpredecessors(newx1,x,etage)==1) newx1++;
        newx2=newx1+1;
        if (newx2%M!=0 && belonginglistofpredecessors(newx2,x,etage)==0)
          { successor[nbsuccessor]=newx1*MN+newx2;pred[etage+1]=x; nbsuccessor++;}
        if (newx1<MN-M)
          { newx2=newx1+M ;
             successor[nbsuccessor]=newx1*MN+newx2;pred[etage+1]=x;nbsuccessor++;
          }
        if(nbsuccessor>0)
        for(i=0;i<nbsuccessor;i++) explore(successor[i],etage+1);
      }
}

void drawing (int etage)
{ int x1,x2;
   if (etage>2) drawing(etage-1);
   x1=pred[etage]/MN;x2=pred[etage]%MN;
   square(x1,x2);
}

void square(int x1,int x2)
{ int xx1,yy1,xx2,yy2,i,j;
   xx1=x1%M;yy1=x1/M;
   xx2=x2%M;yy2=x2/M;
   if (x2==x1+1)
     { for(i=-step/2+2;i<=step/2;i++)
        for(j=-step/2+2;j<=step/2-2;j++)
        putpixel(xorig+step*xx1+i,yorig+step*yy1+j,blue);
        for(i=-step/2;i<=step/2-2;i++)
        for(j=-step/2+2;j<=step/2-2;j++)
        putpixel(xorig+step*xx2+i,yorig+step*yy2+j,blue);
      }
   if (x2==x1+M)
     { for(i=-step/2+2;i<=step/2-2;i++)
        for(j=-step/2+2;j<=step/2;j++)
        putpixel(xorig+step*xx1+i,yorig+step*yy1+j,blue);
        for(i=-step/2+2;i<=step/2-2;i++)
        for(j=-step/2;j<=step/2-2;j++)
        putpixel(xorig+step*xx2+i,yorig+step*yy2+j,blue);
     }
   linewithwidth(xorig+step*xx1, yorig+step*yy1, xorig+step*xx2, yorig+step*yy2,1, red);
}

int belonginglistofpredecessors(int x,int xx, int etage)
{ int xx1,xx2,k;
   xx1=xx/MN;xx2=xx%MN;
   if ( x==xx1 || x==xx2) return 1;
   for(k=etage;k>1;k--)
   if (x==pred[k]/MN || x==pred[k]%MN) return 1;
   return 0;
}

void pause(void)
{
    SDL_Event evenement;
    do   SDL_WaitEvent(&evenement);
    while(evenement.type != SDL_QUIT && evenement.type != SDL_KEYDOWN);
}

void putpixel(int xe, int ye, Uint32 couleur)
{ Uint32 * numerocase;
numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;    *numerocase=couleur;
}

Uint32 getpixel(int xe, int ye)
{ Uint32 * numerocase;
   numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;   return (*numerocase);
}

void linewithwidth(int x1, int y1, int x2, int y2, int width,Uint32 c)
{
int dx,dy;
float k,xf1,yf1,xf2,yf2,d,dx1,dy1,ndx1,ndy1,ndx2,ndy2,angle=M_PI/2.;
line(x1,y1,x2,y2,c);
dx=x2-x1; dy=y2-y1;       d=sqrt(dx*dx+dy*dy);
if (d!=0.)      /* si le vecteur n’est step nul */
{ dx1=(float)width*(float)dx/d; dy1=(float)width*(float)dy/d;
   ndx1=dx1*cos(angle)-dy1*sin(angle);
   ndy1=dx1*sin(angle)+dy1*cos(angle);
   ndx2=dx1*cos(-angle)-dy1*sin(-angle);
   ndy2=dx1*sin(-angle)+dy1*cos(-angle);
   for(k=0;k<=1.;k+=0.1/d)
   {
   xf1=(1.-k)*x1+k*x2; yf1=(1.-k)*y1+k*y2;
   xf2=xf1-ndx1; yf2=yf1-ndy1;  line(xf1,yf1,xf2,yf2,c);
   xf2=xf1-ndx2; yf2=yf1-ndy2;    line(xf1,yf1,xf2,yf2,c);
   }
}
}

void line(int x0,int y0, int x1,int y1, Uint32 c)
{
int dx,dy,x,y,residu,absdx,absdy,stepx,stepy,i;
dx=x1-x0; dy=y1-y0;  residu=0;       x=x0;y=y0;  putpixel(x,y,c);
if (dx>0) stepx=1;else stepx=-1; if (dy>0) stepy=1; else stepy=-1;
absdx=abs(dx);absdy=abs(dy);
if (dx==0) for(i=0;i<absdy;i++) { y+=stepy;
                                                    putpixel(x,y,c); }
else if(dy==0) for(i=0;i<absdx;i++){ x+=stepx;
                                                         putpixel(x,y,c);  }
else if (absdx==absdy)
   for(i=0;i<absdx;i++) {x+=stepx; y+=stepy;
                                     putpixel(x,y,c);
                                     }
else if (absdx>absdy)
          for(i=0;i<absdx;i++)
			  { x+=stepx; residu+=absdy;
			     if(residu >= absdx) {residu -=absdx; y+=stepy;}
			     putpixel(x,y,c);
			  }
else for(i=0;i<absdy;i++)
             {y+=stepy; residu +=absdx;
              if (residu>=absdy)   {residu -= absdy;x +=stepx;}
              putpixel(x,y,c);
             }
}







