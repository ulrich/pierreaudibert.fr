/****************         THREE CONTAINERS (text)         ******************/
#include <stdio.h>
#include <conio.h>
#define N  3
#define YES 1
#define NO 0
void tree(int i,int level);
int belonginglistofpredecessors(int j, int i);
int predecessor[100];
int number=0, time[500];
int max[N]={10,5,3};

main()
{ int l;
   tree(10000*max[0],1);
   printf("\n\n Time for each of the %d solutions: ",number);
   for(l=0;l<number;l++) printf("%d ",time[l]);
   getch(); return 0;
}


void tree(int i,int level)
{ int j,k,ii,iii;int ni; int c[N],r[N]; int nc[N],nr[N];
   c[0]=(int)(i/10000); r[0]=max[0]-c[0];
   c[1]=(int)(i/100)%100; r[1]=max[1]-c[1];
   c[2]=(int)(i%100); r[2]=max[2]-c[2];
   if (c[2]==2 )
     { number++; printf("\n%4.d: ",number);
        for (k=2;k<=level;k++)
        printf("(%d %d %d)",(int)(predecessor[k]/10000),(int)(predecessor[k]/100)%100,(int)(predecessor[k]%100));
        printf(" (%d %d %d)\n",(int)(i/10000),(int) (i/100)%100,(int)(i%100));
        time[number]=level;
     }
   else for(j=0;j<N;j++)  for(k=0;k<N;k++)  if (k!=j)
   if (c[j]>0 && c[j]<=r[k])
     { nc[j]=0; nr[j]=max[j];
        nr[k]=r[k]-c[j]; nc[k]=c[k]+c[j];
        for(ii=0;ii<N;ii++) if (ii!=j && ii!=k)
             { nc[ii]=c[ii]; nr[ii]=r[ii];}
        ni= nc[0]*10000+nc[1]*100+nc[2];
        if (belonginglistofpredecessors(ni,level)==NO)
	         { predecessor[level+1]=i; tree(ni,level+1);}
      }
   else if (r[k]>0 && c[j]>=r[k])
     { nc[j]=c[j]-r[k]; nr[j]=r[j]+r[k];
        nr[k]=0; nc[k]=max[k];
        for(ii=0;ii<N;ii++) if (ii!=j && ii!=k)
    	     { nc[ii]=c[ii]; nr[ii]=r[ii];}
        ni= nc[0]*10000+nc[1]*100+ nc[2];
        if (belonginglistofpredecessors(ni,level)==NO)
	         { predecessor[level+1]=i; tree(ni,level+1);}
     }
}

int belonginglistofpredecessors(int j, int level)
{ int k;
   for(k=level;k>=2;k--)  if (j==predecessor[k]) return YES;
   return NO;
}


