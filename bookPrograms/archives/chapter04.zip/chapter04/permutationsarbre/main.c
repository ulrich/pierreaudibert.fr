#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#define N 7
#define OUI 1
#define NON 0
void arbre(int noeud, int etage);
int appartientlistepredecesseurs(int v, int e);
int pred[N],compteur;

int main()
{   int i;
    for(i=0;i<N;i++)
    arbre(i,0);
    getch();return 0;
}
void arbre(int noeud, int etage)
{  int e,j;
    if (etage==N-1) {compteur++; printf( "%d : ",compteur);
                               for(e=1;e<N;e++) printf( "%d ", pred[e]);
                               printf("%d \n",noeud);
                             }
     else for(j=0;j<N;j++)
             if (j!=noeud && appartientlistepredecesseurs(j,etage)==NON)
              { pred[etage+1]=noeud; arbre(j,etage+1);
              }
}
int appartientlistepredecesseurs(int v, int e)
{  int et;
    for(et=1;et<=e;et++)
    if (v==pred[et]) return OUI;
    return NON;
}


