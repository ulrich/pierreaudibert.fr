
/********              SQUARES WITH VERTICES COLOURED
                                      WITH AT MOST TWO COLOURS.
                                      DIFFERENT SQUARES, REGARDLESS
                                          OF SYMETRIES OF SQUARE                     **********/

#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define pas 30
void carre (int xo, int yo);
void ncarre (int xo, int yo);
void rotationp (void);
void rotationm (void);
void rotationd (void);
void reflexh(void);
void reflexv(void);
void reflexd(void);
void reflexdd(void);
int different(void);
void pause(void);
void putpixel(int xe, int ye, Uint32 c);
Uint32 getpixel(int xe, int ye);
void line(int x0,int y0, int x1,int y1, Uint32 c);
void rectangle(int x1,int y1, int x2, int y2, Uint32 c);
void circle( int xo, int yo, int R, Uint32 couleur);
void filldisc(int xo, int yo, int R,Uint32 couleur);
SDL_Surface * screen; Uint32 white, color[3];
SDL_Surface *texte;  SDL_Rect position;TTF_Font *police=NULL;char chiffre[2000];
int newm[2][2],m[2][2],xorig,yorig,done[16],newnumber,count=0;

int main(int argc, char ** argv)
{  int L,C,number,q,k;
    SDL_Init(SDL_INIT_VIDEO);
   screen=SDL_SetVideoMode(800,600,32, SDL_HWSURFACE|SDL_DOUBLEBUF);
   white=SDL_MapRGB(screen->format,255,255,255);
   color[0]=SDL_MapRGB(screen->format,0,0,0);
   color[1]=SDL_MapRGB(screen->format,255,0,0);
   color[2]=SDL_MapRGB(screen->format,0,255,0);
   SDL_FillRect(screen,0,white);
   TTF_Init();  police=TTF_OpenFont("times.ttf",20);  SDL_Color cblack={0,0,0};
    xorig=50; yorig=100;
   for(number=0;number<16; number++)
   if (done[number]==0)
     { q=number;  done[number]=1; count++;
       for(L=0;L<2;L++)  for(C=0;C<2;C++)
         { m[L][C]=q%2; q=q/2;
         }
       k=0;
       sprintf( chiffre,"%d ",count);
       texte=TTF_RenderText_Solid(police,chiffre,cblack);
       position.x=xorig-30; position.y=yorig;
       SDL_BlitSurface(texte,NULL,screen,&position);
       carre(xorig,yorig); k++;
       rotationp(); if (done[newnumber]==0) {ncarre(xorig+60*(k++),yorig); done[newnumber]=1;  }
       rotationm(); if (done[newnumber]==0) {ncarre(xorig+60*(k++),yorig); done[newnumber]=1;  }
       rotationd(); if (done[newnumber]==0) {ncarre(xorig+60*(k++),yorig); done[newnumber]=1;  }
       reflexh();    if (done[newnumber]==0) {ncarre(xorig+60*(k++),yorig); done[newnumber]=1;  }
       reflexv();    if (done[newnumber]==0) {ncarre(xorig+60*(k++),yorig); done[newnumber]=1;  }
       reflexd();    if (done[newnumber]==0) {ncarre(xorig+60*(k++),yorig); done[newnumber]=1;  }
       reflexdd();  if (done[newnumber]==0) {ncarre(xorig+60*(k++),yorig); done[newnumber]=1;  }
       yorig+=60;
     }
   SDL_Flip(screen); pause();
   TTF_CloseFont(police); TTF_Quit();  return 0;
}


void carre (int xo, int yo)
{ int L,C;
   rectangle(xo,yo,xo+pas,yo+pas,color[0]);
  for(L=0;L<2;L++) for(C=0;C<2;C++)
  filldisc(xo+pas*C,yo+pas*L,5,color[m[L][C]+1]);
}

void ncarre (int xo, int yo)
{ int L,C;
  rectangle(xo,yo,xo+pas,yo+pas,color[0]);
  for(L=0;L<2;L++) for(C=0;C<2;C++)
  filldisc(xo+pas*C,yo+pas*L,5,color[newm[L][C]+1]);
}

void rotationp(void)
{ int L,C,f=1;
   newnumber=0;
   for(L=0;L<2;L++) for(C=0;C<2;C++)
      { newm[L][C]=m[C][2-1-L]; newnumber+=newm[L][C]*f; f=f*2;
      }
}

void rotationm(void)
{ int L,C, f=1;
   newnumber=0;
   for(L=0;L<2;L++) for(C=0;C<2;C++)
     { newm[L][C]=m[2-1-C][L]; newnumber+=newm[L][C]*f; f=f*2;
     }
}

void rotationd(void)
{ int L,C, f=1;
   newnumber=0;
   for(L=0;L<2;L++) for(C=0;C<2;C++)
     { newm[L][C]=m[2-1-L][2-1-C]; newnumber+=newm[L][C]*f; f=f*2;
     }
}

void reflexh(void)
{ int L,C,f=1;
   newnumber=0;
   for(L=0;L<2;L++) for(C=0;C<2;C++)
     { newm[L][C]=m[2-1-L][C];     newnumber+=newm[L][C]*f; f=f*2;
     }
}

void reflexv(void)
{ int L,C,f=1;
   newnumber=0;
   for(L=0;L<2;L++) for(C=0;C<2;C++)
     { newm[L][C]=m[L][2-1-C];     newnumber+=newm[L][C]*f; f=f*2;
     }
}

void reflexd(void)
{ int L,C,f=1;
   newnumber=0;
   for(L=0;L<2;L++) for(C=0;C<2;C++)
     { newm[L][C]=m[C][L];         newnumber+=newm[L][C]*f; f=f*2;
     }
}

void reflexdd(void)
{ int L,C, f=1;
   newnumber=0;
   for(L=0;L<2;L++) for(C=0;C<2;C++)
     { newm[L][C]=m[2-1-C][2-1-L]; newnumber+=newm[L][C]*f; f=f*2;
     }
}

void pause(void)
{
    SDL_Event evenement;
    do   SDL_WaitEvent(&evenement);
    while(evenement.type != SDL_QUIT && evenement.type != SDL_KEYDOWN);
}


void putpixel(int xe, int ye, Uint32 couleur)
{ Uint32 * numerocase;
numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;    *numerocase=couleur;
}

Uint32 getpixel(int xe, int ye)
{ Uint32 * numerocase;
   numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;   return (*numerocase);
}

void circle( int xo, int yo, int R, Uint32 couleur)
  {
      int x, y, F, F1, F2,newx,newy;
      x=xo; y=yo+R; F=0;
      if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
      if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, couleur);
      while( y>yo)
         {
             F1=F+2*(x-xo)+1; F2=F-2*(y-yo)+1;
             if ( abs(F1)<abs(F2))  { x+=1; F=F1;}
             else {y-=1; F=F2;}
             if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
              newx=2*xo-x ; newy=2*yo-y ;
             if (x<800 && x>=0 && newy>=0 && newy<600) putpixel(x, newy,couleur);
             if (newx<800 && newx>=0 && y>=0 && y<600) putpixel( newx,y,couleur);
             if (newx<800 && newx>=0 && newy>=0 && newy<600) putpixel(newx,
             newy, couleur);
         }
       if (xo+R<800 && xo+R>=0) putpixel(xo+R,yo,couleur);
       if (xo-R<800 && xo-R>=0) putpixel(xo-R,yo, couleur);
  }

  void filldisc( int xo, int yo, int R, Uint32 couleur)
  {
      int x, y, F, F1, F2,newx,newy,xx;
      x=xo; y=yo+R; F=0;
      if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
      if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, couleur);
      while( y>yo)
         {
             F1=F+2*(x-xo)+1; F2=F-2*(y-yo)+1;
             if ( abs(F1)<abs(F2))  { x+=1; F=F1;}
             else {y-=1; F=F2;}
             newx=2*xo-x ; newy=2*yo-y ;
             for(xx=newx; xx<=x; xx++)if (xx<800 && xx>=0 && y>=0 && y<600 )
             putpixel(xx,y,couleur);
             for(xx=newx; xx<=x; xx++)if (xx<800 && xx>=0 && newy>=0 && newy<600 )
             putpixel(xx,newy,couleur);
         }
       if (xo+R<800 && xo+R>=0&& y>=0 && y<600) putpixel(xo+R,yo,couleur);
       if (xo-R<800 && xo-R>=0&& y>=0 && y<600) putpixel(xo-R,yo, couleur);
  }

void line(int x0,int y0, int x1,int y1, Uint32 c)
{
int dx,dy,x,y,residu,absdx,absdy,stepx,stepy,i;
dx=x1-x0; dy=y1-y0;  residu=0;       x=x0;y=y0;  putpixel(x,y,c);
if (dx>0) stepx=1;else stepx=-1; if (dy>0) stepy=1; else stepy=-1;
absdx=abs(dx);absdy=abs(dy);
if (dx==0) for(i=0;i<absdy;i++) { y+=stepy;
                                                    putpixel(x,y,c); }
else if(dy==0) for(i=0;i<absdx;i++){ x+=stepx;
                                                         putpixel(x,y,c);  }
else if (absdx==absdy)
   for(i=0;i<absdx;i++) {x+=stepx; y+=stepy;
                                     putpixel(x,y,c);
                                     }
else if (absdx>absdy)
          for(i=0;i<absdx;i++)
			  { x+=stepx; residu+=absdy;
			     if(residu >= absdx) {residu -=absdx; y+=stepy;}
			     putpixel(x,y,c);
			  }
else for(i=0;i<absdy;i++)
             {y+=stepy; residu +=absdx;
              if (residu>=absdy)   {residu -= absdy;x +=stepx;}
              putpixel(x,y,c);
             }
}

void rectangle(int x1,int y1, int x2, int y2, Uint32 c)
{
    line(x1,y1,x2,y1,c);line(x1,y2,x2,y2,c);line(x1,y1,x1,y2,c);line(x2,y2,x2,y1,c);
}

