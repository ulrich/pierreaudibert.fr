
/**  pawns in red */

#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>
#define N 16   /**  N = length*length */
#define length 4
#define NP  8     /** pawns number */
#define pas 9
void carre (int x, int y, int c,int xo, int yo);
void visit(int x,int y);
void rotationp (void);
void rotationm (void);
void rotationd (void);
void reflexh(void);
void reflexv(void);
void reflexd(void);
void reflexdd(void);
void pause(void);
void putpixel(int xe, int ye, Uint32 c);
Uint32 getpixel(int xe, int ye);
SDL_Surface * screen; Uint32 white, color[3];
SDL_Surface *texte;  SDL_Rect position;TTF_Font *police=NULL;char chiffre[2000];
int newm[length][length],m[length][length],xorig=3,yorig=7;
int newn,f,done[length][length],nbcarres;

int main(int argc, char ** argv)
{  int k,j, i,L,C, count,c=0;
    int a[13000],number,q;int aux,g,d,pospivot,b[N],x,y,flag;
    SDL_Init(SDL_INIT_VIDEO);
   screen=SDL_SetVideoMode(800,600,32, SDL_HWSURFACE|SDL_DOUBLEBUF);
   white=SDL_MapRGB(screen->format,255,255,255);
   color[0]=SDL_MapRGB(screen->format,0,0,0);
   color[2]=SDL_MapRGB(screen->format,255,0,0);
   color[1]=SDL_MapRGB(screen->format,0,255,0);
   SDL_FillRect(screen,0,white);
   TTF_Init();  police=TTF_OpenFont("times.ttf",20);  SDL_Color cblack={0,0,0};

   for(j=0;j<N;j++) if (j<N-NP) b[j]=0; else b[j]=1; k=0;
   for(;;)
     { number=0;f=1;
        for(j=0;j<N;j++) {number+=b[j]*f; f=2*f;}
        a[k++]=number;
        j=N-1; while (j>=1 && !(b[j]==1  && b[j-1]==0)) j--;
        pospivot=j-1; if (pospivot==-1) break;
        b[pospivot]=1; b[pospivot+1]=0;
        g=pospivot+2;d=N-1; while(g<d) {aux=b[g];b[g]=b[d];b[d]=aux;g++;d--;}
     }

   for(i=0;i<k;i++)  if (a[i]!=0)
     { q=a[i];
        for(L=0;L<length;L++) for(C=0;C<length;C++)
           { m[L][C]=q%2;q=q/2;   }

         rotationp();
         for(j=i+1;j<k;j++) if (newn==a[j]) {a[j]=0; c++;  break;}
         rotationm();
         for(j=i+1;j<k;j++) if (newn==a[j]) {a[j]=0;c++; break;}
         rotationd();
         for(j=i+1;j<k;j++) if (newn==a[j]) {a[j]=0;c++; break;}
         reflexh();
         for(j=i+1;j<k;j++) if (newn==a[j]) {a[j]=0;c++; break;}
         reflexv();
         for(j=i+1;j<k;j++) if (newn==a[j]) {a[j]=0;c++; break;}
         reflexd();
         for(j=i+1;j<k;j++) if (newn==a[j]) {a[j]=0;c++; break;}
         reflexdd();
         for(j=i+1;j<k;j++) if (newn==a[j]) {a[j]=0;c++; break;}
      }
   count=0;
   for(i=0;i<k;i++) if (a[i]!=0)
     { q=a[i];
        for(L=0;L<length;L++) for(C=0;C<length;C++)
             { m[L][C]=q%2;q=q/2;}
        for(L=0;L<length;L++) for(C=0;C<length;C++)
        carre(C,L,color[m[L][C]+1],xorig,yorig);
        for(L=0;L<length;L++)  for(C=0;C<length;C++)
        if (getpixel(xorig+pas*C+pas/2,yorig+pas*L+pas/2)==color[2])
          { x=C;y=L;
             L=length;C=length;
          }
       for(L=0;L<length;L++) for(C=0;C<length;C++) done[C][L]=0;
       nbcarres=0;
       visit(x,y);
       flag=0;
       if (nbcarres!=NP)
         { for(L=0;L<length;L++) for(C=0;C<length;C++)  carre(C,L,white,xorig,yorig);
            flag=1;
         }
      if (flag==0)
        {  count++;
            xorig+=pas*length+10; if (xorig>800-pas*length) {xorig=3; yorig+=pas*length+10; }
            if (yorig>600-pas*length) { SDL_Flip(screen); pause(); SDL_FillRect(screen,0,white);
                                                      xorig=3;yorig=7;
                                                   }
        }
     }
   sprintf( chiffre,"Chessboard %d x %d, with %d pawns. Number of connected configurations: %d ",length,length,NP,count);
   texte=TTF_RenderText_Solid(police,chiffre,cblack);
   position.x=20; position.y=570;
   SDL_BlitSurface(texte,NULL,screen,&position);
   SDL_Flip(screen); pause();
   TTF_CloseFont(police); TTF_Quit();  return 0;
}

void carre (int x, int y, int c, int xo, int yo)
{ int i,j;
   for(i=pas*x;i<pas*(x+1);i++) for(j=pas*y;j<pas*(y+1);j++)
   putpixel(xo+i,yo+j,c);
}

void visit(int x,int y)
{
int i,neighborx,neighbory;
done[x][y]=1; nbcarres++;
for(i=0;i<4;i++)
{
if (i==0) {neighborx=x+1; neighbory=y; }
else if (i==1) {neighborx=x; neighbory=y-1; }
else if (i==2) {neighborx=x-1; neighbory=y; }
else if (i==3) {neighborx=x; neighbory=y+1; }

if (getpixel(xorig+pas*neighborx+pas/2,yorig+pas*neighbory+pas/2)==color[2] && done[neighborx][neighbory]==0)
visit(neighborx,neighbory);
}
}

void rotationp(void)
{ int L,C;f=1; newn=0;
  for(L=0;L<length;L++) for(C=0;C<length;C++)
      { newm[L][C]=m[C][length-1-L]; newn+=newm[L][C]*f; f=2*f; }
}

void rotationm(void)
{ int L,C;f=1; newn=0;
   for(L=0;L<length;L++)for(C=0;C<length;C++)
      { newm[L][C]=m[length-1-C][L]; newn+=newm[L][C]*f; f=2*f;}
}

void rotationd(void)
{ int L,C;f=1; newn=0;
   for(L=0;L<length;L++)for(C=0;C<length;C++)
      {newm[L][C]=m[length-1-L][length-1-C]; newn+=newm[L][C]*f; f=2*f;}
}

void reflexh(void)
{ int L,C;f=1; newn=0;
   for(L=0;L<length;L++)for(C=0;C<length;C++)
     {newm[L][C]=m[length-1-L][C];    newn+=newm[L][C]*f; f=2*f;}
}

void reflexv(void)
{ int L,C;f=1; newn=0;
   for(L=0;L<length;L++)for(C=0;C<length;C++)
     {newm[L][C]=m[L][length-1-C];    newn+=newm[L][C]*f; f=2*f;}
}

void reflexd(void)
{ int L,C;f=1; newn=0;
   for(L=0;L<length;L++)for(C=0;C<length;C++)
      {newm[L][C]=m[C][L];     newn+=newm[L][C]*f; f=2*f;}
}

void reflexdd(void)
{ int L,C;f=1; newn=0;
  for(L=0;L<length;L++) for(C=0;C<length;C++)
    {newm[L][C]=m[length-1-C][length-1-L]; newn+=newm[L][C]*f; f=2*f;}
}
void pause(void)
{
    SDL_Event evenement;
    do   SDL_WaitEvent(&evenement);
    while(evenement.type != SDL_QUIT && evenement.type != SDL_KEYDOWN);
}


void putpixel(int xe, int ye, Uint32 couleur)
{ Uint32 * numerocase;
numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;    *numerocase=couleur;
}

Uint32 getpixel(int xe, int ye)
{ Uint32 * numerocase;
   numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;   return (*numerocase);
}
