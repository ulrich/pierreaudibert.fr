/**********    NECKLACES WITH SEVERAL KINDS OF PEARLS       *********/
/**  N pearls with NBletters kinds of pearls :  NB[0] with colour 1, NB[1] with colour 2,
       etc.
       Drawings of necklaces regardless of rotations.
       Then regardless of symmetries.
       Then, among them, drawings of self symmetric necklaces */

/** here, N=7 pearls, and three kinds of pearls (NB[0]=1 with colour 1,
      NB[1]=2 with colour 2,  NB[2]=2 with colour 3) */

#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define NO 0
#define YES 1
#define RR 25.   /** radius of necklaces */
#define rr 3.
#define NBletters 3
void pause(void);
void putpixel(int xe, int ye, Uint32 couleur);
Uint32 getpixel(int xe, int ye);
void circle( int xo, int yo, int R, Uint32 couleur);
void filldisc(int xo, int yo, int R,Uint32 couleur);
SDL_Surface * screen; Uint32 white, color[4];
SDL_Surface *texte;  SDL_Rect position;TTF_Font *police=NULL;char chiffre[2000];
int NB[NBletters],done[50000],N,nbc; int a[20],b[50000],count;

int main(int argc, char ** argv)
{  int letter,i,k,pospivot,possubstitute,aux,g,d,n,numberanag,q;
   int head,r[20],nbd,powerP;int xc,yc; float angle;int fflag,flag;

   SDL_Init(SDL_INIT_VIDEO);
   screen=SDL_SetVideoMode(800,600,32, SDL_HWSURFACE|SDL_DOUBLEBUF);
   white=SDL_MapRGB(screen->format,255,255,255);
   color[0]=SDL_MapRGB(screen->format,0,0,0);
   color[1]=SDL_MapRGB(screen->format,255,0,0);
   color[2]=SDL_MapRGB(screen->format,0,255,0);
   color[3]=SDL_MapRGB(screen->format,0,0,250);
   SDL_FillRect(screen,0,white);
    TTF_Init(); police=TTF_OpenFont("times.ttf",20); SDL_Color couleurnoire={0,0,0};

   /**NB[0]=5;NB[1]=5;  (NBletters = 2)     */
    NB[0]=1;NB[1]=4;  NB[2]=2; /** may be changed */
   N=0;for(letter=0;letter<NBletters;letter++) N+=NB[letter];

   sprintf( chiffre," Necklaces with %d pearls: %d red, %d green, %d blue",N,NB[0],NB[1],NB[2]);
   /** must be modified if NBletters !=3  */
    texte=TTF_RenderText_Solid(police,chiffre,couleurnoire);
    position.x=20; position.y=10;
    SDL_BlitSurface(texte,NULL,screen,&position);

   q=0;
   for(letter=0;letter<NBletters;letter++)   for(i=0;i<NB[letter];i++)
    a[q++]=letter;
   count=0;
   for(;;)
     {  powerP=1;nbd=0;
        for(k=0;k<N;k++) {nbd+=a[k]*powerP; powerP*=NBletters;}
        b[count]=nbd;
        k=N-1;    while (a[k]<=a[k-1] && k>=1) k--;
        pospivot=k-1;   if (pospivot==-1) break;
        k=N-1;   while(a[k]<=a[pospivot]) k--;   possubstitute=k;
        aux=a[pospivot];a[pospivot]=a[possubstitute];a[possubstitute]=aux;
        g=pospivot+1;d=N-1;  while(g<d)    { aux=a[g]; a[g]=a[d]; a[d]=aux;g++; d--;}
        count++;
     }
    numberanag=count+1;

    /** necklaces, regardless of rotations */
    sprintf( chiffre," Different necklaces regardless of rotations");
    texte=TTF_RenderText_Solid(police,chiffre,couleurnoire);
    position.x=20; position.y=35;
    SDL_BlitSurface(texte,NULL,screen,&position);
    for(n=0; n<numberanag;n++)  done[n]=NO;
   for(n=0;n<numberanag;n++)  if(done[n]==NO)
     { q=b[n];
        for(k=0;k<N;k++) {r[k]=q%NBletters; q=q/NBletters;}
        for(head=1;head<N;head++)
          { nbd=0;powerP=1;
             for(k=0;k<N;k++) {nbd+=(r[(head+k)%N])*( int)powerP; powerP*=NBletters;}
             for(k=n+1;k<numberanag;k++) if (b[k]==nbd) {done[k]=YES; break;}
          }
      }
   xc=RR+10; yc=RR+80;
   for(k=0;k<numberanag;k++) if (done[k]==NO)
     { circle(xc,yc,RR,color[0]);
        q=b[k]; for(i=0;i<N;i++)  {r[i]=q%NBletters; q=q/NBletters;}
        angle=0.;
        for(i=0;i<N;i++)
          { filldisc(xc+RR*cos(angle),yc-RR*sin(angle),rr+2*r[i],color[r[i]+1]);
             angle+=2.*M_PI/(float)N;
          }
        xc+=2*RR+30; if (xc>750) {xc=RR+10;yc+=2*RR+30;}
        if (yc>600-2*RR) { SDL_Flip(screen);  pause(); SDL_FillRect(screen,0,white);  xc=RR+30; yc=RR+30;}
     }
   SDL_Flip(screen);pause(); SDL_FillRect(screen,0,white);

   /** necklaces, regardless of symmetries (rotations and reflexions */
   sprintf( chiffre," Different necklaces regardless of symmetries (rotations, reflections)");
    texte=TTF_RenderText_Solid(police,chiffre,couleurnoire);
    position.x=20; position.y=10;
    SDL_BlitSurface(texte,NULL,screen,&position);
   for(n=0; n<numberanag;n++)  done[n]=NO;
   for(n=0;n<numberanag;n++)  if(done[n]==NO)
     { q=b[n];
        for(k=0;k<N;k++) {r[k]=q%NBletters; q=q/NBletters;}
        for(head=1;head<N;head++)
          { nbd=0;powerP=1;
             for(k=0;k<N;k++) {nbd+=(r[(head+k)%N])*( int)powerP; powerP*=NBletters;}
             for(k=n+1;k<numberanag;k++) if (b[k]==nbd) {done[k]=YES; break;}
          }
        for(head=0;head<N;head++)
         { nbd=0;powerP=1;
            for(k=0;k<N;k++) {nbd+=(r[(head+N-k)%N])*powerP; powerP*=NBletters;}
            for(k=n+1;k<numberanag;k++) if (b[k]==nbd) {done[k]=YES; break;}
          }
      }
   xc=RR+10; yc=RR+50;
   for(k=0;k<numberanag;k++) if (done[k]==NO)
     { circle(xc,yc,RR,color[0]);
        q=b[k]; for(i=0;i<N;i++)  {r[i]=q%NBletters; q=q/NBletters;}
        angle=0.;
        for(i=0;i<N;i++)
          { filldisc(xc+RR*cos(angle),yc-RR*sin(angle),rr+2*r[i],color[r[i]+1]);
             angle+=2.*M_PI/(float)N;
          }
       xc+=2*RR+30; if (xc>750) {xc=RR+10;yc+=2*RR+30;}
       if (yc>600-2*RR) { SDL_Flip(screen);  pause(); SDL_FillRect(screen,0,white);  xc=RR+30; yc=RR+30;}
    }
SDL_Flip(screen);pause(); SDL_FillRect(screen,0,white);

/*********    self-symetric  necklaces   ****************/
    sprintf( chiffre," Self symmetric necklaces");
    texte=TTF_RenderText_Solid(police,chiffre,couleurnoire);
    position.x=20; position.y=10;
    SDL_BlitSurface(texte,NULL,screen,&position);

   xc=RR+10;yc=RR+50;  nbc=0;
   for(k=0;k<numberanag;k++) if (done[k]==NO)
     { if (N%2==1)
         { for(head=0;head<N;head++)
              { flag=YES;
                 q=b[k]; for(i=0;i<N;i++)  {r[i]=q%NBletters; q=q/NBletters;}
                 for(i=1;i<=(N-1)/2;i++) if (r[(head+N-i)%N]!=r[(head+i)%N]) {flag=NO; break;}
                 if (flag==YES) break;
              }
          }
       else
         { for(head=0;head<=(N-2)/2;head++)
             { flag=YES; fflag=YES;
                q=b[k]; for(i=0;i<N;i++)  {r[i]=q%NBletters; q=q/NBletters;}
                for(i=1;i<=(N-2)/2;i++) if (r[(head+N-i)%N]!=r[(head+i)%N]) {flag=NO; break;}
                if (flag==YES) break;
               for(i=0;i<=N/2;i++) if (r[(head+N-i+1)%N]!=r[(head+i)%N]) {fflag=NO; break;}
               if (fflag==YES) break;
            }
         }
      if (flag==YES || fflag==YES)
        { circle(xc,yc,RR,color[0]);
           q=b[k]; for(i=0;i<N;i++)  {r[i]=q%NBletters; q=q/NBletters;}
           angle=0.;
           for(i=0;i<N;i++)
             { filldisc(xc+RR*cos(angle),yc-RR*sin(angle),rr+2*r[i],color[r[i]+1]);
                angle+=2.*M_PI/(float)N;
             }
           xc+=2*RR+30; if (xc>580) {xc=RR+10;yc+=2*RR+30;}
         }
      }
   SDL_Flip(screen);pause(); TTF_CloseFont(police); TTF_Quit();  return 0;
}

void pause(void)
{
    SDL_Event evenement;
    do   SDL_WaitEvent(&evenement);
    while(evenement.type != SDL_QUIT && evenement.type != SDL_KEYDOWN);
}

void putpixel(int xe, int ye, Uint32 couleur)
{ Uint32 * numerocase;
numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;    *numerocase=couleur;
}

Uint32 getpixel(int xe, int ye)
{ Uint32 * numerocase;
   numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;   return (*numerocase);
}

void circle( int xo, int yo, int R, Uint32 couleur)
  {
      int x, y, F, F1, F2,newx,newy;
      x=xo; y=yo+R; F=0;
      if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
      if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, couleur);
      while( y>yo)
         {
             F1=F+2*(x-xo)+1; F2=F-2*(y-yo)+1;
             if ( abs(F1)<abs(F2))  { x+=1; F=F1;}
             else {y-=1; F=F2;}
             if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
              newx=2*xo-x ; newy=2*yo-y ;
             if (x<800 && x>=0 && newy>=0 && newy<600) putpixel(x, newy,couleur);
             if (newx<800 && newx>=0 && y>=0 && y<600) putpixel( newx,y,couleur);
             if (newx<800 && newx>=0 && newy>=0 && newy<600) putpixel(newx,
             newy, couleur);
         }
       if (xo+R<800 && xo+R>=0 && yo>=0 && yo<600) putpixel(xo+R,yo,couleur);
       if (xo-R<800 && xo-R>=0 && yo>=0 && yo<600) putpixel(xo-R,yo, couleur);
  }

void filldisc( int xo, int yo, int R, Uint32 couleur)
  {
      int x, y, F, F1, F2,newx,newy,xx;
      x=xo; y=yo+R; F=0;
      if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
      if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, couleur);
      while( y>yo)
         {
             F1=F+2*(x-xo)+1; F2=F-2*(y-yo)+1;
             if ( abs(F1)<abs(F2))  { x+=1; F=F1;}
             else {y-=1; F=F2;}
             newx=2*xo-x ; newy=2*yo-y ;
             for(xx=newx; xx<=x; xx++)if (xx<800 && xx>=0 && y>=0 && y<600 )
             putpixel(xx,y,couleur);
             for(xx=newx; xx<=x; xx++)if (xx<800 && xx>=0 && newy>=0 && newy<600 )
             putpixel(xx,newy,couleur);
         }
       if (xo+R<800 && xo+R>=0&& y>=0 && y<600) putpixel(xo+R,yo,couleur);
       if (xo-R<800 && xo-R>=0&& y>=0 && y<600) putpixel(xo-R,yo, couleur);
  }
