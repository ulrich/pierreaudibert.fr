/*********    NECKLACES    REGARDLESS OF SYMMETRIES       **********/
/**  N pearls, with NBletters different colours (NB[0] pearls with colour 0,
        NB[1] with colour 1, etc.)
*/
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#define NBletters 3  /** may be changed */
#define YES 1
#define NO 0
int fact (int n);
void display(void);
int NB[3],done[5000],N,nbc; int a[20],b[5000],count;

int main()
{ int letter,i,k,pospivot,possubstitute,aux,g,d,n,numberanag,q;
   int head,r[20],nbd,powerP; int flag,nbas=0;

   NB[0]=1;NB[1]=4;NB[2]=2;
   N=0;for(letter=0;letter<NBletters;letter++) N+=NB[letter];
   printf("ANAGRAMS OF LENGTH %d avec %d  letter(s) 0, %d  letter(s) 1, %d  letter(s) 2\n\n",N,NB[0],NB[1],NB[2]);
   q=0;
   for(letter=0;letter<NBletters;letter++)   for(i=0;i<NB[letter];i++)
    a[q++]=letter;
    count=0;
    for(;;)
     {  display(); printf("  ");
         powerP=1;nbd=0;
        for(k=0;k<N;k++) {nbd+=a[k]*powerP; powerP*=NBletters;}
        b[count]=nbd;
        k=N-1;    while (a[k]<=a[k-1] && k>=1) k--;
        pospivot=k-1;   if (pospivot==-1) break;
        k=N-1;   while(a[k]<=a[pospivot]) k--;   possubstitute=k;
        aux=a[pospivot];a[pospivot]=a[possubstitute];a[possubstitute]=aux;
        g=pospivot+1;d=N-1;  while(g<d)    { aux=a[g]; a[g]=a[d]; a[d]=aux;g++; d--;}
        count++;
     }
    numberanag=count+1;
    printf("\n\nNumber of anagrams=%d \n\n",numberanag);getch();
    printf("The same, written as decimal numbers:\n\n");
   for(n=0;n<numberanag;n++) printf("%d ",b[n]);
   getch();
   printf("\n\nNecklaces, and their symmetric (rotations, reflections) :\n");
   for(n=0; n<numberanag;n++)  done[n]=NO;
   for(n=0;n<numberanag;n++)  if(done[n]==NO)
     { q=b[n];printf("\n%d :   ",b[n]);
        for(k=0;k<N;k++) {r[k]=q%NBletters; q=q/NBletters;}
        for(head=1;head<N;head++)
          { nbd=0;powerP=1;
             for(k=0;k<N;k++) {nbd+=(r[(head+k)%N])*( int)powerP; powerP*=NBletters;}
             printf("%d ",nbd);
             for(k=n+1;k<numberanag;k++) if (b[k]==nbd) {done[k]=YES; break;}
          }
        for(head=0;head<N;head++)
         { nbd=0;powerP=1;
            for(k=0;k<N;k++) {nbd+=(r[(head+N-k)%N])*powerP; powerP*=NBletters;}
            printf("*%d ",nbd);
            for(k=n+1;k<numberanag;k++) if (b[k]==nbd) {done[k]=YES; break;}
          }
      }
   getch();printf("\n\nDifferent necklaces regardless of symmetries\n\n");nbc=0;
   for(k=0;k<numberanag;k++) if (done[k]==NO) {nbc++; printf("%d ",b[k]);}
   printf("   *** %d different necklaces *** ",nbc); getch();


/*********    self symmetric necklaces  (N odd)   ****************/
    printf("\n\nSelf symmetric :  ");
   for(k=0;k<numberanag;k++) if (done[k]==NO)
      { for(head=0;head<N;head++)
           { flag=YES;
              q=b[k]; for(i=0;i<N;i++)  {r[i]=q%NBletters; q=q/NBletters;}
              for(i=1;i<=(N-1)/2;i++) if (r[(head+N-i)%N]!=r[(head+i)%N]) {flag=NO; break;}
              if (flag==YES) { nbas++; printf("%d ",b[k]); break;}
           }
       }
getch();return 0;
}

void display(void)
{ int i;
   printf("%3d: ",count);
   for(i=0;i<N;i++) printf("%d",a[i]);
}

