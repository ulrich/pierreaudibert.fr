/**************         BINARY TREES LANGUAGE       ***************/
#include <stdio.h>
#include <math.h>
#include <conio.h>
#define No 4
void display(int Nnumber);
char a[10][150][30];
int L[10],C[10];
int Lo, number,aa[3*No+1];

int main()
{
int i,j,k,kk,count,N,nn0,n,nn; int iii,d,e,f,NS=No+2,digitnumber[100];
C[0]=1;a[0][0][0]='x'; L[0]=1;  display(0);
for(N=1;N<=No;N++)
   { count=0;
      for(i=0;i<N;i++)
         { j=N-1-i;
           for(k=0;k<C[i];k++)  for(kk=0;kk<C[j];kk++)
             { a[N][count][0]='(';
               for(n=0;n<3*i+1;n++) a[N][count][n+1]=a[i][k][n];
               nn0=3*i+2;
               for(n=0;n<3*j+1;n++) a[N][count][nn0+n]=a[j][kk][n];
               a[N][count][nn0+3*j+1]=')';
               count++;
             }
          C[N]=count;
        }
     display(N);
   }
getch();

/** conversion,  and preparation of triangulations */

for(n=0; n<C[No]; n++)
  {  printf("\n\n%d\n\n",n+1);
      Lo=3*No+1 ; number=1;
      for(nn=0; nn <Lo ; nn++)
        { if (a[No][n][nn]=='(') aa[nn]=-1; if (a[No][n][nn]==')') aa[nn]=-2;
           if (a[No][n][nn]=='x') aa[nn]=number++;
           printf("%c ",a[No][n][nn]);
        }
     printf("\n");
     for(nn=0; nn < Lo ; nn++) printf("%d ",aa[nn]);
     for(i=0;i<Lo;i++) digitnumber[i]=1;
     while(Lo!=1)
        { for(i=0;i<Lo-3;i++)
           if (aa[i]==-1  && aa[i+3]==-2)
              { d=aa[i+1]; while(d/10!=0) d=d/10;
                 e=aa[i+2]; while(e/10!=0) e=e/10;
                 f=(aa[i+2]%10+1)%NS;
                 printf("\n\n(%d %d %d)",d,e,f);
                 aa[i]=aa[i+1]*(float)pow(10,digitnumber[i+2])+aa[i+2];
                 digitnumber[i]=digitnumber[i+1]+digitnumber[i+2];
                 for(j=i+4;j<Lo;j++) {aa[j-3]=aa[j];digitnumber[j-3]=digitnumber[j];}
                 Lo-=3;
                 printf("   ");
                for(iii=0;iii<Lo;iii++) printf("%d ",aa[iii]);
              }
        }
getch();
  }
getch(); return 0;
}


void display(int Nnumber)
{ int j,n;
printf("\nN = %d\n",Nnumber);
for(j=0;j<C[Nnumber];j++)
   { printf(" \n%3.1d   ",j);
      for(n=0;n<3*Nnumber+1;n++)  printf("%c ",a[Nnumber][j][n]);
   }
printf("\n");
}

