/**************           POLYGON TRIANGULATION          **************/
/**************                   Chapter 32                                    **************/
/**    All the triangultations  */

#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <stdio.h>
#include <math.h>
#include <dos.h>
#define No 6      /**  number of  vertices. You can change  */
#define zoom 40
void drawing(void);
void drawingtriangle(int d, int e, int f);
void pause(void);
void putpixel(int xe, int ye, Uint32 c);
Uint32 getpixel(int xe, int ye);
void filldisc(int xo, int yo, int R,Uint32 c);
void line(int x0,int y0, int x1,int y1, Uint32 c);
void linewithwidth(int x1, int y1, int x2, int y2, int epaisseur,Uint32 c);
void floodfill( int x,int y, Uint32 cr,Uint32 cb);
char a[10][150][30];
int L[10],C[10];
int xe[No+2],ye[No+2],xorig,yorig, NS=No+2;   /** NS = vertices number*/
int xg,yg,icolor;
SDL_Surface * screen; Uint32 white, color[10];
SDL_Surface *texte;  SDL_Rect position;TTF_Font *police=NULL;char chiffre[2000];

int main(int argc, char ** argv)
{ int i,j,k,kk,count,N,nn0,n,iii,ii;
  int Lo,digitnumber[3*No+1];
  int d,e,f,number,nn; int aa[50];
  SDL_Init(SDL_INIT_VIDEO);
   screen=SDL_SetVideoMode(800,600,32, SDL_HWSURFACE|SDL_DOUBLEBUF);
   white=SDL_MapRGB(screen->format,255,255,255);
   color[0]=SDL_MapRGB(screen->format,0,0,0);
   color[1]=SDL_MapRGB(screen->format,250,0,0);
   color[2]=SDL_MapRGB(screen->format,0,250,0);
   color[3]=SDL_MapRGB(screen->format,0,0,250);
   color[4]=SDL_MapRGB(screen->format,250,250,0);
   color[5]=SDL_MapRGB(screen->format,250,0,250);
   color[6]=SDL_MapRGB(screen->format,0,250,250);
   SDL_FillRect(screen,0,white);
   TTF_Init();
   police=TTF_OpenFont("times.ttf",20);

/**   C[No] words of binary trees  */

C[0]=1;a[0][0][0]='x'; L[0]=1;
for(N=1;N<=No;N++)
  { count=0;
     for(i=0;i<N;i++)
       { j=N-1-i;
         for(k=0;k<C[i];k++)  for(kk=0;kk<C[j];kk++)
           { a[N][count][0]='(';
              for(n=0;n<3*i+1;n++) a[N][count][n+1]=a[i][k][n];
              nn0=3*i+2;
             for(n=0;n<3*j+1;n++) a[N][count][nn0+n]=a[j][kk][n];
              a[N][count][nn0+3*j+1]=')';
              count++;
           }
        C[N]=count;
      }
   }

/**    triangulation  */

xorig=zoom+20; yorig=zoom+20;
for(n=0; n<C[No]; n++)
  {   Lo=3*No+1 ; number=1;
      for(nn=0; nn <Lo ; nn++)
        { if (a[No][n][nn]=='(') aa[nn]=-1; if (a[No][n][nn]==')') aa[nn]=-2;
           if (a[No][n][nn]=='x') aa[nn]=number++;
        }
  drawing();
  icolor=0;
  for(i=1;i<Lo;i++) digitnumber[i]=1;
  while(Lo!=1)
    { for(i=0;i<Lo-3;i++)
       if (aa[i]==-1  && aa[i+3]==-2)
         {
           d=aa[i+1]; while(d/10!=0) d=d/10;
           e=aa[i+2]; while(e/10!=0) e=e/10;
           f=(aa[i+2]%10+1)%NS;
          icolor++;drawingtriangle(d,e,f);
          aa[i]=aa[i+1]*(float)pow(10.,digitnumber[i+2])+aa[i+2];
          digitnumber[i]=digitnumber[i+1]+digitnumber[i+2];
          for(j=i+4;j<Lo;j++) {aa[j-3]=aa[j]; digitnumber[j-3]=digitnumber[j];}
          Lo-=3;
        }
    }
    xorig+= 2*zoom+20; if (xorig>750)  { yorig+=2*zoom;xorig=zoom+20;}
    if (yorig>540)
       {  SDL_Flip(screen);pause();SDL_FillRect(screen,0,white);
          xorig=zoom+20; yorig=zoom+20;
       }

  }
SDL_Flip(screen);pause();TTF_CloseFont(police); TTF_Quit();  return 0;
}

void drawing(void)
{
int i;
for(i=0;i<NS;i++)
{
xe[i]=xorig+zoom*cos(M_PI/2.- M_PI/(float)NS+i*2.*M_PI/(float)NS);
ye[i]=yorig-zoom*sin(M_PI/2.- M_PI/(float)NS+i*2.*M_PI/(float)NS);
filldisc(xe[i],ye[i],1,color[0]);
}
}

void drawingtriangle(int d, int e,  int f)
{
  line(xe[d],ye[d],xe[e],ye[e],color[0]);  line(xe[e],ye[e],xe[f],ye[f],color[0]);
  line(xe[f],ye[f],xe[d],ye[d],color[0]);
  xg=(xe[d]+xe[e]+xe[f])/3;yg=(ye[d]+ye[e]+ye[f])/3;
  floodfill(xg,yg,color[icolor],color[0]);
}

void pause(void)
{
    SDL_Event evenement;
    do   SDL_WaitEvent(&evenement);
    while(evenement.type != SDL_QUIT && evenement.type != SDL_KEYDOWN);
}

void putpixel(int xe, int ye, Uint32 c)
{ Uint32 * numbercase;
numbercase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;    *numbercase=c;
}

Uint32 getpixel(int xe, int ye)
{ Uint32 * numbercase;
   numbercase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;   return (*numbercase);
}

void filldisc( int xo, int yo, int R, Uint32 c)
  {
      int x, y, F, F1, F2,newx,newy,xx;
      x=xo; y=yo+R; F=0;
      if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,c);
      if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, c);
      while( y>yo)
         {
             F1=F+2*(x-xo)+1; F2=F-2*(y-yo)+1;
             if ( abs(F1)<abs(F2))  { x+=1; F=F1;}
             else {y-=1; F=F2;}
             newx=2*xo-x ; newy=2*yo-y ;
             for(xx=newx; xx<=x; xx++)if (xx<800 && xx>=0 && y>=0 && y<600 )
             putpixel(xx,y,c);
             for(xx=newx; xx<=x; xx++)if (xx<800 && xx>=0 && newy>=0 && newy<600 )
             putpixel(xx,newy,c);
         }
       if (xo+R<800 && xo+R>=0&& y>=0 && y<600) putpixel(xo+R,yo,c);
       if (xo-R<800 && xo-R>=0&& y>=0 && y<600) putpixel(xo-R,yo, c);
  }
/**  ligne en marches d'escalier */
void line(int x0,int y0, int x1,int y1, Uint32 c)
{
int dx,dy,x,y,residu,absdx,absdy,pasx,pasy,i;
dx=x1-x0; dy=y1-y0;  residu=0;       x=x0;y=y0;  if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
if (dx>0) pasx=1;else pasx=-1; if (dy>0) pasy=1; else pasy=-1;
absdx=abs(dx);absdy=abs(dy);
if (dx==0) for(i=0;i<absdy;i++) { y+=pasy;
                                                    if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c); }
else if(dy==0) for(i=0;i<absdx;i++){ x+=pasx;
                                                         if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);  }
else if (absdx==absdy)
   for(i=0;i<absdx;i++) {x+=pasx; if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
                                     y+=pasy;
                                     if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
                                     }
else if (absdx>absdy)
          for(i=0;i<absdx;i++)
			  { x+=pasx; if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
			     residu+=absdy;
			     if(residu >= absdx) {residu -=absdx; y+=pasy;
	                              		        if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
			                                    }
			  }
else for(i=0;i<absdy;i++)
             {y+=pasy; if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
               residu +=absdx;
              if (residu>=absdy)   {residu -= absdy;x +=pasx;
                                              if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
                                             }
             }
}

void floodfill( int x,int y, Uint32 cr,Uint32 cb)
{   int xg,xd,xx;
    if (getpixel(x,y) !=cb && getpixel(x,y) !=cr)
    { putpixel(x,y,cr);
    xg=x-1;
    while(xg>0 && getpixel(xg,y)!=cb)  {putpixel(xg,y,cr); xg--;}
    xd=x+1;
    while(xd<800 && getpixel(xd,y)!=cb)  {putpixel(xd,y,cr); xd++ ;}
    for(xx=xg; xx<xd;xx++)
    { if (y>1 ) {floodfill(xx,y-1,cr,cb);}
       if (y<599 ) {floodfill(xx,y+1,cr,cb);}
    }
    }
}
