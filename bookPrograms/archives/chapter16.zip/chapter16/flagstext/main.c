
#include <stdio.h>
#include <conio.h>
#define P 4
#define N 6

void tree (int a, int level);
int done[N+1][P],d[N+1],predecessor[N+1],compteur=0;

main()   {  done[1][0]=1;  tree(0, 1);  getch(); return 0; }

void tree (int a, int level)
{ int pluspetit,i,j;
   if (level==N)
     { for(j=2; j<=N; j++) d[j-2]=predecessor[j]; d[N-1]=a;
        for(i=0;i<P;i++)
        if(done[level][i]==0) {pluspetit=i;break;}
        if (i==P) pluspetit=-1;
        if(pluspetit==-1)
         { compteur++;
            printf("\n%3.d : ", compteur);
            for(i=0;i<N;i++) printf("%d ",d[i]);
         }
      }
   else
     { for(i=0;i<P;i++)
        if(done[level][i]==0) {pluspetit=i;break;}
        if (i==P) pluspetit=-1;
        for(i=0;i<P;i++)
        if (done[level][i]==1 && i!=a)
          { predecessor[level+1]=a;
            for(j=0;j<P;j++) done[level+1][j]=done[level][j];
            done[level+1][i]=1;
            tree(i,level+1);
          }
        if (pluspetit!=-1)
          { predecessor[level+1]=a;
	        for(j=0;j<P;j++) done[level+1][j]=done[level][j];
            done[level+1][pluspetit]=1;
            tree(pluspetit,level+1);
         }
     }
}
