#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <math.h>
#define N 6
#define P 5

int main()
{  int i, k,count=0, pospivot, a[N];
    for(i=0;i<N;i++) if (i%2==0) a[i]=0; else a[i]=1;
for(;;)
  {  count++;
     printf("\n%3.d : ",count);
     for(i=0;i<N;i++) printf("%d ",a[i]);
   i=N-1;
  while((a[i]==P-1 || (a[i]==P-2 && a[i-1]==P-1)) && i>=0 ) i--;
  pospivot=i;    if (pospivot==-1) break;
  if (a[pospivot]==a[pospivot-1]-1 && a[pospivot]!=P-2) a[pospivot]+=2;else a[pospivot]++;
  k=0;
  for(i=pospivot+1;i<N;i++) { if (k%2==0) a[i]=0; else a[i]=1;  k++; }
  }

  printf("\n*** %d ", P*(int)pow((float)P-1,(float)N-1));
    getch();return 0;
}
