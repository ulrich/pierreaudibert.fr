/********************                 FLAGS                  *********************/
/**  N vertical strips, P colors all used   */

#include <SDL/SDL.h>
#include <stdio.h>
#include <math.h>
#define P 5
#define N 7
#define pas 20
void tree (int a, int level);
void listeaetpredecesseurs(int a,int level);
void dessin(int xorig, int yorig) ;
void pause(void);
void putpixel(int xe, int ye, Uint32 c);
Uint32 getpixel(int xe, int ye);
void line(int x0,int y0, int x1,int y1, Uint32 c);
void floodfill( int x,int y, Uint32 cr,Uint32 cb);
void rectangle(int x1,int y1, int x2, int y2, Uint32 c);
SDL_Surface * screen; Uint32 white, color[10];
int done[N+1][P],d[N+1],predecessor[N+1],compteur=0,xx=10,yy=5;

int main(int argc, char ** argv)
{  SDL_Init(SDL_INIT_VIDEO);
   screen=SDL_SetVideoMode(800,600,32, SDL_HWSURFACE|SDL_DOUBLEBUF);
   white=SDL_MapRGB(screen->format,255,255,255);
   color[0]=SDL_MapRGB(screen->format,0,0,0);
   color[1]=SDL_MapRGB(screen->format,250,0,0);
   color[2]=SDL_MapRGB(screen->format,0,250,0);
   color[3]=SDL_MapRGB(screen->format,0,0,250);
   color[4]=SDL_MapRGB(screen->format,250,250,0);
   color[5]=SDL_MapRGB(screen->format,250,0,250);
   color[6]=SDL_MapRGB(screen->format,0,250,250);
   color[7]=SDL_MapRGB(screen->format,120,120,120);
   SDL_FillRect(screen,0,white);

   done[1][0]=1;
   tree(0, 1);
   SDL_Flip(screen);  pause();  return 0;
}

void tree (int a, int level)
{ int smallest,i,j;
   if (level==N)
     { for(j=2; j<=N; j++) d[j-2]=predecessor[j]; d[N-1]=a;
        for(i=0;i<P;i++)
        if(done[level][i]==0) {smallest=i;break;}
        if (i==P) smallest=-1;
        if(smallest==-1)
          { compteur++;
             dessin(xx,yy); xx+=pas*(N+1); if (xx>800-N*pas) {yy+=3*pas,xx=10;}
             if (yy>600 - 2*pas) { SDL_Flip(screen);  pause(); SDL_FillRect(screen,0,white);
                                              xx=10;yy=5;
                                           }
          }
      }
   else
     { for(i=0;i<P;i++)
        if(done[level][i]==0) {smallest=i;break;}
        if (i==P) smallest=-1;
        for(i=0;i<P;i++)
        if (done[level][i]==1 && i!=a)
          { predecessor[level+1]=a;
            for(j=0;j<P;j++) done[level+1][j]=done[level][j];
            done[level+1][i]=1;
            tree(i,level+1);
          }
        if (smallest!=-1)
          { predecessor[level+1]=a;
	        for(j=0;j<P;j++) done[level+1][j]=done[level][j];
            done[level+1][smallest]=1;
            tree(smallest,level+1);
         }
     }
}


void dessin(int xorig, int yorig)
{ int i,icolor;
  for(i=0;i<N;i++)
    { rectangle(xorig+pas*i,yorig,xorig+pas*(i+1),yorig+2*pas,color[7]);
       icolor=d[i]+1;
      floodfill(xorig+pas*i+pas/2,yorig+pas,color[icolor],color[7]);
    }
}

void pause(void)
{
    SDL_Event evenement;
    do   SDL_WaitEvent(&evenement);
    while(evenement.type != SDL_QUIT && evenement.type != SDL_KEYDOWN);
}

void putpixel(int xe, int ye, Uint32 c)
{ Uint32 * numbercase;
numbercase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;    *numbercase=c;
}

Uint32 getpixel(int xe, int ye)
{ Uint32 * numbercase;
   numbercase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;   return (*numbercase);
}

/**  stairs line */
void line(int x0,int y0, int x1,int y1, Uint32 c)
{
int dx,dy,x,y,residu,absdx,absdy,pasx,pasy,i;
dx=x1-x0; dy=y1-y0;  residu=0;       x=x0;y=y0;  if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
if (dx>0) pasx=1;else pasx=-1; if (dy>0) pasy=1; else pasy=-1;
absdx=abs(dx);absdy=abs(dy);
if (dx==0) for(i=0;i<absdy;i++) { y+=pasy;
                                                    if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c); }
else if(dy==0) for(i=0;i<absdx;i++){ x+=pasx;
                                                         if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);  }
else if (absdx==absdy)
   for(i=0;i<absdx;i++) {x+=pasx; if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
                                     y+=pasy;
                                     if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
                                     }
else if (absdx>absdy)
          for(i=0;i<absdx;i++)
			  { x+=pasx; if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
			     residu+=absdy;
			     if(residu >= absdx) {residu -=absdx; y+=pasy;
	                              		        if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
			                                    }
			  }
else for(i=0;i<absdy;i++)
             {y+=pasy; if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
               residu +=absdx;
              if (residu>=absdy)   {residu -= absdy;x +=pasx;
                                              if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
                                             }
             }
}

void floodfill( int x,int y, Uint32 cr,Uint32 cb)
{   int xg,xd,xx;
    if (getpixel(x,y) !=cb && getpixel(x,y) !=cr)
    { putpixel(x,y,cr);
    xg=x-1;
    while(xg>0 && getpixel(xg,y)!=cb)  {putpixel(xg,y,cr); xg--;}
    xd=x+1;
    while(xd<800 && getpixel(xd,y)!=cb)  {putpixel(xd,y,cr); xd++ ;}
    for(xx=xg; xx<xd;xx++)
    { if (y>1 ) {floodfill(xx,y-1,cr,cb);}
       if (y<599 ) {floodfill(xx,y+1,cr,cb);}
    }
    }
}
void rectangle(int x1,int y1, int x2, int y2, Uint32 c)
{
    line(x1,y1,x2,y1,c);line(x1,y2,x2,y2,c);line(x1,y1,x1,y2,c);line(x2,y2,x2,y1,c);
}
