/*************************      FLAGS         ***************************/
/**************          N vertical strips,  P colors                      **************/
#include <SDL/SDL.h>
#include <stdio.h>
#define N 4
#define P 5
#define pas 20
void drawing(int i,int c);
void pause(void);
void putpixel(int xe, int ye, Uint32 c);
Uint32 getpixel(int xe, int ye);
void line(int x0,int y0, int x1,int y1, Uint32 c);
void floodfill( int x,int y, Uint32 cr,Uint32 cb);
void rectangle(int x1,int y1, int x2, int y2, Uint32 c);
SDL_Surface * screen; Uint32 white, color[10];
int xorig,yorig;float zoom;
int a[N];

int main(int argc, char ** argv)
{  int i,k,pospivot;
    SDL_Init(SDL_INIT_VIDEO);
   screen=SDL_SetVideoMode(800,600,32, SDL_HWSURFACE|SDL_DOUBLEBUF);
   white=SDL_MapRGB(screen->format,255,255,255);
   if (P<=5)
   {
   color[0]=SDL_MapRGB(screen->format,250,250,250);
   color[1]=SDL_MapRGB(screen->format,200,200,200);
   color[2]=SDL_MapRGB(screen->format,150,150,150);
   color[3]=SDL_MapRGB(screen->format,100,100,100);
   color[4]=SDL_MapRGB(screen->format,50,50,50);
   color[5]=SDL_MapRGB(screen->format,0,0,0);

   }
   SDL_FillRect(screen,0,white);

xorig=10;yorig=10;
for(i=0;i<N;i++) if (i%2==0) a[i]=0; else a[i]=1;
for(;;)
  {
  line(xorig-1,yorig,xorig-1,yorig+4*pas,color[5]);
  line(xorig-2,yorig,xorig-2,yorig+4*pas,color[5]);
  for(i=0;i<N;i++) drawing(i,a[i]);
  xorig+=N*pas+20; if (xorig>800-N*pas) {yorig+=6*pas; xorig=10;}
  if (yorig>550)  { SDL_Flip(screen);  pause(); SDL_FillRect(screen,0,white);
                            xorig=10;yorig=10;
                         }
  i=N-1;

  while((a[i]==P-1 || (a[i]==P-2 && a[i-1]==P-1)) && i>=0 ) i--;
  pospivot=i;    if (pospivot==-1) break;
  if (a[pospivot]==a[pospivot-1]-1 && a[pospivot]!=P-2) a[pospivot]+=2;else a[pospivot]++;
   k=0;
  for(i=pospivot+1;i<N;i++) { if (k%2==0) a[i]=0; else a[i]=1;  k++; }
  }
SDL_Flip(screen);  pause();  return 0;
}

void drawing(int i,int c)
{
rectangle( xorig+pas*i, yorig, xorig+pas*i+pas-1, yorig+3*pas,color[5]);
floodfill( xorig+pas*i+(pas-1)/2,yorig+3*pas/2,color[c],color[5]);
}

void pause(void)
{
    SDL_Event evenement;
    do   SDL_WaitEvent(&evenement);
    while(evenement.type != SDL_QUIT && evenement.type != SDL_KEYDOWN);
}


void putpixel(int xe, int ye, Uint32 couleur)
{ Uint32 * numerocase;
numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;    *numerocase=couleur;
}

Uint32 getpixel(int xe, int ye)
{ Uint32 * numerocase;
   numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;   return (*numerocase);
}



void line(int x0,int y0, int x1,int y1, Uint32 c)
{
int dx,dy,x,y,residu,absdx,absdy,stepx,stepy,i;
dx=x1-x0; dy=y1-y0;  residu=0;       x=x0;y=y0;  putpixel(x,y,c);
if (dx>0) stepx=1;else stepx=-1; if (dy>0) stepy=1; else stepy=-1;
absdx=abs(dx);absdy=abs(dy);
if (dx==0) for(i=0;i<absdy;i++) { y+=stepy;
                                                    putpixel(x,y,c); }
else if(dy==0) for(i=0;i<absdx;i++){ x+=stepx;
                                                         putpixel(x,y,c);  }
else if (absdx==absdy)
   for(i=0;i<absdx;i++) {x+=stepx; y+=stepy;
                                     putpixel(x,y,c);
                                     }
else if (absdx>absdy)
          for(i=0;i<absdx;i++)
			  { x+=stepx; residu+=absdy;
			     if(residu >= absdx) {residu -=absdx; y+=stepy;}
			     putpixel(x,y,c);
			  }
else for(i=0;i<absdy;i++)
             {y+=stepy; residu +=absdx;
              if (residu>=absdy)   {residu -= absdy;x +=stepx;}
              putpixel(x,y,c);
             }
}


void rectangle(int x1,int y1, int x2, int y2, Uint32 c)
{
    line(x1,y1,x2,y1,c);line(x1,y2,x2,y2,c);line(x1,y1,x1,y2,c);line(x2,y2,x2,y1,c);
}

void floodfill( int x,int y, Uint32 cr,Uint32 cb)
{   int xg,xd,xx;
    if (getpixel(x,y) !=cb && getpixel(x,y) !=cr)
    { putpixel(x,y,cr);
    xg=x-1;
    while(xg>0 && getpixel(xg,y)!=cb)  {putpixel(xg,y,cr); xg--;}
    xd=x+1;
    while(xd<800 && getpixel(xd,y)!=cb)  {putpixel(xd,y,cr); xd++ ;}
    for(xx=xg; xx<xd;xx++)
    { if (y>1 ) {floodfill(xx,y-1,cr,cb);}
       if (y<599 ) {floodfill(xx,y+1,cr,cb);}
    }
    }
}
