/*******      ALL SPANNING TREES OF A COMPLETE GRAPH         ********/
/*******                                  Fig. 31-3                                                        ********/

#include <SDL/SDL.h>
#include <math.h>
#define twopi 6.28318
#define radius 20
#define N 5
void pause(void);
void putpixel(int xe, int ye, Uint32 couleur);
Uint32 getpixel(int xe, int ye);
void circle(int x0, int y0, int R, Uint32 couleur);
void line(int x0, int y0, int x1, int y1, Uint32 c);
void filldisc( int xo, int yo, int R, Uint32 couleur);
SDL_Surface *screen = NULL;
Uint32 white, black, red;
int xorig, yorig;
int x[N+1], y[N+1], l[N+1];


int main(int argc, char **argv)
{
int w[N-1], deg[N+1];
int number, i, j, k, r, q, stage;
xorig=radius+10;
yorig=radius+10;
SDL_Init(SDL_INIT_VIDEO);
screen = SDL_SetVideoMode(800,600,32,SDL_HWSURFACE|SDL_DOUBLEBUF);
white = SDL_MapRGB(screen->format,255,255,255);
black = SDL_MapRGB(screen->format,0,0,0);
red = SDL_MapRGB(screen->format,255,0,0);
SDL_FillRect(screen,0,white);

for(number=0;number<pow(N,N-2);  number++)
  {
   for(i=1;i<=N;i++)
     {  x[i]=xorig+radius*cos(twopi*(i-1)/(float)N);
         y[i]=yorig-radius*sin(twopi*(i-1)/(float)N);
         filldisc(x[i],y[i],2,black);
     }
   q = number;
   for(i=0;i<N-2;i++)  {   r = q%N;   w[N-2-i] = r+1;   q = q/N;  }
   for(i=1;i<=N;i++)   deg[i] = 1;
   for(j=1;j<=N-2;j++)  deg[w[j]]++;


   for(stage=1;stage<=N-1;stage++)
    {
      k=1;
      for(j=1;j<=N;j++) if(deg[j] == 1)  {l[k] = j;  k++;}
      if(stage < N-1)
       {
         line(x[l[1]],y[l[1]],x[w[stage]],y[w[stage]],red);
         deg[l[1]]--;
         deg[w[stage]]--;
       }
      else  line(x[l[1]],y[l[1]],x[l[2]],y[l[2]],red);
   }

   xorig+=2*radius+40;   if(xorig>750){  yorig+=2*radius+20;  xorig=radius+10;  }
   if(yorig>550)  {  SDL_Flip(screen);  pause();  SDL_FillRect(screen,0,white);
                             xorig=10+radius;   yorig=10+radius;
                         }
  }
SDL_Flip(screen);pause();return 0;
}

void pause(void)
{
    SDL_Event evenement;
    do   SDL_WaitEvent(&evenement);
    while (evenement.type != SDL_QUIT && evenement.type != SDL_KEYDOWN);
}


void putpixel(int xe, int ye, Uint32 couleur)
{ Uint32 * numerocase;
numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;    *numerocase=couleur;
}

Uint32 getpixel(int xe, int ye)
{ Uint32 * numerocase;
   numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;   return (*numerocase);
}

void line(int x0,int y0, int x1,int y1, Uint32 c)
{
int dx,dy,x,y,residu,absdx,absdy,pasx,pasy,i;
dx=x1-x0; dy=y1-y0;  residu=0;       x=x0;y=y0;  putpixel(x,y,c);
if (dx>0) pasx=1;else pasx=-1; if (dy>0) pasy=1; else pasy=-1;
absdx=abs(dx);absdy=abs(dy);
if (dx==0) for(i=0;i<absdy;i++) { y+=pasy;
                                                    putpixel(x,y,c); /*circle(x,y,3,c);*/}
else if(dy==0) for(i=0;i<absdx;i++){ x+=pasx;
                                           putpixel(x,y,c);  /*circle(x,y,3,c);*/}
else if (absdx==absdy)
   for(i=0;i<absdx;i++) {x+=pasx; y+=pasy;
                                     putpixel(x,y,c);
                                     }
else if (absdx>absdy)
          for(i=0;i<absdx;i++)
			  { x+=pasx; residu+=absdy;
			     if(residu >= absdx) {residu -=absdx; y+=pasy;}
			     putpixel(x,y,c);/*circle(x,y,3,c);*/
			  }
else for(i=0;i<absdy;i++)
             {y+=pasy; residu +=absdx;
              if (residu>=absdy)   {residu -= absdy;x +=pasx;}
              putpixel(x,y,c);/*circle(x,y,3,c);*/
             }
}

void circle( int xo, int yo, int RR, Uint32 couleur)
{
    int x, y, F, F1, F2,newx,newy;
    x=xo; y=yo+RR; F=0;
    if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
    if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, couleur);
    while ( y>yo)
    {
        F1=F+2*(x-xo)+1;F2=F-2*(y-yo)+1;
        if ( abs(F1)<abs(F2)) {  x+=1;   F=F1; }
        else{ y-=1; F=F2;  }
        if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
        newx=2*xo-x ;   newy=2*yo-y ;
        if (x<800 && x>=0 && newy>=0 && newy<600) putpixel(x, newy,couleur);
        if (newx<800 && newx>=0 && y>=0 && y<600) putpixel( newx,y,couleur);
        if (newx<800 && newx>=0 && newy>=0 && newy<600) putpixel(newx,
                    newy, couleur);
    }
    if (xo+RR<800 && xo+RR>=0) putpixel(xo+RR,yo,couleur);
    if (xo-RR<800 && xo-RR>=0) putpixel(xo-RR,yo, couleur);
}
void filldisc( int xo, int yo, int R, Uint32 couleur)
  {
      int x, y, F, F1, F2,newx,newy,xx;
      x=xo; y=yo+R; F=0;
      if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
      if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, couleur);
      while( y>yo)
         {
             F1=F+2*(x-xo)+1; F2=F-2*(y-yo)+1;
             if ( abs(F1)<abs(F2))  { x+=1; F=F1;}
             else {y-=1; F=F2;}
             newx=2*xo-x ; newy=2*yo-y ;
             for(xx=newx; xx<=x; xx++)if (xx<800 && xx>=0 && y>=0 && y<600 )
             putpixel(xx,y,couleur);
             for(xx=newx; xx<=x; xx++)if (xx<800 && xx>=0 && newy>=0 && newy<600 )
             putpixel(xx,newy,couleur);
         }
       if (xo+R<800 && xo+R>=0&& y>=0 && y<600) putpixel(xo+R,yo,couleur);
       if (xo-R<800 && xo-R>=0&& y>=0 && y<600) putpixel(xo-R,yo, couleur);
  }

