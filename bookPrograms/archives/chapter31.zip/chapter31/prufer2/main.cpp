/**********     SPANNING TREES OF A   COMPLETE GRAPH     ***********/
/**********                         Fig. 31-4     31-5                                          ***********/
#include <SDL/SDL.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#define twopi 6.28318
#define radius 15
#define N 6
void pause(void);
void putpixel(int xe, int ye, Uint32 couleur);
Uint32 getpixel(int xe, int ye);
void circle(int x0, int y0, int R, Uint32 couleur);
void line(int x0, int y0, int x1, int y1, Uint32 c);
void linewithwidth(int x1, int y1, int x2, int y2, int width,Uint32 c);
void filldisc( int xo, int yo, int R, Uint32 couleur);
SDL_Surface *screen = NULL;
Uint32 white, black, red,color[100];
int xorig, yorig;
int x[N+1], y[N+1], file[N+1];

int main(int argc, char **argv)
{
int m[N-1], deg[N+1];
int number, i, j, k, t,r, q, etape,numberleaves;
xorig=radius+10;
yorig=radius+10;
SDL_Init(SDL_INIT_VIDEO);
screen = SDL_SetVideoMode(800,600,32,SDL_HWSURFACE|SDL_DOUBLEBUF);
white = SDL_MapRGB(screen->format,255,255,255);
black= SDL_MapRGB(screen->format,0,0,0);
red = SDL_MapRGB(screen->format,255,0,0);
t=0;
for(i=0;i<2;i++) for(j=0;j<2;j++) for(k=0;k<2;k++)
   {color[t]=SDL_MapRGB(screen->format,210-100*i,210-100*j, 210-100*k); t++;}

SDL_FillRect(screen,0,white);

for(number=0;number<pow(N,N-2);  number++)
  {
   for(i=1;i<=N;i++)
     {  x[i]=xorig+radius*cos(twopi*(i-1)/(float)N);
         y[i]=yorig-radius*sin(twopi*(i-1)/(float)N);
         filldisc(x[i],y[i],2,black);
     }
   q = number;
   for(i=0;i<N-2;i++)  {   r = q%N;   m[N-2-i] = r+1;   q = q/N;  }
   for(i=1;i<=N;i++)   deg[i] = 1;
   for(j=1;j<=N-2;j++)  deg[m[j]]++;
   numberleaves=0;
   for(j=1;j<=N;j++) if(deg[j] == 1) numberleaves++;

   for(etape=1;etape<=N-1;etape++)
    {
      k=1;
      for(j=1;j<=N;j++) if(deg[j] == 1)  {file[k] = j;  k++;}
      if(etape < N-1)
       {
         linewithwidth(x[file[1]],y[file[1]],x[m[etape]],y[m[etape]],1,color[numberleaves]);
         deg[file[1]]--;
         deg[m[etape]]--;
       }
      else  linewithwidth(x[file[1]],y[file[1]],x[file[2]],y[file[2]],1,color[numberleaves]);
   }
   xorig+=2*radius+20;   if(xorig>750){  yorig+=2*radius+20;  xorig=radius+10;  }
   if(yorig>550)  {  SDL_Flip(screen);  pause();  SDL_FillRect(screen,0,white);
                             xorig=10+radius;   yorig=10+radius;
                         }
  }
SDL_Flip(screen);pause();return 0;
}

void pause(void)
{
    SDL_Event evenement;
    do   SDL_WaitEvent(&evenement);
    while (evenement.type != SDL_QUIT && evenement.type != SDL_KEYDOWN);
}


void putpixel(int xe, int ye, Uint32 couleur)
{ Uint32 * numerocase;
numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;    *numerocase=couleur;
}

Uint32 getpixel(int xe, int ye)
{ Uint32 * numerocase;
   numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;   return (*numerocase);
}

void line(int x0,int y0, int x1,int y1, Uint32 c)
{
int dx,dy,x,y,residu,absdx,absdy,pasx,pasy,i;
dx=x1-x0; dy=y1-y0;  residu=0;       x=x0;y=y0;  putpixel(x,y,c);
if (dx>0) pasx=1;else pasx=-1; if (dy>0) pasy=1; else pasy=-1;
absdx=abs(dx);absdy=abs(dy);
if (dx==0) for(i=0;i<absdy;i++) { y+=pasy;
                                                    putpixel(x,y,c); /*circle(x,y,3,c);*/}
else if(dy==0) for(i=0;i<absdx;i++){ x+=pasx;
                                           putpixel(x,y,c);  /*circle(x,y,3,c);*/}
else if (absdx==absdy)
   for(i=0;i<absdx;i++) {x+=pasx; y+=pasy;
                                     putpixel(x,y,c);
                                     }
else if (absdx>absdy)
          for(i=0;i<absdx;i++)
			  { x+=pasx; residu+=absdy;
			     if(residu >= absdx) {residu -=absdx; y+=pasy;}
			     putpixel(x,y,c);/*circle(x,y,3,c);*/
			  }
else for(i=0;i<absdy;i++)
             {y+=pasy; residu +=absdx;
              if (residu>=absdy)   {residu -= absdy;x +=pasx;}
              putpixel(x,y,c);/*circle(x,y,3,c);*/
             }
}

void circle( int xo, int yo, int RR, Uint32 couleur)
{
    int x, y, F, F1, F2,newx,newy;
    x=xo; y=yo+RR; F=0;
    if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
    if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, couleur);
    while ( y>yo)
    {
        F1=F+2*(x-xo)+1;F2=F-2*(y-yo)+1;
        if ( abs(F1)<abs(F2)) {  x+=1;   F=F1; }
        else{ y-=1; F=F2;  }
        if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
        newx=2*xo-x ;   newy=2*yo-y ;
        if (x<800 && x>=0 && newy>=0 && newy<600) putpixel(x, newy,couleur);
        if (newx<800 && newx>=0 && y>=0 && y<600) putpixel( newx,y,couleur);
        if (newx<800 && newx>=0 && newy>=0 && newy<600) putpixel(newx,
                    newy, couleur);
    }
    if (xo+RR<800 && xo+RR>=0) putpixel(xo+RR,yo,couleur);
    if (xo-RR<800 && xo-RR>=0) putpixel(xo-RR,yo, couleur);
}
void filldisc( int xo, int yo, int R, Uint32 couleur)
  {
      int x, y, F, F1, F2,newx,newy,xx;
      x=xo; y=yo+R; F=0;
      if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
      if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, couleur);
      while( y>yo)
         {
             F1=F+2*(x-xo)+1; F2=F-2*(y-yo)+1;
             if ( abs(F1)<abs(F2))  { x+=1; F=F1;}
             else {y-=1; F=F2;}
             newx=2*xo-x ; newy=2*yo-y ;
             for(xx=newx; xx<=x; xx++)if (xx<800 && xx>=0 && y>=0 && y<600 )
             putpixel(xx,y,couleur);
             for(xx=newx; xx<=x; xx++)if (xx<800 && xx>=0 && newy>=0 && newy<600 )
             putpixel(xx,newy,couleur);
         }
       if (xo+R<800 && xo+R>=0&& y>=0 && y<600) putpixel(xo+R,yo,couleur);
       if (xo-R<800 && xo-R>=0&& y>=0 && y<600) putpixel(xo-R,yo, couleur);
  }
void linewithwidth(int x1, int y1, int x2, int y2, int width,Uint32 c)
{
int dx,dy;
float k,xf1,yf1,xf2,yf2,d,dx1,dy1,ndx1,ndy1,ndx2,ndy2,angle=M_PI/2.;
line(x1,y1,x2,y2,c);
dx=x2-x1; dy=y2-y1;       d=sqrt(dx*dx+dy*dy);
if (d!=0.)      /* si le vecteur n’est pas nul */
{ dx1=(float)width*(float)dx/d; dy1=(float)width*(float)dy/d;
   ndx1=dx1*cos(angle)-dy1*sin(angle);
   ndy1=dx1*sin(angle)+dy1*cos(angle);
   ndx2=dx1*cos(-angle)-dy1*sin(-angle);
   ndy2=dx1*sin(-angle)+dy1*cos(-angle);
   for(k=0;k<=1.;k+=0.1/d)
   {
   xf1=(1.-k)*x1+k*x2; yf1=(1.-k)*y1+k*y2;
   xf2=xf1-ndx1; yf2=yf1-ndy1;  line(xf1,yf1,xf2,yf2,c);
   xf2=xf1-ndx2; yf2=yf1-ndy2;    line(xf1,yf1,xf2,yf2,c);
   }
}
}


