/****************            WILSON ALGORITHM              ******************/
#include <stdio.h>
#include <SDL/SDL.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#define N 20
#define M 20
#define MN (M*N)
#define xorig 120
#define yorig 10
#define step 30

void branch(int i);
void pause(void);
void putpixel(int xe, int ye, Uint32 couleur);
Uint32 getpixel(int xe, int ye);
void circle( int xo, int yo, int R, Uint32 couleur);
void filldisc(int xo, int yo, int R,Uint32 couleur);
void line(int x0,int y0, int x1,int y1, Uint32 c);
void linewithwidth(int x1, int y1, int x2, int y2, int epaisseur,Uint32 c);
void floodfill( int x,int y, Uint32 cr,Uint32 cb);
SDL_Surface * screen; Uint32 white,red,green,blue;
int wherealreadyseen (int v);
int n[MN][4],nbn[MN],x[MN],y[MN],finished[MN],a[10000],counter;

int main(int argc, char ** argv)
{  int i,k,i0,r;int xx,kk,start[100];
  SDL_Init(SDL_INIT_VIDEO);srand(time(NULL));
   screen=SDL_SetVideoMode(800,600,32, SDL_HWSURFACE|SDL_DOUBLEBUF);
   white=SDL_MapRGB(screen->format,255,255,255);
   green=SDL_MapRGB(screen->format,0,250,0);
   blue=SDL_MapRGB(screen->format,0,0,250);
   red=SDL_MapRGB(screen->format,255,0,0);
   SDL_FillRect(screen,0,white);  srand(time(NULL));

/**  grid in rectangle M*N  */
for(i=0;i<MN;i++) {x[i]=xorig+step*(i%N); y[i]=yorig+step*(i/N);
		                       filldisc(x[i],y[i],4,red);
                             }
for(i=0;i<MN;i++)
  { k=0;
     if (i-N>=0) n[i][k++]=i-N;
     if (i%N!=0) n[i][k++]=i-1;
    if (i+N<MN) n[i][k++]=i+N;
    if ((i+1)%N !=0) n[i][k++]=i+1;
    nbn[i]=k;
  }
for(i=0;i<MN;i++)  for(k=0;k<nbn[i];k++) linewithwidth(x[i],y[i],x[n[i][k]],y[n[i][k]],0,green);

/**************    random spanning tree with root r=0,                *************/
r=0; finished[r]=1;
for(i0=1;i0<MN;i0++) if (finished[i0]==0)
  { branch(i0);
   for(k=0;k<=counter;k++) finished[a[k]]=1;
   for(k=0;k<counter;k++)
	linewithwidth(x[a[k]],y[a[k]],x[a[k+1]],y[a[k+1]],2,red);
  }

/**   percolation */
k=0;
for(xx=xorig+step/2; xx<xorig+(M-1)*step;xx+=step)
if(getpixel(xx,yorig)==green) start[k++]=xx;
for(kk=0;kk<k;kk++) circle(start[kk],yorig,3,blue);

line(xorig,yorig,xorig+step*(M-1),yorig,red);
line(xorig,yorig,xorig,yorig+step*(N-1)+5,red);
line(xorig+step*(M-1),yorig,xorig+step*(M-1),yorig+step*(N-1)+5,red);
line(xorig,yorig+step*(N-1)+5,xorig+step*(M-1),yorig+step*(N-1)+5,red);

for(kk=0;kk<k;kk++)  floodfill(start[kk],yorig+5,blue,red);

SDL_Flip(screen); pause(); return 0;
}

void branch(int i)
{ int h,j, neighbor,vertex;
  for(j=0;j<10000;j++) a[j]=0;
  vertex=i; counter=0; a[0]=vertex;
  for(;;)
    { vertex=a[counter];
       h=rand()%nbn[vertex]; neighbor=n[vertex][h];
       if (finished[neighbor]==1)
         { line(x[vertex],y[vertex],x[neighbor],y[neighbor],red);
	   	    counter++; a[counter]=neighbor; break;}
       if (wherealreadyseen(neighbor)==-1)	{	counter++;  a[counter]=neighbor;}
       else counter=wherealreadyseen(neighbor);
    }
}


int wherealreadyseen(int v)
{ int j;

for(j=counter;j>=0;j--)
if (v==a[j]) return j;
return -1;
}


void pause(void)
{
    SDL_Event evenement;
    do   SDL_WaitEvent(&evenement);
    while(evenement.type != SDL_QUIT && evenement.type != SDL_KEYDOWN);
}

void putpixel(int xe, int ye, Uint32 couleur)
{ Uint32 * numerocase;
numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;    *numerocase=couleur;
}

Uint32 getpixel(int xe, int ye)
{ Uint32 * numerocase;
   numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;   return (*numerocase);
}

void linewithwidth(int x1, int y1, int x2, int y2, int epaisseur,Uint32 c)
{
int dx,dy;
float k,xf1,yf1,xf2,yf2,d,dx1,dy1,ndx1,ndy1,ndx2,ndy2,angle=M_PI/2.;
line(x1,y1,x2,y2,c);
dx=x2-x1; dy=y2-y1;       d=sqrt(dx*dx+dy*dy);
if (d!=0.)
{ dx1=(float)epaisseur*(float)dx/d; dy1=(float)epaisseur*(float)dy/d;
   ndx1=dx1*cos(angle)-dy1*sin(angle);
   ndy1=dx1*sin(angle)+dy1*cos(angle);
   ndx2=dx1*cos(-angle)-dy1*sin(-angle);
   ndy2=dx1*sin(-angle)+dy1*cos(-angle);
   for(k=0;k<=1.;k+=0.1/d)
   {
   xf1=(1.-k)*x1+k*x2; yf1=(1.-k)*y1+k*y2;
   xf2=xf1-ndx1; yf2=yf1-ndy1;  line(xf1,yf1,xf2,yf2,c);
   xf2=xf1-ndx2; yf2=yf1-ndy2;    line(xf1,yf1,xf2,yf2,c);
   }
}
}

void circle( int xo, int yo, int R, Uint32 couleur)
  {
      int x, y, F, F1, F2,newx,newy;
      x=xo; y=yo+R; F=0;
      if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
      if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, couleur);
      while( y>yo)
         {
             F1=F+2*(x-xo)+1; F2=F-2*(y-yo)+1;
             if ( abs(F1)<abs(F2))  { x+=1; F=F1;}
             else {y-=1; F=F2;}
             if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
              newx=2*xo-x ; newy=2*yo-y ;
             if (x<800 && x>=0 && newy>=0 && newy<600) putpixel(x, newy,couleur);
             if (newx<800 && newx>=0 && y>=0 && y<600) putpixel( newx,y,couleur);
             if (newx<800 && newx>=0 && newy>=0 && newy<600) putpixel(newx,
             newy, couleur);
         }
       if (xo+R<800 && xo+R>=0 && yo>=0 && yo<600) putpixel(xo+R,yo,couleur);
       if (xo-R<800 && xo-R>=0 && yo>=0 && yo<600) putpixel(xo-R,yo, couleur);
  }

void filldisc( int xo, int yo, int R, Uint32 couleur)
  {
      int x, y, F, F1, F2,newx,newy,xx;
      x=xo; y=yo+R; F=0;
      if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
      if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, couleur);
      while( y>yo)
         {
             F1=F+2*(x-xo)+1; F2=F-2*(y-yo)+1;
             if ( abs(F1)<abs(F2))  { x+=1; F=F1;}
             else {y-=1; F=F2;}
             newx=2*xo-x ; newy=2*yo-y ;
             for(xx=newx; xx<=x; xx++)if (xx<800 && xx>=0 && y>=0 && y<600 )
             putpixel(xx,y,couleur);
             for(xx=newx; xx<=x; xx++)if (xx<800 && xx>=0 && newy>=0 && newy<600 )
             putpixel(xx,newy,couleur);
         }
       if (xo+R<800 && xo+R>=0&& y>=0 && y<600) putpixel(xo+R,yo,couleur);
       if (xo-R<800 && xo-R>=0&& y>=0 && y<600) putpixel(xo-R,yo, couleur);
  }
/**  line en marches d'escalier */
void line(int x0,int y0, int x1,int y1, Uint32 c)
{
int dx,dy,x,y,residu,absdx,absdy,pasx,pasy,i;
dx=x1-x0; dy=y1-y0;  residu=0;       x=x0;y=y0;  if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
if (dx>0) pasx=1;else pasx=-1; if (dy>0) pasy=1; else pasy=-1;
absdx=abs(dx);absdy=abs(dy);
if (dx==0) for(i=0;i<absdy;i++) { y+=pasy;
                                                    if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c); }
else if(dy==0) for(i=0;i<absdx;i++){ x+=pasx;
                                                         if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);  }
else if (absdx==absdy)
   for(i=0;i<absdx;i++) {x+=pasx; if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
                                     y+=pasy;
                                     if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
                                     }
else if (absdx>absdy)
          for(i=0;i<absdx;i++)
			  { x+=pasx; if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
			     residu+=absdy;
			     if(residu >= absdx) {residu -=absdx; y+=pasy;
	                              		        if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
			                                    }
			  }
else for(i=0;i<absdy;i++)
             {y+=pasy; if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
               residu +=absdx;
              if (residu>=absdy)   {residu -= absdy;x +=pasx;
                                              if (x>=0 && x<800 && y>=0 && y<600) putpixel(x,y,c);
                                             }
             }
}

void floodfill( int x,int y, Uint32 cr,Uint32 cb)
{  int xg,xd,xx;
    if (getpixel(x,y) !=cb && getpixel(x,y) !=cr)
      { putpixel(x,y,cr);
         xg=x-1;
        while(xg>0 && getpixel(xg,y)!=cb)  {putpixel(xg,y,cr); xg--;}
        xd=x+1;
       while(xd<800 && getpixel(xd,y)!=cb)  {putpixel(xd,y,cr); xd++ ;}
       for(xx=xg; xx<xd;xx++)
          { if (y>1 ) {floodfill(xx,y-1,cr,cb);}
             if (y<599 ) {floodfill(xx,y+1,cr,cb);}
          }
    }
}

