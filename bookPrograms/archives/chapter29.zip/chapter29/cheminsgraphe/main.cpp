/**************       PATHS ON A GRAPH  (-drawings)       ***************/
/**************                   Fig. 29-10                                    ***************/

#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define N 6
#define zoom 39.
void pause(void);
void putpixel(int xe, int ye, Uint32 couleur);
Uint32 getpixel(int xe, int ye);
void line(int x0,int y0, int x1,int y1, Uint32 c);
void linewithwidth(int x1, int y1, int x2, int y2, int epaisseur,Uint32 c);
void drawing(int e);
void tree(int i, int level);
int belonginglistofpred(int j, int e);
SDL_Surface * screen; Uint32 white,black,red;
SDL_Surface *texte;
SDL_Rect position;
TTF_Font *police=NULL;
int n[N][N], pred[N],nbn[N],start,end,count;  int xorig,yorig;
float x[N],y[N] ;  char chiffre[200];

int main(int argc, char ** argv)
{  int i;
   SDL_Init(SDL_INIT_VIDEO);    TTF_Init();
   screen=SDL_SetVideoMode(800,600,32, SDL_HWSURFACE|SDL_DOUBLEBUF);
   white=SDL_MapRGB(screen->format,255,255,255);
   black=SDL_MapRGB(screen->format,0,0,0);
   red=SDL_MapRGB(screen->format,255,0,0);
   SDL_FillRect(screen,0,white);
    police=TTF_OpenFont("times.ttf",25);
    SDL_Color blackcolor={0,0,0};
    texte=TTF_RenderText_Solid(police,"ALL ROUTES ",blackcolor);
    position.x=300; position.y=470;
    SDL_BlitSurface(texte,NULL,screen,&position);

   x[0]=0.; y[0]=2.;   x[5]=0.; y[5]=-2.;
   x[1]=-1.; y[1]=1.;  x[2]=1.; y[2]=1.;
   x[3]=-1.; y[3]=-1.;  x[4]=1.; y[4]=-1.;

   xorig=2.*zoom; yorig=3.*zoom;
   police=TTF_OpenFont("times.ttf",20);
   for(i=0;i<N;i++)
      {  sprintf( chiffre,"%d",i);
          texte=TTF_RenderText_Solid(police,chiffre,blackcolor);
          position.x=xorig+zoom*x[i]-10; position.y=yorig-zoom*y[i]-23;
          SDL_BlitSurface(texte,NULL,screen,&position);
      }

    n[0][0]=1; n[0][1]=2;   nbn[0]=2;
    n[1][0]=0; n[1][1]=2;  n[1][2]=3;  nbn[1]=3;
    n[2][0]=0; n[2][1]=1;  n[2][2]=3;  n[2][3]=4;  nbn[2]=4;
    n[3][0]=1; n[3][1]=2;  n[3][2]=4;  n[3][3]=5;  nbn[3]=4;
    n[4][0]=2; n[4][1]=3;  n[4][2]=5;  nbn[4]=3;
    n[5][0]=3; n[5][1]=4;  nbn[5]=2;

    start=0;end=5;
    tree(start,0);

    sprintf( chiffre,"GOING FROM %d TO %d",start,end);
    texte=TTF_RenderText_Solid(police,chiffre,blackcolor);
    position.x=300; position.y=500;
    SDL_BlitSurface(texte,NULL,screen,&position);

    SDL_Flip(screen);pause();  TTF_CloseFont(police); TTF_Quit();  return 0;
}

void tree(int i, int level)
{ int j,neighbour;
   if (i==end) { count++;  drawing(level);    }
   else
   { for(j=0;j<nbn[i];j++)
     { neighbour=n[i][j];    if(belonginglistofpred(neighbour,level)==0)
            { pred[level+1]=i; tree(neighbour,level+1);      }
     }
   }
}
  int belonginglistofpred(int j, int levl)
  { int k;
     for(k=1;k<=levl;k++)    if(j==pred[k]) return 1;
     return 0;
  }

 void drawing(int e)
 {   int i,j;
     for(i=0;i<N;i++)
     for(j=0;j<nbn[i];j++)
     line(xorig+zoom*x[i],yorig-zoom*y[i], xorig+zoom*x[n[i][j]],yorig-zoom*y[n[i][j]], black);

     for(j=1;j<e;j++)
     linewithwidth(xorig+zoom*x[pred[j]] , yorig-zoom*y[pred[j]] ,
             xorig+zoom*x[pred[j+1]] ,  yorig-zoom*y[pred[j+1]] , 3, red);
      linewithwidth(xorig+zoom*x[pred[e]] , yorig-zoom*y[pred[e]] ,
             xorig+zoom*x[end] ,  yorig-zoom*y[end] , 3, red);
     SDL_Flip(screen);
     xorig+=3.*zoom; if (xorig>700) {yorig+=5.*zoom; xorig= 2.*zoom;}
 }

void pause(void)
{
    SDL_Event evenement;
    do   SDL_WaitEvent(&evenement);
    while(evenement.type != SDL_QUIT && evenement.type != SDL_KEYDOWN);
}

void putpixel(int xe, int ye, Uint32 couleur)
{ Uint32 * numerocase;
numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;    *numerocase=couleur;
}

Uint32 getpixel(int xe, int ye)
{ Uint32 * numerocase;
   numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;   return (*numerocase);
}


void line(int x0,int y0, int x1,int y1, Uint32 c)
{
int dx,dy,x,y,residu,absdx,absdy,pasx,pasy,i;
dx=x1-x0; dy=y1-y0;  residu=0;       x=x0;y=y0;  putpixel(x,y,c);
if (dx>0) pasx=1;else pasx=-1; if (dy>0) pasy=1; else pasy=-1;
absdx=abs(dx);absdy=abs(dy);
if (dx==0) for(i=0;i<absdy;i++) { y+=pasy;
                                                    putpixel(x,y,c); }
else if(dy==0) for(i=0;i<absdx;i++){ x+=pasx;
                                                         putpixel(x,y,c);  }
else if (absdx==absdy)
   for(i=0;i<absdx;i++) {x+=pasx; y+=pasy;
                                     putpixel(x,y,c);
                                     }
else if (absdx>absdy)
          for(i=0;i<absdx;i++)
			  { x+=pasx; residu+=absdy;
			     if(residu >= absdx) {residu -=absdx; y+=pasy;}
			     putpixel(x,y,c);
			  }
else for(i=0;i<absdy;i++)
             {y+=pasy; residu +=absdx;
              if (residu>=absdy)   {residu -= absdy;x +=pasx;}
              putpixel(x,y,c);
             }
}

void linewithwidth(int x1, int y1, int x2, int y2, int epaisseur,Uint32 c)
{
int dx,dy;
float k,xf1,yf1,xf2,yf2,d,dx1,dy1,ndx1,ndy1,ndx2,ndy2,angle=M_PI/2.;
line(x1,y1,x2,y2,c);
dx=x2-x1; dy=y2-y1;       d=sqrt(dx*dx+dy*dy);
if (d!=0.)      /* si le vecteur n’est pas nul */
{ dx1=(float)epaisseur*(float)dx/d; dy1=(float)epaisseur*(float)dy/d;
   ndx1=dx1*cos(angle)-dy1*sin(angle);
   ndy1=dx1*sin(angle)+dy1*cos(angle);
   ndx2=dx1*cos(-angle)-dy1*sin(-angle);
   ndy2=dx1*sin(-angle)+dy1*cos(-angle);
   for(k=0;k<=1.;k+=0.1/d)
   {
   xf1=(1.-k)*x1+k*x2; yf1=(1.-k)*y1+k*y2;
   xf2=xf1-ndx1; yf2=yf1-ndy1;  line(xf1,yf1,xf2,yf2,c);
   xf2=xf1-ndx2; yf2=yf1-ndy2;    line(xf1,yf1,xf2,yf2,c);
   }
}
}





