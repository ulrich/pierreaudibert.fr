/************          PATHS ON A GRAPH  (print)           *****************/
/************                      Fig. 29-10                                *****************/
#include <stdio.h>
#include <stdlib.h>
#define N 6     /** can be changed */
void path(int i, int level);
int belonginglistofpred(int j, int e);
int n[N][N], pred[N],nbn[N],start,end,count;

int main()
{  n[0][0]=1; n[0][1]=2;   nbn[0]=2;
    n[1][0]=0; n[1][1]=2;  n[1][2]=3;  nbn[1]=3;
    n[2][0]=0; n[2][1]=1;  n[2][2]=3;  n[2][3]=4;  nbn[2]=4;
    n[3][0]=1; n[3][1]=2;  n[3][2]=4;  n[3][3]=5;  nbn[3]=4;
    n[4][0]=2; n[4][1]=3;  n[4][2]=5;  nbn[4]=3;
    n[5][0]=3; n[5][1]=4;  nbn[5]=5;
    start=0;end=5;
    path(start,0);
    return 0;
}

void path(int i, int level)
{ int j,neighbour;
   if (i==end) { count++; printf("%3.d: ",count);
                            for(j=1;j<=level;j++) printf("%d ",pred[j]);
                            printf("%d ",end);   printf("\n");
                         }
   else
   { for(j=0;j<nbn[i];j++)
     { neighbour=n[i][j];
        if(belonginglistofpred(neighbour,level)==0)
            { pred[level+1]=i; path(neighbour,level+1);
            }
     }
   }
}
  int belonginglistofpred(int j, int levl)
     { int k;
     for(k=1;k<=levl;k++)
     if(j==pred[k]) return 1;
     return 0;
     }
