/***********   ALL  THE GRAPHS WITH N NODES     **************/
/***********   (and the connected graphs in particular    **************/
/***********                    Fig. 29-4                                     **************/
#include <SDL/SDL.h>
#include <math.h>
#include <stdio.h>
#define deuxpi 6.28318
#define N 5   /** can be changed */
#define radius 20
void drawingnodes(void);
void explore(int j);
void pause(void);
void putpixel(int xe, int ye, Uint32 couleur);
Uint32 getpixel(int xe, int ye);
void circle( int xo, int yo, int R, Uint32 couleur);
void line(int x0,int y0, int x1,int y1, Uint32 c);
SDL_Surface * screen; Uint32 white,black,red;
int edge[N*(N-1)/2],r[N*(N-1)/2],xorig,yorig,x[N],y[N],NE,n[N][N],nbn[N];
int start[N*(N-1)/2],end[N*(N-1)/2],alreadyseen[N],numbernodes,numberconnected;

int main(int argc, char ** argv)
{   int i, j,k,q,xstart,xend,ystart,yend;
    SDL_Init(SDL_INIT_VIDEO);
    screen=SDL_SetVideoMode(800,600,32, SDL_HWSURFACE|SDL_DOUBLEBUF);
    white=SDL_MapRGB(screen->format,255,255,255);
    black=SDL_MapRGB(screen->format,0,0,0);
    red=SDL_MapRGB(screen->format,255,0,0);
    SDL_FillRect(screen,0,white);
    xorig=radius+10; yorig=radius+10;
    k=0;   for(i=0;i<N-1;i++) for(j=i+1;j<N;j++)  edge[k++]=N*i+j;
    NE=N*(N-1)/2;
    for(i=0;i<pow(2,NE);i++)
     {
       drawingnodes();
       q=i;
       for(j=0;j<NE;j++)
         {  r[j]=q%2;
             if (r[j]==1)
                {  start[j]=edge[j]/N; end[j]=edge[j]%N;
                    xstart=x[start[j]]; ystart=y[start[j]]; xend=x[end[j]]; yend=y[end[j]];
                    line(xstart,ystart,xend,yend,black);
                }
            q=q/2;
         }
       for(k=0;k<N;k++) nbn[k]=0;
       for(k=0;k<NE;k++) if (r[k]==1)
         { n[start[k]] [nbn[start[k]]++] = end[k];
           n[end[k]][nbn[end[k]]++] = start[k];
         }
         /** exploration */
       numbernodes=0; for(k=0;k<N;k++) alreadyseen[k]=0;
       explore(0);
       if (numbernodes==N)
            {circle(xorig, yorig,radius+9,red);
               numberconnected++;
            }

      xorig+= 2*radius+40; if (xorig>750) {yorig+=2*radius+20; xorig=radius+10;}
      if (yorig>550) {SDL_Flip(screen); pause();
                              SDL_FillRect(screen,0,white);
                              xorig=10+radius; yorig=10+radius;
                              }
   }
   SDL_Flip(screen);pause();
   printf("N=%d  \nNumber of connected graphs: %d ",N,numberconnected); pause();
   return 0;
}

void drawingnodes(void)
{ int j;
    for(j=0;j<N;j++)
        {  x[j]=xorig+radius*cos(deuxpi*j/(float)N);
            y[j]=yorig-radius*sin(deuxpi*j/(float)N);     circle(x[j],y[j],2,black);
        }
}

void explore(int i)
{ int j,neighbor;
   numbernodes++;
   alreadyseen[i]=1;
   for(j=0;j<nbn[i];j++)
     { neighbor=n[i][j];
        if (alreadyseen[neighbor]==0) explore(neighbor);
     }
}

void pause(void)
{
    SDL_Event evenement;
    do   SDL_WaitEvent(&evenement);
    while(evenement.type != SDL_QUIT && evenement.type != SDL_KEYDOWN);
}


void putpixel(int xe, int ye, Uint32 couleur)
{ Uint32 * numerocase;
numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;    *numerocase=couleur;
}

Uint32 getpixel(int xe, int ye)
{ Uint32 * numerocase;
   numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;   return (*numerocase);
}

void circle( int xo, int yo, int R, Uint32 couleur)
  {
      int x, y, F, F1, F2,newx,newy;
      x=xo; y=yo+R; F=0;
      if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
      if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, couleur);
      while( y>yo)
         {
             F1=F+2*(x-xo)+1; F2=F-2*(y-yo)+1;
             if ( abs(F1)<abs(F2))  { x+=1; F=F1;}
             else {y-=1; F=F2;}
             if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
              newx=2*xo-x ; newy=2*yo-y ;
             if (x<800 && x>=0 && newy>=0 && newy<600) putpixel(x, newy,couleur);
             if (newx<800 && newx>=0 && y>=0 && y<600) putpixel( newx,y,couleur);
             if (newx<800 && newx>=0 && newy>=0 && newy<600) putpixel(newx,
             newy, couleur);
         }
       if (xo+R<800 && xo+R>=0) putpixel(xo+R,yo,couleur);
       if (xo-R<800 && xo-R>=0) putpixel(xo-R,yo, couleur);
  }

void line(int x0,int y0, int x1,int y1, Uint32 c)
{
int dx,dy,x,y,residu,absdx,absdy,pasx,pasy,i;
dx=x1-x0; dy=y1-y0;  residu=0;       x=x0;y=y0;  putpixel(x,y,c);
if (dx>0) pasx=1;else pasx=-1; if (dy>0) pasy=1; else pasy=-1;
absdx=abs(dx);absdy=abs(dy);
if (dx==0) for(i=0;i<absdy;i++) { y+=pasy;
                                                    putpixel(x,y,c); }
else if(dy==0) for(i=0;i<absdx;i++){ x+=pasx;
                                                         putpixel(x,y,c);  }
else if (absdx==absdy)
   for(i=0;i<absdx;i++) {x+=pasx; y+=pasy;
                                     putpixel(x,y,c);
                                     }
else if (absdx>absdy)
          for(i=0;i<absdx;i++)
			  { x+=pasx; residu+=absdy;
			     if(residu >= absdx) {residu -=absdx; y+=pasy;}
			     putpixel(x,y,c);
			  }
else for(i=0;i<absdy;i++)
             {y+=pasy; residu +=absdx;
              if (residu>=absdy)   {residu -= absdy;x +=pasx;}
              putpixel(x,y,c);
             }
}

