/**********         TRIANGLES WITH PERIMETER FIXED          ***********/
#include <SDL/SDL_ttf.h>
#include <stdio.h>
#include <math.h>
#define n 40
#define zoom 12.
void pause(void);
void putpixel(int xe, int ye, Uint32 c);
Uint32 getpixel(int xe, int ye);
void line(int x0,int y0, int x1,int y1, Uint32 c);
void circle( int xo, int yo, int R, Uint32 c);
SDL_Surface * screen, *rectangle; Uint32 white,black;
SDL_Surface *texte;  SDL_Rect position;TTF_Font *police=NULL;char chiffre[2000];

int main ( int argc, char** argv )
{   int x,y,z,a,b,c; float xa,ya,B,slope,C,slope2; int xea,yea,xeb,yeb,xec,yec;
    float xx,yy,alpha,beta; int xe,ye,k,xdebut;
    int xorig=10; int yorig=100;
    SDL_Init(SDL_INIT_VIDEO);
    screen=SDL_SetVideoMode(800,600,32, SDL_HWSURFACE|SDL_DOUBLEBUF);
    white=SDL_MapRGB(screen->format,255,255,255);
    black=SDL_MapRGB(screen->format,0,0,0);
    SDL_FillRect(screen,0,white);

    TTF_Init();
    police=TTF_OpenFont("times.ttf",20);
    SDL_Color cnoire={0,0,0};
    sprintf( chiffre," Triangles with perimeter %d",n);
    texte=TTF_RenderText_Solid(police,chiffre,cnoire);
    position.x=10; position.y=10;
    SDL_BlitSurface(texte,NULL,screen,&position);

    if (n%2==1) xdebut=1; else xdebut=2;
    for(x=xdebut;3*x<=n;x+=2)  for(y=0; 4*y<=n-3*x;y++)  for(z=0;2*z<=n-4*y-3*x;z++)
    if (3*x+4*y+2*z==n)
     { a=x+2*y+z; b=x+y+z;c=x+y;
        sprintf( chiffre,"(%d %d %d)",a,b,c);
        texte=TTF_RenderText_Solid(police,chiffre,cnoire);
        position.x=xorig; position.y=yorig;
        SDL_BlitSurface(texte,NULL,screen,&position);
        xa=(float)(a*a+c*c-b*b)/(float)(2.*a);
        B=acos(xa/c); slope=tan(B);ya=slope*xa;
        xeb=xorig;yeb=yorig;
        xec=xorig+zoom*a; yec=yorig;
        xea=xorig+zoom*xa;yea=yorig-zoom*ya;
        line(xea,yea,xeb,yeb,black); line(xeb,yeb,xec,yec,black); line(xec,yec,xea,yea,black);
        alpha=(float)a /(float)a; beta=0.;
        for(k=0;k<=a;k++)
          { xx=k*alpha;yy=0.;
            xe=xorig+zoom*xx;ye=yorig;
            circle(xe,ye,2,black);
          }
        alpha=1; beta=slope;
        alpha=alpha/sqrt(1.+beta*beta); beta=beta/sqrt(1+beta*beta);
        for(k=0;k<=c;k++)
         { xx=k*alpha;yy=k*beta;
            xe=xorig+zoom*xx;ye=yorig-zoom*yy;
            circle(xe,ye,2,black);
         }
       C=acos(((float)a-(float)c*cos(B))/(float)b); slope2=tan(C);
       alpha=-1; beta=slope2;
       alpha=alpha/sqrt(1.+beta*beta); beta=beta/sqrt(1+beta*beta);
       for(k=0;k<=b;k++)
        { xx=(float)a+k*alpha;yy=k*beta;
          xe=xorig+zoom*xx;ye=yorig-zoom*yy;
          circle(xe,ye,2,black);
        }
      xorig+=zoom*n/2; if (xorig>800-zoom*n/2) {xorig=10; yorig+=zoom*n/3;}
      if (yorig>600-zoom*n/4)
          {SDL_Flip(screen);pause(); SDL_FillRect(screen,0,white);xorig=10; yorig=140;}
    }
SDL_Flip(screen);pause(); TTF_CloseFont(police); TTF_Quit();return 0;
}

void pause(void)
{  SDL_Event evenement;
    do   SDL_WaitEvent(&evenement);
    while(evenement.type != SDL_QUIT && evenement.type != SDL_KEYDOWN);
}

void putpixel(int xe, int ye, Uint32 c)
{ Uint32 * boxnumber;
boxnumber= (Uint32 *)(screen->pixels)+xe+ye*screen->w;    *boxnumber=c;
}

Uint32 getpixel(int xe, int ye)
{ Uint32 * boxnumber;
   boxnumber= (Uint32 *)(screen->pixels)+xe+ye*screen->w;   return (*boxnumber);
}

void line(int x0,int y0, int x1,int y1, Uint32 c)
{
int dx,dy,x,y,residu,absdx,absdy,pasx,pasy,i;
dx=x1-x0; dy=y1-y0;  residu=0;       x=x0;y=y0;  putpixel(x,y,c);
if (dx>0) pasx=1;else pasx=-1; if (dy>0) pasy=1; else pasy=-1;
absdx=abs(dx);absdy=abs(dy);
if (dx==0) for(i=0;i<absdy;i++) { y+=pasy;
                                                    putpixel(x,y,c); }
else if(dy==0) for(i=0;i<absdx;i++){ x+=pasx;
                                                         putpixel(x,y,c);  }
else if (absdx==absdy)
   for(i=0;i<absdx;i++) {x+=pasx; y+=pasy;
                                     putpixel(x,y,c);
                                     }
else if (absdx>absdy)
          for(i=0;i<absdx;i++)
			  { x+=pasx; residu+=absdy;
			     if(residu >= absdx) {residu -=absdx; y+=pasy;}
			     putpixel(x,y,c);
			  }
else for(i=0;i<absdy;i++)
             {y+=pasy; residu +=absdx;
              if (residu>=absdy)   {residu -= absdy;x +=pasx;}
              putpixel(x,y,c);
             }
}

void circle( int xo, int yo, int R, Uint32 c)
  {
      int x, y, F, F1, F2,newx,newy;
      x=xo; y=yo+R; F=0;
      if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,c);
      if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, c);
      while( y>yo)
         {
             F1=F+2*(x-xo)+1; F2=F-2*(y-yo)+1;
             if ( abs(F1)<abs(F2))  { x+=1; F=F1;}
             else {y-=1; F=F2;}
             if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,c);
              newx=2*xo-x ; newy=2*yo-y ;
             if (x<800 && x>=0 && newy>=0 && newy<600) putpixel(x, newy,c);
             if (newx<800 && newx>=0 && y>=0 && y<600) putpixel( newx,y,c);
             if (newx<800 && newx>=0 && newy>=0 && newy<600) putpixel(newx,
             newy, c);
         }
       if (xo+R<800 && xo+R>=0) putpixel(xo+R,yo,c);
       if (xo-R<800 && xo-R>=0) putpixel(xo-R,yo, c);
  }



