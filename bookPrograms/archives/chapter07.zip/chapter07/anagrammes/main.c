/**********************           ANAGRAMS            *********************/
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#define NBletters 4
void display(void);
int NB[NBletters],N,a[100],count;

int main()
{  int letter,i,k,aux,pospivot,possubstitute,g,d;
    NB[0]=3; NB[1]=2; NB[2]=1; NB[3]=1;
    N=0;
    for(letter=0;letter<NBletters; letter++) N+=NB[letter];
    printf("ANAGRAMS,  LENGTH %d, WITH ",N);
    for(letter=0; letter<NBletters; letter++) printf("%d  LETTER(S) %d   ",NB[letter], letter);
    printf("\n\n");
    k=0; count=0;
    for(letter=0; letter<NBletters;letter++) for(i=0;i<NB[letter];i++) a[k++]=letter;
    for(;;)
      {
          count++; display();
          i=N-1; while(i>=1 && a[i]<=a[i-1] )i--;
          pospivot=i-1; if(pospivot==-1) break;
          i=N-1; while(a[i]<=a[pospivot]) i--;
          possubstitute=i;
          aux=a[pospivot]; a[pospivot]=a[possubstitute]; a[possubstitute]=aux;
          g=pospivot+1; d= N-1;
          while(g<d) {aux=a[g];a[g]=a[d]; a[d]=aux; g++; d--;}
      }
    getch();return 0;
}
void display(void)
  {  int i;
      printf("   %3.d : ",count);
      for(i=0;i<N;i++) printf("%d",a[i]);
  }
