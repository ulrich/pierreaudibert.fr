/************             PALM TREE GROVE    -  ANNEX         ************/
/****    N^2  numbers from 0 to N^2 - 1.  Number of ways to take N of these numbers
             with a sum of   N(N^2 - 1) /2                                                                      ****/


#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#define N 6    /****** N can be changed  *******/
#define NN  (N*N)
void tree( int i,int level, int weight);
int counter,S,predecessor[N];

/***
int main()
{  int i,j,k;
   S=(NN-1)*N/2;
   for(i=0;i<=N*(N-1)/2;i++) for(j=i+1;j<NN;j++) for(k=j+1;k<NN;k++)
   if (i+j+k==S) {counter++; printf("\n%3.d : (%d %d %d) ",counter,i,j,k);}
   getch();
    return 0;
}
****/

int main()
{  int i;
   S=(NN-1)*N/2;
   for(i=0;i<=S/(N+1);i++) tree(i,0,i);
   printf(" ******  %d  ******", counter);
   getch();
    return 0;
}

void tree( int i,int level, int weight)
  {   int k;
      if (level==N-1 && weight==S)
         { counter++;
            printf("%d : ",counter);
            for (k=1;k<=level;k++) printf("%d ", predecessor[k]);
            printf("%d \n",i);
         }
      else if (weight<S && level<N-1)
      for(k=i+1;k<NN;k++)
         { predecessor[level+1]=i;
            tree(k,level+1,weight+k);
         }
  }



