/**************           ABU KAMIL PROBLEM               ******************/
#include <stdio.h>
#include <conio.h>

main()
{
int x,y,z,t,u,count=0;int count1=0,count2=0,count3=0;

for(x=1;x<=93;x++) for(y=1;y<=100-x-6;y++)
for(z=3;z<=100-x-y-3;z+=3) for(t=2;t<=100-x-y-z-1;t+=2)
 {
 u=100-x-y-z-t;
 if (4*x+y+2*(z/3)+(t/2)+2*u==200)
   {
   count++;
   printf("\n%3.3d: %d %d %d %d %d ",count,x,y,z,t,u);
   if (y%2==1) count1++; else count2++;
   if (t%4==2 && y%2==1) {printf("*");count3++;}
   }
 }
printf("\n\n%d   %d",count1, count2);


/****   Abu Kamil  method   *****/
printf("\n\n Abu Kamil method :");

count1=0;count2=0;
for(y=1;y<=59;y+=2) for(z=3;z<=54;z+=3) for(t=2;t<=50;t+=4)
if (2*3*y/2+2*5*z/3+2*7*t/4<200) {count1++; }
for(y=2;y<=58;y+=2) for(z=3;z<=51;z+=3) for(t=4;t<=52;t+=4)
if (3*y/2+5*z/3+7*t/4<100) {count2++;}
printf("\n\n*** %d  %d",count1,count2);

/******  Abu Kamil  method  (bis) *****/

count1=0;count2=0;
for(y=1;y<=59;y+=2) for(z=3;z<=54;z+=3)  for(t=2;t<=50;t+=4)
if ((6*y+7*t)/4+5*z/3<100)   {count1++; }
for(y=2;y<=58;y+=2) for(z=3;z<=51;z+=3) for(t=4;t<=52;t+=4)
if (3*y/2+5*z/3+7*t/4<100)   {count2++; }
printf("\n\n*** %d  %d",count1,count2);

getch(); return 0;
}


