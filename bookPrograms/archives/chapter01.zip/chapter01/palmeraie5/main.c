/*************           PALM GROVE PROBLEM             ***************/
/****  N=5.   25 numbers (palm trees)  from 0 to 24, to be placed in five parcels,
                       each having a sum of 60                                                         ****/

#include <stdio.h>
#include <conio.h>
int done1[25],done2[25],done3[25],done4[25],a[25];

int main()
{
int first1,j,k,l,n,jj,kk,ll,first2,first3,first4,jjj,kkk,lll,m,mm,mmm,jjjj,kkkk,llll,mmmm;
int counter; int  count;
counter=0;
first1=0; for(j=1;j<=21;j++) for(k=j+1;k<=22;k++) for(l=k+1;l<=23;l++) for(m=l+1; m<=24; m++)
if (first1+j+k+l+m==60)
  { for(n=0;n<25;n++) done1[n]=0;
     done1[first1]=1;done1[j]=1;done1[k]=1;done1[l]=1; done1[m]=1;
      for(n=0;n<25;n++) if (done1[n]==0) { first2=n; break; }
     for(jj=first2+1;jj<=21;jj++)  if (done1[jj]==0)
     for(kk=jj+1;kk<=22;kk++)  if (done1[kk]==0)
     for(ll=kk+1;ll<=23;ll++)  if (done1[ll]==0)
     for(mm=ll+1;mm<=24;mm++)  if (done1[mm]==0)
     if (first2+jj+kk+ll+mm==60)
       { for(n=0;n<25;n++) done2[n]=0;
         done2[first2]=1;done2[jj]=1;done2[kk]=1;done2[ll]=1; done2[mm]=1;
         for(n=0;n<25;n++) if (done1[n]==0 && done2[n]==0) { first3=n; break; }
         for(jjj=first3+1;jjj<=21;jjj++)  if (done1[jjj]==0 && done2[jjj]==0)
         for(kkk=jjj+1;kkk<=22;kkk++)  if (done1[kkk]==0 && done2[kkk]==0)
         for(lll=kkk+1;lll<=23;lll++)  if (done1[lll]==0 && done2[lll]==0)
         for(mmm=lll+1;mmm<=24;mmm++)  if (done1[mmm]==0 && done2[mmm]==0)
         if (first3+jjj+kkk+lll+mmm==60)
            { for(n=0;n<25;n++) done3[n]=0;
              done3[first3]=1;done3[jjj]=1;done3[kkk]=1;done3[lll]=1; done3[mmm]=1;
              for(n=0;n<25;n++) if (done1[n]==0 && done2[n]==0 && done3[n]==0) { first4=n; break; }
              for(jjjj=first4+1;jjjj<=21;jjjj++)   if (done1[jjjj]==0 && done2[jjjj]==0 && done3[jjjj]==0)
              for(kkkk=jjjj+1;kkkk<=22;kkkk++)  if (done1[kkkk]==0 && done2[kkkk]==0 && done3[kkkk]==0)
              for(llll=kkkk+1;llll<=23;llll++)  if (done1[llll]==0 && done2[llll]==0 && done3[llll]==0)
              for(mmmm=llll+1;mmmm<=24;mmmm++)  if (done1[mmmm]==0 && done2[mmmm]==0 && done3[mmmm]==0)
              if (first4+jjjj+kkkk+llll+mmmm==60)
                { for(n=0;n<25;n++) done4[n]=0;
                   done4[first4]=1;done4[jjjj]=1;done4[kkkk]=1;done4[llll]=1; done4[mmmm]=1;
                   counter++;
                   count=0;
                   for(n=0;n<25;n++) if (done1[n]==1) { a[count++]=n;}
                   for(n=0;n<25;n++) if (done2[n]==1) {a[count++]=n;}
                   for(n=0;n<25;n++) if (done3[n]==1) {a[count++]=n;}
                   for(n=0;n<25;n++) if (done4[n]==1) {a[count++]=n;}
                  for(n=0;n<25;n++)
                  if (done1[n]==0 && done2[n]==0 && done3[n]==0 && done4[n]==0)  {  a[count++]=n;}
                  /*printf("%d: (",counter);
                    for(count=0;count<25;count++)
	                    { if (count>0 && count%5==0) printf(") ("); printf("%d ",a[count]); }
                  printf(")\n");
                  */
               }
           }
       }
   }
printf("\nNumber of solutions: %d ", counter); getch();
return 0;
}
