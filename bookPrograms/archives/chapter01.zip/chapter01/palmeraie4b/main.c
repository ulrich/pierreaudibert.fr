/*************           PALM GROVE PROBLEM             ***************/
/****  N=4.   16 numbers (palm trees)  from 0 to 15, to be placed in four parcels,
                       each having a sum of 30                                                         ****/

#include <stdio.h>
#include <conio.h>
int done1[16],done2[16],done3[16],done4[16],a[16];

int main()
{
int first1,j,k,l,n,jj,kk,ll,first2,first3,jjj,kkk,lll;int counter; int  count;
counter=0;
first1=0; for(j=1;j<=13;j++) for(k=j+1;k<=14;k++) for(l=k+1;l<=15;l++)
if (first1+j+k+l==30)
  { for(n=0;n<16;n++) done1[n]=0; done1[first1]=1;done1[j]=1;done1[k]=1;done1[l]=1;
      for(n=0;n<16;n++) if (done1[n]==0) { first2=n; break; }
     for(jj=first2+1;jj<=13;jj++)  if (done1[jj]==0)
     for(kk=jj+1;kk<=14;kk++)  if (done1[kk]==0)
     for(ll=kk+1;ll<=15;ll++)  if (done1[ll]==0)
     if (first2+jj+kk+ll==30)
       { for(n=0;n<16;n++) done2[n]=0;
         done2[first2]=1;done2[jj]=1;done2[kk]=1;done2[ll]=1;
         for(n=0;n<16;n++) if (done1[n]==0 && done2[n]==0) { first3=n; break; }
         for(jjj=first3+1;jjj<=13;jjj++)  if (done1[jjj]==0 && done2[jjj]==0)
         for(kkk=jjj+1;kkk<=14;kkk++)  if (done1[kkk]==0 && done2[kkk]==0)
         for(lll=kkk+1;lll<=15;lll++)  if (done1[lll]==0 && done2[lll]==0)
         if (first3+jjj+kkk+lll==30)
            { for(n=0;n<16;n++) done3[n]=0;
              done3[first3]=1;done3[jjj]=1;done3[kkk]=1;done3[lll]=1;
              counter++;
              count=0;
              for(n=0;n<16;n++) if (done1[n]==1) { a[count++]=n;}
              for(n=0;n<16;n++) if (done2[n]==1) {a[count++]=n;}
              for(n=0;n<16;n++) if (done3[n]==1) {a[count++]=n;}
              for(n=0;n<16;n++)
              if (done1[n]==0 && done2[n]==0 && done3[n]==0)  {  a[count++]=n;}
              printf("%d: ( ",counter);
              for(count=0;count<16;count++)
	                    { if (count>0 && count%4==0) printf(")  ("); printf("%d ",a[count]); }
              printf(")\n");
           }
       }
   }
printf("\nNumber of solutions: %d ", counter); getch();
return 0;
}
