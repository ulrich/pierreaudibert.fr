/****       PATHS WITH FIXED LENGTH ,WITHOUT INTERDECTION     ****/
#include <SDL/SDL.h>
#include <stdio.h>
#define N 6
#define zoom 8
void pause(void);
void putpixel(int xe, int ye, Uint32 couleur);
Uint32 getpixel(int xe, int ye);
void line(int x0,int y0, int x1,int y1, Uint32 c);
void circle( int xo, int yo, int R, Uint32 couleur);
void explore(int xx, int yy, int forbidden, int n);
int x[N+1],y[N+1],xorig,yorig;
int count=0;
SDL_Surface * screen, *rectangle; Uint32 white,black;

int main ( int argc, char** argv )
{  SDL_Init(SDL_INIT_VIDEO);
    screen=SDL_SetVideoMode(800,600,32, SDL_HWSURFACE|SDL_DOUBLEBUF);
    white=SDL_MapRGB(screen->format,255,255,255);
    black=SDL_MapRGB(screen->format,0,0,0);
    xorig=0; yorig=60;
    SDL_FillRect(screen,0,white);
    x[0]=0;y[0]=0; x[1]=0;y[1]=1;
    explore(0,1,3,1);
    printf("  Nombre(%d)=%ld",N,count);
    pause(); return 0;
}

void  explore (int xx, int yy, int forbidden, int n)
{  int i,dx,dy,j,alreadyfound,newx,newy;
    if (n==N)
      { count++; xorig+=50; if (xorig>750) {yorig+=65; xorig=50; }
         if (yorig>550){pause();SDL_FillRect(screen,0,white);yorig=60; xorig=50; }
         circle(xorig+zoom*x[0],yorig-zoom*y[0],2,black);
         for(j=0;j<N;j++)
         line(xorig+zoom*x[j],yorig-zoom*y[j],xorig+zoom*x[j+1],yorig-zoom*y[j+1],black);
         SDL_Flip(screen);
      }
    else
      { for(i=0;i<4;i++)   if (i!=forbidden)
          { dx=((i+1)%2)*(1-i); dy=(i%2)*(2-i);
             newx=xx+dx;newy=yy+dy;     alreadyfound=0;
             for(j=0;j<=n;j++)   if (newx==x[j] && newy==y[j])
                {alreadyfound=1; break;}
             if (alreadyfound==0)
                { x[n+1]=newx;y[n+1]=newy;  explore(newx,newy,(i+2)%4,n+1);  }
          }
      }
}

void pause(void)
{  SDL_Event evenement;
    do   SDL_WaitEvent(&evenement);
    while(evenement.type != SDL_QUIT && evenement.type != SDL_KEYDOWN);
}

void putpixel(int xe, int ye, Uint32 couleur)
{ Uint32 * boxnumber;
boxnumber= (Uint32 *)(screen->pixels)+xe+ye*screen->w;    *boxnumber=couleur;
}

Uint32 getpixel(int xe, int ye)
{ Uint32 * boxnumber;
   boxnumber= (Uint32 *)(screen->pixels)+xe+ye*screen->w;   return (*boxnumber);
}

void line(int x0,int y0, int x1,int y1, Uint32 c)
{
int dx,dy,x,y,residu,absdx,absdy,pasx,pasy,i;
dx=x1-x0; dy=y1-y0;  residu=0;       x=x0;y=y0;  putpixel(x,y,c);
if (dx>0) pasx=1;else pasx=-1; if (dy>0) pasy=1; else pasy=-1;
absdx=abs(dx);absdy=abs(dy);
if (dx==0) for(i=0;i<absdy;i++) { y+=pasy;
                                                    putpixel(x,y,c); }
else if(dy==0) for(i=0;i<absdx;i++){ x+=pasx;
                                                         putpixel(x,y,c);  }
else if (absdx==absdy)
   for(i=0;i<absdx;i++) {x+=pasx; y+=pasy;
                                     putpixel(x,y,c);
                                     }
else if (absdx>absdy)
          for(i=0;i<absdx;i++)
			  { x+=pasx; residu+=absdy;
			     if(residu >= absdx) {residu -=absdx; y+=pasy;}
			     putpixel(x,y,c);
			  }
else for(i=0;i<absdy;i++)
             {y+=pasy; residu +=absdx;
              if (residu>=absdy)   {residu -= absdy;x +=pasx;}
              putpixel(x,y,c);
             }
}

void circle( int xo, int yo, int R, Uint32 couleur)
  {
      int x, y, F, F1, F2,newx,newy;
      x=xo; y=yo+R; F=0;
      if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
      if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, couleur);
      while( y>yo)
         {
             F1=F+2*(x-xo)+1; F2=F-2*(y-yo)+1;
             if ( abs(F1)<abs(F2))  { x+=1; F=F1;}
             else {y-=1; F=F2;}
             if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
              newx=2*xo-x ; newy=2*yo-y ;
             if (x<800 && x>=0 && newy>=0 && newy<600) putpixel(x, newy,couleur);
             if (newx<800 && newx>=0 && y>=0 && y<600) putpixel( newx,y,couleur);
             if (newx<800 && newx>=0 && newy>=0 && newy<600) putpixel(newx,
             newy, couleur);
         }
       if (xo+R<800 && xo+R>=0) putpixel(xo+R,yo,couleur);
       if (xo-R<800 && xo-R>=0) putpixel(xo-R,yo, couleur);
  }


