/**************       PATHS IN A SQUARE GRID N*N         ************/
/**************                      (fig. 6.2)                                      *************/
#include <SDL/SDL.h>
#include <stdio.h>
#include <math.h>
#define N 4
void pause(void);
void putpixel(int xe, int ye, Uint32 couleur);
Uint32 getpixel(int xe, int ye);
void line(int x0,int y0, int x1,int y1, Uint32 c);
void linewithwidth(int x1, int y1, int x2, int y2, int width,Uint32 c);
SDL_Surface * screen, *rectangle; Uint32 white,black,red;
int a[100],xorig,yorig,pas,x,y;

int main ( int argc, char** argv )
{  int i,j,pospivot,left,right,aux; int deuxN=2*N;
    SDL_Init(SDL_INIT_VIDEO);
    screen=SDL_SetVideoMode(800,600,32, SDL_HWSURFACE|SDL_DOUBLEBUF);
    white=SDL_MapRGB(screen->format,255,255,255);
    red=SDL_MapRGB(screen->format,255,0,0);
    black=SDL_MapRGB(screen->format,0,0,0);
    SDL_FillRect(screen,0,white);
    pas=10;xorig=10; yorig=N*pas+10;
    for(i=0;i<deuxN;i++) if (i<N) a[i]=0; else a[i]=1;
    for(;;)
      {
        for(i=0;i<=N;i++) line(xorig+pas*i,yorig,xorig+pas*i,yorig-pas*N,black);
        for(i=0;i<=N;i++) line(xorig,yorig-pas*i,xorig+pas*N,yorig-pas*i,black) ;
        x=0;y=0;
        for(i=0;i<deuxN;i++)
        if (a[i]==0) { linewithwidth(xorig+pas*x,yorig-pas*y,xorig+pas*x+pas,yorig-pas*y,2,red);
                            x++;
                          }
        else { linewithwidth(xorig+pas*x,yorig-pas*y,xorig+pas*x,yorig-pas*y-pas,2,red);
                     y++;
                }
        SDL_Flip(screen);
         xorig+=N*pas+10; if (xorig>750) {yorig+=N*pas+15; xorig=10;}
         if (yorig>590) {pause();SDL_FillRect(screen,0,white);xorig=10; yorig=N*pas+10;;}
         i=deuxN-2;
        while (i>=0 && (a[i]!=0 || a[i+1]!=1))  i--;
        pospivot=i;   if (pospivot==-1) break;
        a[pospivot]=1; a[pospivot+1]=0;
        left=pospivot+2; right=deuxN-1;
        while (left<right)   { aux=a[left];a[left]=a[right];a[right]=aux; left++; right--;    }
     }
pause();return 0;
}

void pause(void)
{  SDL_Event evenement;
    do   SDL_WaitEvent(&evenement);
    while(evenement.type != SDL_QUIT && evenement.type != SDL_KEYDOWN);
}

void putpixel(int xe, int ye, Uint32 couleur)
{ Uint32 * boxnumber;
boxnumber= (Uint32 *)(screen->pixels)+xe+ye*screen->w;    *boxnumber=couleur;
}

Uint32 getpixel(int xe, int ye)
{ Uint32 * boxnumber;
   boxnumber= (Uint32 *)(screen->pixels)+xe+ye*screen->w;   return (*boxnumber);
}

void line(int x0,int y0, int x1,int y1, Uint32 c)
{
int dx,dy,x,y,residu,absdx,absdy,pasx,pasy,i;
dx=x1-x0; dy=y1-y0;  residu=0;       x=x0;y=y0;  putpixel(x,y,c);
if (dx>0) pasx=1;else pasx=-1; if (dy>0) pasy=1; else pasy=-1;
absdx=abs(dx);absdy=abs(dy);
if (dx==0) for(i=0;i<absdy;i++) { y+=pasy;
                                                    putpixel(x,y,c); }
else if(dy==0) for(i=0;i<absdx;i++){ x+=pasx;
                                                         putpixel(x,y,c);  }
else if (absdx==absdy)
   for(i=0;i<absdx;i++) {x+=pasx; y+=pasy;
                                     putpixel(x,y,c);
                                     }
else if (absdx>absdy)
          for(i=0;i<absdx;i++)
			  { x+=pasx; residu+=absdy;
			     if(residu >= absdx) {residu -=absdx; y+=pasy;}
			     putpixel(x,y,c);
			  }
else for(i=0;i<absdy;i++)
             {y+=pasy; residu +=absdx;
              if (residu>=absdy)   {residu -= absdy;x +=pasx;}
              putpixel(x,y,c);
             }
}

void linewithwidth(int x1, int y1, int x2, int y2, int width,Uint32 c)
{
int dx,dy;
float k,xf1,yf1,xf2,yf2,d,dx1,dy1,ndx1,ndy1,ndx2,ndy2,angle=M_PI/2.;
line(x1,y1,x2,y2,c);
dx=x2-x1; dy=y2-y1;       d=sqrt(dx*dx+dy*dy);
if (d!=0.)      /* si le vecteur n’est step nul */
{ dx1=(float)width*(float)dx/d; dy1=(float)width*(float)dy/d;
   ndx1=dx1*cos(angle)-dy1*sin(angle);
   ndy1=dx1*sin(angle)+dy1*cos(angle);
   ndx2=dx1*cos(-angle)-dy1*sin(-angle);
   ndy2=dx1*sin(-angle)+dy1*cos(-angle);
   for(k=0;k<=1.;k+=0.1/d)
   {
   xf1=(1.-k)*x1+k*x2; yf1=(1.-k)*y1+k*y2;
   xf2=xf1-ndx1; yf2=yf1-ndy1;  line(xf1,yf1,xf2,yf2,c);
   xf2=xf1-ndx2; yf2=yf1-ndy2;    line(xf1,yf1,xf2,yf2,c);
   }
}
}
