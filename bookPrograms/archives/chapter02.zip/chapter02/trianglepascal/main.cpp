/***********      PASCAL  TIRANGLE  MODULO   K     **************/
#include <SDL/SDL.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define K 5
#define step 8
void square(int xe, int ye, Uint32 c);
int CmoduloK(int n, int p);
void pause(void);
void putpixel(int xe, int ye, Uint32 color);
Uint32 getpixel(int xe, int ye);
SDL_Surface * screen; Uint32 white,color, col[K] ;
int xorig,yorig,x,y;

int main(int argc, char ** argv)
{    int i;
    SDL_Init(SDL_INIT_VIDEO);
    screen=SDL_SetVideoMode(800,600,32, SDL_HWSURFACE|SDL_DOUBLEBUF);
    white=SDL_MapRGB(screen->format,255,255,255);
    col[0]=SDL_MapRGB(screen->format,255,255,255);
    col[1]=SDL_MapRGB(screen->format,255,0,0);
    col[2]=SDL_MapRGB(screen->format,0,255,0);
    col[3]=SDL_MapRGB(screen->format,0,0,255);
    srand(time(NULL));
    for(i=4;i<K;i++)
    col[i]=SDL_MapRGB(screen->format,rand()%256,rand()%256,rand()%256);
    SDL_FillRect(screen,0,white);
    xorig=10; yorig=10;
    for(y=0;y<64;y++)
    for(x=0;x<64;x++)
    {   color=col[CmoduloK(y,x)];
        square(xorig+step*x, yorig+step*y, color);
    }
SDL_Flip(screen);pause();

   return 0;
}



int CmoduloK(int n, int p)    /****   C(n p) mod K  */
{
    int i,j,c[1000];
    c[0]=1; for(j=1;j<=p;j++) c[j]=0;
    for(i=1;i<=n;i++)
    for(j=p;j>=1;j--)
    c[j]=(c[j]+c[j-1])%K;
    return c[p];
}

void square(int xe, int ye,Uint32 c)
{  int i,j;
    for(i=xe;i<xe+step;i++) for(j=ye;j<ye+step;j++)
    putpixel(i,j,c);
}

void pause(void)
{
    SDL_Event evenement;
    do   SDL_WaitEvent(&evenement);
    while(evenement.type != SDL_QUIT && evenement.type != SDL_KEYDOWN);
}

void putpixel(int xe, int ye, Uint32 color)
{ Uint32 * numerocase;
numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;    *numerocase=color;
}

