/*************     CLASSIFICATIONS OF APPLICAITONS      ***********/
#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <stdlib.h>
#define N 6         /* 9 is the maximum */
struct w { int length; int p[N];int c; struct w * s; } ;
struct w * start,* ptr, * neww, * oldptr;

int main()
{ int nmax,number,q;  int i,r,a[N],j,aux,b[N],L,k,flag,same,counter;
   nmax=pow((double)N,(double)N);
   for(number=0;number<nmax;number++)
     { q=number;
        for(i=0;i<N;i++){r=q%N;q=q/N; a[N-1-i]=r;}
        for(i=0;i<N;i++) b[i]=0;
        for(i=0;i<N;i++)
        b[a[i]]++;
       /************     sort of array b with length L   *****************/
        for(i=0;i<N-1;i++)
        for(j=i+1;j<N;j++)
        if (b[i]<b[j])  { aux=b[i];b[i]=b[j];b[j]=aux;}
        L=N;
        for(i=0;i<N;i++)
        if (b[i]==0) { L=i;break;}

        /**************    list of partitions    ******************/
        if (start==NULL)
          { start=(struct w *) malloc(sizeof(struct w));
             start->length=L;  start->c=1;
             for(i=0;i<L;i++) start->p[i]=b[i]; /*printf(" %d$    ",L); */
             start->s=start;  counter=1;
          }
        else
          { ptr=start; flag=0;
            do
              { same=1;
                 if (L!=ptr->length) same=0;
                 else for(j=0;j<L;j++) if (b[j]!=ptr->p[j]) { same=0; break;}
                 if (same==1) {(ptr->c)++; flag=1;break;}
                 ptr=ptr->s;
              }
           while (ptr!=start);
           if (flag==0)
              { neww=(struct w *) malloc(sizeof(struct w));
		         neww->length=L;     neww->c=1;
		         for(k=0;k<L;k++) neww->p[k]=b[k];
		         neww->s=start;
		         ptr=start; do { oldptr=ptr;ptr=ptr->s;}
                                while (ptr!=start);
		         oldptr->s=neww;
		         counter++;
		       }
            }
    } /*** for each application ***/

   ptr=start;
   do
     { for(j=0;j<ptr->length;j++) printf("%d ",ptr->p[j]);
        printf("%15.d\n",ptr->c);
        ptr=ptr->s;
     }
   while(ptr!=start);
   printf("\nNumber of partitions = %d",counter);
   getch(); return 0;
}



