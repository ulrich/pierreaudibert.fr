#include <stdio.h>
#include <conio.h>
#include <math.h>

#define N 6         /* 9 is the maximum */

int nmax,number,q;  int a[N],b[N],L;
int nbpartitions,partition[100][N];  int c[100];
int same(int k);

int main()
{ int i,j,aux,r,flag;  int cumul;float bg,bbgg;

  nmax=(int)pow((double)N,(double)N);nbpartitions=0;
  for(number=0;number<nmax;number++)
    { if (number%1000000==0) printf("*");
      q=number;   for(i=0;i<N;i++) {r=q%N;q=q/N; a[N-1-i]=r;}
      for(i=0;i<N;i++) b[i]=0;
      for(i=0;i<N;i++)  b[a[i]]++;

      for(i=0;i<N-1;i++)  for(j=i+1;j<N;j++)  /**   sort of array b with length   L   */
      if (b[i]<b[j])  { aux=b[i];b[i]=b[j];b[j]=aux;}
      /*
        L=N;
        for(i=0;i<N;i++) if (b[i]==0) { L=i;break;}
                             else printf("%d ",b[i]);
        printf("(%d) ",L);
      */
      /*printf("(");for(i=0;i<N;i++) printf("%d ",b[i]);printf(")");*/
      flag=0;
      for(j=0;j<nbpartitions;j++)
      if (same(j)==1) {c[j]++;flag=1;break;}
      if (flag==0)
       { for(i=0;i<N;i++) partition[nbpartitions][i]=b[i]; c[nbpartitions]=1;
          nbpartitions++;
       }
    }
  printf("\nnumber of partitions %d\n",nbpartitions);
  bg=0;
  for(i=0;i<nbpartitions;i++)
    { for(j=0;j<N;j++) printf("%d ",partition[i][j]);
       printf("     %d",c[i]);
       bbgg=1;
       for(j=0;j<N;j++)  bbgg*=(float)(N-partition[i][j]);
       printf("   %3.0f\n",bbgg);
       bg+=bbgg*(float)c[i];
     }
   printf("bg=%3.0f\n",bg);
   cumul=0;
   for(i=0;i<nbpartitions;i++) cumul+=c[i];
   printf("\n\n%d %3.0f",cumul,pow(N,N));
   printf("\nProba=%3.3f",1.-bg/((float)nmax*(float)nmax));
   getch();
   return 0;
}

int same(int k)
{ int q;
  for (q=0;q<N;q++)
  if (b[q]!=partition[k][q]) return 0;
  return 1;
}



