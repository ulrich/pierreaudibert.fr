/**************                    HEAPS                 ****************/
/**************                                                  ****************/
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define length 5
#define height 5
void path(int N);
void pause(void);
void putpixel(int xe, int ye, Uint32 c);
Uint32 getpixel(int xe, int ye);
void line(int x0,int y0, int x1,int y1, Uint32 c);
void rectangle(int x1,int y1, int x2, int y2, Uint32 c);
void floodfill( int x,int y, Uint32 cr,Uint32 cb);
void linewithwidth(int x1, int y1, int x2, int y2, int width,Uint32 c);
SDL_Surface * screen; Uint32 white, color[3];
SDL_Surface *texte;  SDL_Rect position;TTF_Font *police=NULL;char chiffre[2000];
int a[100],b[100];int xorig,yorig,step,x,y,count,endx;

int main(int argc, char ** argv)
{  int i,pospivot,g,d,aux;
    SDL_Init(SDL_INIT_VIDEO);
   screen=SDL_SetVideoMode(800,600,32, SDL_HWSURFACE|SDL_DOUBLEBUF);
   white=SDL_MapRGB(screen->format,255,255,255);
   color[0]=SDL_MapRGB(screen->format,0,0,0);
   color[1]=SDL_MapRGB(screen->format,255,0,0);
   color[2]=SDL_MapRGB(screen->format,0,0,255);
   SDL_FillRect(screen,0,white);
   TTF_Init();  police=TTF_OpenFont("times.ttf",20);  SDL_Color cblack={0,0,0};
   step=12;xorig=10; yorig=height*step+10; count=0;
   for(endx=0;endx<length;endx++)
      { for(i=0;i<endx+height-2;i++) if (i<endx) a[i]=0; else a[i]=1;
         for(;;)
           { path(length-endx-1);
              /** next left path */
              i=endx+height-2-2;
             while (i>=0 && (a[i]!=0 || a[i+1]!=1))  i--;
              pospivot=i;   if (pospivot==-1) break;
             a[pospivot]=1; a[pospivot+1]=0; g=pospivot+2; d=endx+height-3;
             while (g<d)  { aux=a[g];a[g]=a[d];a[d]=aux; g++; d--;}
           }
      }
   sprintf( chiffre,"%d heaps  with length = %d  and height = %d",count,length, height);
   texte=TTF_RenderText_Solid(police,chiffre,cblack);
   position.x=10; position.y=570;
   SDL_BlitSurface(texte,NULL,screen,&position);
   SDL_Flip(screen); pause();
   TTF_CloseFont(police); TTF_Quit();  return 0;
}

void path(int N)
{ int xx,yy; int i,pospivot,left,right,aux;  int P=height-1;
   for(i=0;i<N+P;i++) if (i<N) b[i]=0; else b[i]=1;
   for(;;)
     { x=0;y=1; count++;
       linewithwidth(xorig,yorig,xorig,yorig-step,1,color[2]);
       for(i=0;i<endx+height-2;i++)
       if (a[i]==0)
	     { linewithwidth(xorig+step*x,yorig-step*y,xorig+step*x+step,yorig-step*y,1,color[2]);x++;}
       else {linewithwidth(xorig+step*x,yorig-step*y,xorig+step*x,yorig-step*y-step,1,color[2]);  y++;}
       linewithwidth(xorig+step*endx,yorig-step*height,xorig+step*endx,yorig-step*(height-1),1,color[1]);
       linewithwidth(xorig+step*endx,yorig-step*height,xorig+step*(endx+1),yorig-step*height,1,color[1]);
       xx=length;yy=1;
      linewithwidth(xorig+step*length,yorig,xorig+step*length,yorig-step,1,color[2]);
      for(i=0;i<N+P;i++)
      if (b[i]==0)
	    { linewithwidth(xorig+step*xx,yorig-step*yy,xorig+step*xx-step,yorig-step*yy,1,color[2]);xx--;}
      else {linewithwidth(xorig+step*xx,yorig-step*yy,xorig+step*xx,yorig-step*yy-step,1,color[2]);  yy++;}
      linewithwidth(xorig,yorig,xorig+step*length,yorig,1,color[2]);
      xorig+=length*step+10; if (xorig>800-step*length) {yorig+=height*step+15; xorig=10;}
      if (yorig>600-step*height) { SDL_Flip(screen); pause(); SDL_FillRect(screen,0,white);
                               xorig=10;yorig=height*step+15;
                            }
      /** next right path  */
      i=N+P-2;
      while (i>=0 && (b[i]!=0 || b[i+1]!=1))  i--;
      pospivot=i;   if (pospivot==-1) break;
      b[pospivot]=1; b[pospivot+1]=0; left=pospivot+2; right=N+P-1;
      while (left<right)  { aux=b[left];b[left]=b[right];b[right]=aux; left++; right--;}
    }
}

void pause(void)
{
    SDL_Event evenement;
    do   SDL_WaitEvent(&evenement);
    while(evenement.type != SDL_QUIT && evenement.type != SDL_KEYDOWN);
}


void putpixel(int xe, int ye, Uint32 c)
{ Uint32 * numerocase;
numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;    *numerocase=c;
}

Uint32 getpixel(int xe, int ye)
{ Uint32 * numerocase;
   numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;   return (*numerocase);
}

void line(int x0,int y0, int x1,int y1, Uint32 c)
{
int dx,dy,x,y,residu,absdx,absdy,stepx,stepy,i;
dx=x1-x0; dy=y1-y0;  residu=0;       x=x0;y=y0;  putpixel(x,y,c);
if (dx>0) stepx=1;else stepx=-1; if (dy>0) stepy=1; else stepy=-1;
absdx=abs(dx);absdy=abs(dy);
if (dx==0) for(i=0;i<absdy;i++) { y+=stepy;
                                                    putpixel(x,y,c); }
else if(dy==0) for(i=0;i<absdx;i++){ x+=stepx;
                                                         putpixel(x,y,c);  }
else if (absdx==absdy)
   for(i=0;i<absdx;i++) {x+=stepx; y+=stepy;
                                     putpixel(x,y,c);
                                     }
else if (absdx>absdy)
          for(i=0;i<absdx;i++)
			  { x+=stepx; residu+=absdy;
			     if(residu >= absdx) {residu -=absdx; y+=stepy;}
			     putpixel(x,y,c);
			  }
else for(i=0;i<absdy;i++)
             {y+=stepy; residu +=absdx;
              if (residu>=absdy)   {residu -= absdy;x +=stepx;}
              putpixel(x,y,c);
             }
}

void rectangle(int x1,int y1, int x2, int y2, Uint32 c)
{
    line(x1,y1,x2,y1,c);line(x1,y2,x2,y2,c);line(x1,y1,x1,y2,c);line(x2,y2,x2,y1,c);
}

void linewithwidth(int x1, int y1, int x2, int y2, int width,Uint32 c)
{
int dx,dy;
float k,xf1,yf1,xf2,yf2,d,dx1,dy1,ndx1,ndy1,ndx2,ndy2,angle=M_PI/2.;
line(x1,y1,x2,y2,c);
dx=x2-x1; dy=y2-y1;       d=sqrt(dx*dx+dy*dy);
if (d!=0.)      /* si le vecteur n’est step nul */
{ dx1=(float)width*(float)dx/d; dy1=(float)width*(float)dy/d;
   ndx1=dx1*cos(angle)-dy1*sin(angle);
   ndy1=dx1*sin(angle)+dy1*cos(angle);
   ndx2=dx1*cos(-angle)-dy1*sin(-angle);
   ndy2=dx1*sin(-angle)+dy1*cos(-angle);
   for(k=0;k<=1.;k+=0.1/d)
   {
   xf1=(1.-k)*x1+k*x2; yf1=(1.-k)*y1+k*y2;
   xf2=xf1-ndx1; yf2=yf1-ndy1;  line(xf1,yf1,xf2,yf2,c);
   xf2=xf1-ndx2; yf2=yf1-ndy2;    line(xf1,yf1,xf2,yf2,c);
   }
}
}
