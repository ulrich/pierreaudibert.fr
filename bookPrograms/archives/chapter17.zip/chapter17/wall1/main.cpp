/***************         BRICK WALLS       *********************/
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define N 9
void brick(int x,int y);
void pause(void);
void putpixel(int xe, int ye, Uint32 c);
Uint32 getpixel(int xe, int ye);
void line(int x0,int y0, int x1,int y1, Uint32 c);
void floodfill( int x,int y, Uint32 cr,Uint32 cb);
void rectangle(int x1,int y1, int x2, int y2, Uint32 c);
SDL_Surface * screen; Uint32 white, color[2];
SDL_Surface *texte;  SDL_Rect position;TTF_Font *police=NULL;char chiffre[2000];
int a[N],hauteur[N],xorig,yorig,l,h;

int main(int argc, char ** argv)
{  int i,count,number,xb,yb,q;
   SDL_Init(SDL_INIT_VIDEO);
   screen=SDL_SetVideoMode(800,600,32, SDL_HWSURFACE|SDL_DOUBLEBUF);
   white=SDL_MapRGB(screen->format,255,255,255);
   color[0]=SDL_MapRGB(screen->format,0,0,0);
   color[1]=SDL_MapRGB(screen->format,255,0,0);
   SDL_FillRect(screen,0,white);
   TTF_Init();
   police=TTF_OpenFont("times.ttf",20);
    SDL_Color cblack={0,0,0};
    sprintf( chiffre," N = %d",N);
    texte=TTF_RenderText_Solid(police,chiffre,cblack);
    position.x=10; position.y=10;
    SDL_BlitSurface(texte,NULL,screen,&position);
    l=20; h=10;
    count=0;xorig=10;yorig=N*h+40;
    a[0]=1;
    for(number=0; number<pow(2,N-1);number++)
       { q=number;  count++;
          for(i=1;i<N;i++)   { a[i]=q%2; q=q/2;}
           xb=xorig;yb=yorig;brick(xb,yb);
           for(i=1;i<N;i++)
              { if (a[i]==0) yb-=h; else {xb+=l;yb=yorig;  }
                 brick(xb,yb);
              }
          xorig+=N*l+10; if (xorig>800-N*l) {yorig+=N*h+10; xorig=10;}
          if (yorig>600-N*h) { SDL_Flip(screen); pause(); SDL_FillRect(screen,0,white);
                                               xorig=10;yorig=N*h+10;
                                        }
        }
    sprintf( chiffre," Number of walls : %d",count);
    texte=TTF_RenderText_Solid(police,chiffre,cblack);
    position.x=50; position.y=550;
    SDL_BlitSurface(texte,NULL,screen,&position);
    SDL_Flip(screen); pause();  TTF_CloseFont(police); TTF_Quit();  return 0;
}

void brick(int x,int y)
{
rectangle(x,y,x+l,y-h,color[0]);
floodfill(x+l/2,y-h/2,color[1],color[0]);
}

void pause(void)
{
    SDL_Event evenement;
    do   SDL_WaitEvent(&evenement);
    while(evenement.type != SDL_QUIT && evenement.type != SDL_KEYDOWN);
}


void putpixel(int xe, int ye, Uint32 c)
{ Uint32 * numerocase;
numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;    *numerocase=c;
}

Uint32 getpixel(int xe, int ye)
{ Uint32 * numerocase;
   numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;   return (*numerocase);
}

void line(int x0,int y0, int x1,int y1, Uint32 c)
{
int dx,dy,x,y,residu,absdx,absdy,stepx,stepy,i;
dx=x1-x0; dy=y1-y0;  residu=0;       x=x0;y=y0;  putpixel(x,y,c);
if (dx>0) stepx=1;else stepx=-1; if (dy>0) stepy=1; else stepy=-1;
absdx=abs(dx);absdy=abs(dy);
if (dx==0) for(i=0;i<absdy;i++) { y+=stepy;
                                                    putpixel(x,y,c); }
else if(dy==0) for(i=0;i<absdx;i++){ x+=stepx;
                                                         putpixel(x,y,c);  }
else if (absdx==absdy)
   for(i=0;i<absdx;i++) {x+=stepx; y+=stepy;
                                     putpixel(x,y,c);
                                     }
else if (absdx>absdy)
          for(i=0;i<absdx;i++)
			  { x+=stepx; residu+=absdy;
			     if(residu >= absdx) {residu -=absdx; y+=stepy;}
			     putpixel(x,y,c);
			  }
else for(i=0;i<absdy;i++)
             {y+=stepy; residu +=absdx;
              if (residu>=absdy)   {residu -= absdy;x +=stepx;}
              putpixel(x,y,c);
             }
}

void rectangle(int x1,int y1, int x2, int y2, Uint32 c)
{
    line(x1,y1,x2,y1,c);line(x1,y2,x2,y2,c);line(x1,y1,x1,y2,c);line(x2,y2,x2,y1,c);
}

void floodfill( int x,int y, Uint32 cr,Uint32 cb)
{   int xg,xd,xx;
    if (getpixel(x,y) !=cb && getpixel(x,y) !=cr)
    { putpixel(x,y,cr);
    xg=x-1;
    while(xg>0 && getpixel(xg,y)!=cb)  {putpixel(xg,y,cr); xg--;}
    xd=x+1;
    while(xd<800 && getpixel(xd,y)!=cb)  {putpixel(xd,y,cr); xd++ ;}
    for(xx=xg; xx<xd;xx++)
    { if (y>1 ) {floodfill(xx,y-1,cr,cb);}
       if (y<599 ) {floodfill(xx,y+1,cr,cb);}
    }
    }
}
