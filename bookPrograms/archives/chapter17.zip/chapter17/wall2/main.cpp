/***********       BRICK WALLS WITH CONTINUOUS ROWS       ***********/

#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
void pause(void);
void putpixel(int xe, int ye, Uint32 c);
Uint32 getpixel(int xe, int ye);
void line(int x0,int y0, int x1,int y1, Uint32 c);
void rectangle(int x1,int y1, int x2, int y2, Uint32 c);
void floodfill( int x,int y, Uint32 cr,Uint32 cb);
SDL_Surface * screen; Uint32 white, color[2];
SDL_Surface *texte;  SDL_Rect position;TTF_Font *police=NULL;char chiffre[2000];
int a[1000],b[1000],c[1000],x[1000];
void brick(int xx,int yy) ;
int xorig,yorig,stepx,stepy;

int main(int argc, char ** argv)
{  int pospivot,L,i,cumul,reste,k,r,count,n,cumulb,nbwalls,ppospivot,cumulx,level;
   SDL_Init(SDL_INIT_VIDEO);
   screen=SDL_SetVideoMode(800,600,32, SDL_HWSURFACE|SDL_DOUBLEBUF);
   white=SDL_MapRGB(screen->format,255,255,255);
   color[0]=SDL_MapRGB(screen->format,0,0,0);
   color[1]=SDL_MapRGB(screen->format,255,0,0);
   SDL_FillRect(screen,0,white);
   TTF_Init();
   police=TTF_OpenFont("times.ttf",20);
    SDL_Color cblack={0,0,0};
   stepx=12; stepy=7;

   for(n=2;n<12;n++)
     { xorig=10;yorig=60;
        sprintf( chiffre," N =  %d",n);
        texte=TTF_RenderText_Solid(police,chiffre,cblack);
        position.x=10; position.y=10;
        SDL_BlitSurface(texte,NULL,screen,&position);
        count=1;a[0]=n; L=1 ; nbwalls=1;
        for(i=0;i<a[0];i++) brick(i,0); xorig+=stepx*n+5;
        for(;;)
          { count++;
             if (a[L-1]!=1) { pospivot=L-1; a[pospivot]-=1; a[pospivot+1]=1; L+=1; }
            else
              { k=L-1;cumul=0;  while (a[k]==1 && k>=0) {k--; cumul+=1;}
                 pospivot=k; if (pospivot==-1) break;
                 a[pospivot]-=1; reste=cumul+1; L=pospivot+1;
                 if (reste<=a[pospivot]) { a[pospivot+1]=reste; L+=1;}
                 else
                   { r=reste; k=pospivot+1;
                     while(r>=a[pospivot]) { a[k]=a[pospivot];r-=a[pospivot];L+=1;k+=1; }
	                 if (r!=0) { a[k]=r; L+=1;}
	               }
                }
            b[0]=0;
            for(i=1;i<L;i++) b[i]=-a[i]+a[i-1]+1;
            cumulb=1;  for(i=1;i<L;i++) cumulb*=b[i]; nbwalls+=cumulb;
           for(i=0;i<L;i++) c[i]=0;
           for(;;)
            { cumulx=0;x[0]=0;
              for(i=1;i<L;i++)  { x[i]=c[i]+cumulx; cumulx+=c[i]; }
              for(i=0;i<a[0];i++) brick(i,0);
              for(level=1;level<L;level++)
              for(i=0;i<a[level];i++)   { brick(x[level]+i,level); }
              xorig+=stepx*n+5; if (xorig>800-stepx*n) { xorig=10; yorig+=stepy*n+5;}
              if (yorig>600-stepy*n) { SDL_Flip(screen); pause(); SDL_FillRect(screen,0,white);
                                                   xorig=10;yorig=60;
                                                }
               i=L-1;
              while(c[i]==b[i]-1) i--;
              ppospivot=i;  if (ppospivot==0) break;
              c[ppospivot]++;  for(i=ppospivot+1;i<L;i++) c[i]=0;
            }
         }
       sprintf( chiffre," number of walls =  %d",nbwalls);
       texte=TTF_RenderText_Solid(police,chiffre,cblack);
       position.x=10; position.y=570;
       SDL_BlitSurface(texte,NULL,screen,&position);
       SDL_Flip(screen); pause(); SDL_FillRect(screen,0,white);
   }
SDL_Flip(screen); pause();  TTF_CloseFont(police); TTF_Quit();  return 0;
}

void brick(int xx,int yy)
{
rectangle(xorig+stepx*xx,yorig-stepy*yy,xorig+stepx*xx+stepx,yorig-stepy*yy-stepy,color[0]);
floodfill(xorig+stepx*xx+stepx/2, yorig-stepy*yy-stepy/2,color[1],color[0]);
}

void pause(void)
{
    SDL_Event evenement;
    do   SDL_WaitEvent(&evenement);
    while(evenement.type != SDL_QUIT && evenement.type != SDL_KEYDOWN);
}


void putpixel(int xe, int ye, Uint32 c)
{ Uint32 * numerocase;
numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;    *numerocase=c;
}

Uint32 getpixel(int xe, int ye)
{ Uint32 * numerocase;
   numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;   return (*numerocase);
}

void line(int x0,int y0, int x1,int y1, Uint32 c)
{
int dx,dy,x,y,residu,absdx,absdy,stepx,stepy,i;
dx=x1-x0; dy=y1-y0;  residu=0;       x=x0;y=y0;  putpixel(x,y,c);
if (dx>0) stepx=1;else stepx=-1; if (dy>0) stepy=1; else stepy=-1;
absdx=abs(dx);absdy=abs(dy);
if (dx==0) for(i=0;i<absdy;i++) { y+=stepy;
                                                    putpixel(x,y,c); }
else if(dy==0) for(i=0;i<absdx;i++){ x+=stepx;
                                                         putpixel(x,y,c);  }
else if (absdx==absdy)
   for(i=0;i<absdx;i++) {x+=stepx; y+=stepy;
                                     putpixel(x,y,c);
                                     }
else if (absdx>absdy)
          for(i=0;i<absdx;i++)
			  { x+=stepx; residu+=absdy;
			     if(residu >= absdx) {residu -=absdx; y+=stepy;}
			     putpixel(x,y,c);
			  }
else for(i=0;i<absdy;i++)
             {y+=stepy; residu +=absdx;
              if (residu>=absdy)   {residu -= absdy;x +=stepx;}
              putpixel(x,y,c);
             }
}

void rectangle(int x1,int y1, int x2, int y2, Uint32 c)
{
    line(x1,y1,x2,y1,c);line(x1,y2,x2,y2,c);line(x1,y1,x1,y2,c);line(x2,y2,x2,y1,c);
}

void floodfill( int x,int y, Uint32 cr,Uint32 cb)
{   int xg,xd,xx;
    if (getpixel(x,y) !=cb && getpixel(x,y) !=cr)
    { putpixel(x,y,cr);
    xg=x-1;
    while(xg>0 && getpixel(xg,y)!=cb)  {putpixel(xg,y,cr); xg--;}
    xd=x+1;
    while(xd<800 && getpixel(xd,y)!=cb)  {putpixel(xd,y,cr); xd++ ;}
    for(xx=xg; xx<xd;xx++)
    { if (y>1 ) {floodfill(xx,y-1,cr,cb);}
       if (y<599 ) {floodfill(xx,y+1,cr,cb);}
    }
    }
}
