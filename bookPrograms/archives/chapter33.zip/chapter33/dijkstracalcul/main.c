/**************         DIJKSTRA   ALGORITHM    (text)  **************/
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <math.h>
#define N 5
#define step 150
void path(int ii);
int pred[N];int k;int c[N], x[N],y[N]; int arc[N][N],initialpoint;

int main()
{    int S[N],T[N],d[N];
   int i,j,etape, LS,LT,dmin,pointmin,imin,newd,point;

 for(i=0;i<N;i++) for(j=0;j<N;j++) {arc[i][j]=30000; if(i==j) arc[i][j]=0;}
arc[0][1]=60;arc[0][3]=70;arc[0][4]=20;arc[1][3]=50;
arc[2][3]=30;arc[3][2]=30;arc[4][1]=30; arc[4][2]=90;arc[4][3]=70;

 initialpoint=4;
LS=1; S[0]=initialpoint;  LT=N-1;
for(i=0;i<LT;i++) if (i<initialpoint) T[i]=i; else T[i]=i+1;
for(i=0;i<N;i++)  if (i!=initialpoint) { d[i]=arc[initialpoint][i]; pred[i]=initialpoint;}

printf("\nS: ");
for(i=0;i<LS;i++) printf("%d ",S[i]);
printf("          T: ");
for(i=0;i<LT;i++) printf("%d ",T[i]);
printf("\nd :");
for(i=0;i<N;i++)  if (i!=initialpoint)
  { d[i]=arc[initialpoint][i]; pred[i]=initialpoint;
    printf("%d(%d) ",d[i],pred[i]);
  }

 for(etape=1;etape<N; etape++)
  { dmin=40000;
     for(i=0;i<LT;i++)
        { point=T[i];
           if (d[point]<dmin) {dmin=d[point]; pointmin=point;imin=i;}
        }

     LS++; S[LS-1]=pointmin;  for(i=imin;i<LT-1;i++) T[i]=T[i+1];  LT--;
     for(i=0;i<LT;i++)
      { point=T[i]; newd=dmin+arc[pointmin][point];
        if(newd<d[point]) {d[point]=newd;pred[point]=pointmin;}
      }

    printf("\n\nS: ");
    for(i=0;i<LS;i++) printf("%d ",S[i]);
    printf("          T: ");
    for(i=0;i<LT;i++) printf("%d ",T[i]);
    printf("\nd :");
    for(i=0;i<N;i++)  if (i!=initialpoint)  printf("%d(%d) ",d[i],pred[i]);
  }
printf("\n\n");
  for(i=0;i<N;i++) if (i!=initialpoint)
   { k=1;  path(i);
     printf("\nde %d a %d :   ",initialpoint,i);
	  if (d[i]<30000) for(j=1;j<k;j++)   printf ("(%d %d) ",c[j-1], c[j] );
   }

  getch();return 0;
}


void path(int ii)
{
if (ii==initialpoint) {  c[0]=initialpoint;}
else { path(pred[ii]);   c[k++]=ii; }
}
