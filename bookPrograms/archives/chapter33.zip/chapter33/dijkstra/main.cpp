/******************       DIJKSTRA  ALGORITHM    *****************/
/******************         Fig.  33-2                                                        *****************/

#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define N 5
#define step 150
void path(int ii);
void initialdrawing(void);
void pause(void);
void putpixel(int xe, int ye, Uint32 couleur);
Uint32 getpixel(int xe, int ye);
void circle( int xo, int yo, int R, Uint32 couleur);
void filldisc(int xo, int yo, int R,Uint32 couleur);
void line(int x0,int y0, int x1,int y1, Uint32 c);
void linewithwidth(int x1, int y1, int x2, int y2, int epaisseur,Uint32 c);
void arrow(int x1, int y1, int x2, int y2, Uint32 c);
SDL_Surface * screen; Uint32 blanc,noir,rouge,bleu,vert,jaune,couleur,gris;
SDL_Surface *texte; SDL_Rect position;
TTF_Font *police=NULL;SDL_Color couleurnoire={0,0,0}; SDL_Color couleurrouge={250,0,0};
char chiffre[200];
int pred[N];int k;int c[N], x[N],y[N]; int arc[N][N],initialpoint;

int main(int argc, char ** argv)
{
    int S[N],T[N],d[N];
   int i,j,jj,etape, LS,LT,dmin,pointmin,imin,newd,point;
   SDL_Init(SDL_INIT_VIDEO); TTF_Init();
   screen=SDL_SetVideoMode(800,600,32, SDL_HWSURFACE|SDL_DOUBLEBUF);
   blanc=SDL_MapRGB(screen->format,255,255,255);
   noir=SDL_MapRGB(screen->format,0,0,0);
   vert=SDL_MapRGB(screen->format,0,250,0);
   bleu=SDL_MapRGB(screen->format,0,0,250);
   rouge=SDL_MapRGB(screen->format,255,0,0);
   jaune=SDL_MapRGB(screen->format,255,255,0);
   gris=SDL_MapRGB(screen->format,200,200,200);
   SDL_FillRect(screen,0,blanc);

x[0]= 70;y[0]=20;   x[1]= 10;y[1]=70;  x[2]= 100;y[2]=130;
x[3]= 30;y[3]=130;  x[4]= 130;y[4]=70;

for(i=0;i<N;i++) for(j=0;j<N;j++) {arc[i][j]=30000; if(i==j) arc[i][j]=0;}
arc[0][1]=60;arc[0][3]=70;arc[0][4]=20;arc[1][3]=50;
arc[2][3]=30;arc[3][2]=30;arc[4][1]=30; arc[4][2]=90;arc[4][3]=70;
initialdrawing();

initialpoint=0;
sprintf( chiffre,"initial point : %d ",initialpoint);
texte=TTF_RenderText_Solid(police,chiffre,couleurnoire);
position.x=30; position.y=500;
SDL_BlitSurface(texte,NULL,screen,&position);

LS=1; S[0]=initialpoint;  LT=N-1;
for(i=0;i<LT;i++) if (i<initialpoint) T[i]=i; else T[i]=i+1;
for(i=0;i<N;i++)  if (i!=initialpoint) { d[i]=arc[initialpoint][i]; pred[i]=initialpoint;}
for(etape=1;etape<N; etape++)
  { dmin=40000;
     for(i=0;i<LT;i++)
        { point=T[i];    if (d[point]<dmin) {dmin=d[point]; pointmin=point;imin=i;} }
     LS++; S[LS-1]=pointmin;  for(i=imin;i<LT-1;i++) T[i]=T[i+1];  LT--;
     for(i=0;i<LT;i++)
      { point=T[i]; newd=dmin+arc[pointmin][point];
        if(newd<d[point]) {d[point]=newd;pred[point]=pointmin;}
      }
  }
for(j=0;j<N;j++) y[j]+=350;

for(i=0;i<N;i++) if (i!=initialpoint)
   { k=1;    path(i);
	  for(j=0;j<N;j++)    {circle(x[j],y[j],3,noir);    filldisc(x[j],y[j],3,3);  }
      for(j=0;j<N;j++) for(jj=0;jj<N;jj++)  if (j!=jj && arc[j][jj]<30000)
      line(x[j],y[j],x[jj],y[jj],noir);
	  if (d[i]<30000) for(j=1;j<k;j++)   linewithwidth(x[c[j]],y[c[j]],x[c[j-1]],y[c[j-1]],1,rouge);
      for(j=0;j<N;j++) x[j]+=step;
   }
SDL_Flip(screen); pause(); TTF_CloseFont(police); TTF_Quit();  return 0;
}

void path(int ii)
{
if (ii==initialpoint) {  c[0]=initialpoint;}
else { path(pred[ii]);   c[k++]=ii;  }
}

void initialdrawing(void)
{ int i,j,xx[N],yy[N];
   for(i=0;i<N;i++) {xx[i]=2*x[i]; yy[i]=2*y[i];}
   police=TTF_OpenFont("times.ttf",20);
   sprintf( chiffre," DIJKSTRA'S ALGORITHM  (shortest distances from a point)");
   texte=TTF_RenderText_Solid(police,chiffre,couleurnoire);
   position.x=280; position.y=280;
   SDL_BlitSurface(texte,NULL,screen,&position);
   police=TTF_OpenFont("times.ttf",20);
   for(i=0;i<N;i++)
      { sprintf( chiffre,"%d ",i);
         texte=TTF_RenderText_Solid(police,chiffre,couleurnoire);
         position.x=xx[i]+5; position.y=yy[i]-2;
         SDL_BlitSurface(texte,NULL,screen,&position);
      }

   for(i=0;i<N;i++) for(j=0;j<N;j++)
   if (i!=j && arc[i][j]!=30000)
     { arrow(xx[i],yy[i],xx[j],yy[j],noir);
       sprintf( chiffre,"%d ",arc[i][j]);
       texte=TTF_RenderText_Solid(police,chiffre,couleurrouge);
       position.x=(xx[i]+xx[j])/2-5; position.y=(yy[i]+yy[j])/2-5;
       SDL_BlitSurface(texte,NULL,screen,&position);
    }
}

void pause(void)
{
    SDL_Event evenement;
    do   SDL_WaitEvent(&evenement);
    while(evenement.type != SDL_QUIT && evenement.type != SDL_KEYDOWN);
}

void putpixel(int xe, int ye, Uint32 couleur)
{ Uint32 * numerocase;
numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;    *numerocase=couleur;
}

Uint32 getpixel(int xe, int ye)
{ Uint32 * numerocase;
   numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;   return (*numerocase);
}

void linewithwidth(int x1, int y1, int x2, int y2, int epaisseur,Uint32 c)
{
int dx,dy;
float k,xf1,yf1,xf2,yf2,d,dx1,dy1,ndx1,ndy1,ndx2,ndy2,angle=M_PI/2.;
line(x1,y1,x2,y2,c);
dx=x2-x1; dy=y2-y1;       d=sqrt(dx*dx+dy*dy);
if (d!=0.)      /* si le vecteur n’est step nul */
{ dx1=(float)epaisseur*(float)dx/d; dy1=(float)epaisseur*(float)dy/d;
   ndx1=dx1*cos(angle)-dy1*sin(angle);
   ndy1=dx1*sin(angle)+dy1*cos(angle);
   ndx2=dx1*cos(-angle)-dy1*sin(-angle);
   ndy2=dx1*sin(-angle)+dy1*cos(-angle);
   for(k=0;k<=1.;k+=0.1/d)
   {
   xf1=(1.-k)*x1+k*x2; yf1=(1.-k)*y1+k*y2;
   xf2=xf1-ndx1; yf2=yf1-ndy1;  line(xf1,yf1,xf2,yf2,c);
   xf2=xf1-ndx2; yf2=yf1-ndy2;    line(xf1,yf1,xf2,yf2,c);
   }
}
}

void circle( int xo, int yo, int R, Uint32 couleur)
  {
      int x, y, F, F1, F2,newx,newy;
      x=xo; y=yo+R; F=0;
      if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
      if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, couleur);
      while( y>yo)
         {
             F1=F+2*(x-xo)+1; F2=F-2*(y-yo)+1;
             if ( abs(F1)<abs(F2))  { x+=1; F=F1;}
             else {y-=1; F=F2;}
             if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
              newx=2*xo-x ; newy=2*yo-y ;
             if (x<800 && x>=0 && newy>=0 && newy<600) putpixel(x, newy,couleur);
             if (newx<800 && newx>=0 && y>=0 && y<600) putpixel( newx,y,couleur);
             if (newx<800 && newx>=0 && newy>=0 && newy<600) putpixel(newx,
             newy, couleur);
         }
       if (xo+R<800 && xo+R>=0 && yo>=0 && yo<600) putpixel(xo+R,yo,couleur);
       if (xo-R<800 && xo-R>=0 && yo>=0 && yo<600) putpixel(xo-R,yo, couleur);
  }

void filldisc( int xo, int yo, int R, Uint32 couleur)
  {
      int x, y, F, F1, F2,newx,newy,xx;
      x=xo; y=yo+R; F=0;
      if (x<800 && x>=0 && y>=0 && y<600) putpixel(x,y,couleur);
      if (x<800 && x>=0 && 2*yo-y>=0 && 2*yo-y<600) putpixel (x,2*yo-y, couleur);
      while( y>yo)
         {
             F1=F+2*(x-xo)+1; F2=F-2*(y-yo)+1;
             if ( abs(F1)<abs(F2))  { x+=1; F=F1;}
             else {y-=1; F=F2;}
             newx=2*xo-x ; newy=2*yo-y ;
             for(xx=newx; xx<=x; xx++)if (xx<800 && xx>=0 && y>=0 && y<600 )
             putpixel(xx,y,couleur);
             for(xx=newx; xx<=x; xx++)if (xx<800 && xx>=0 && newy>=0 && newy<600 )
             putpixel(xx,newy,couleur);
         }
       if (xo+R<800 && xo+R>=0&& y>=0 && y<600) putpixel(xo+R,yo,couleur);
       if (xo-R<800 && xo-R>=0&& y>=0 && y<600) putpixel(xo-R,yo, couleur);
  }

void line(int x0,int y0, int x1,int y1, Uint32 c)
{
int dx,dy,x,y,residu,absdx,absdy,stepx,stepy,i;
dx=x1-x0; dy=y1-y0;  residu=0;       x=x0;y=y0;  putpixel(x,y,c);
if (dx>0) stepx=1;else stepx=-1; if (dy>0) stepy=1; else stepy=-1;
absdx=abs(dx);absdy=abs(dy);
if (dx==0) for(i=0;i<absdy;i++) { y+=stepy;
                                                    putpixel(x,y,c); }
else if(dy==0) for(i=0;i<absdx;i++){ x+=stepx;
                                                         putpixel(x,y,c);  }
else if (absdx==absdy)
   for(i=0;i<absdx;i++) {x+=stepx; y+=stepy;
                                     putpixel(x,y,c);
                                     }
else if (absdx>absdy)
          for(i=0;i<absdx;i++)
			  { x+=stepx; residu+=absdy;
			     if(residu >= absdx) {residu -=absdx; y+=stepy;}
			     putpixel(x,y,c);
			  }
else for(i=0;i<absdy;i++)
             {y+=stepy; residu +=absdx;
              if (residu>=absdy)   {residu -= absdy;x +=stepx;}
              putpixel(x,y,c);
             }
}

void arrow(int x1, int y1, int x2, int y2, Uint32 c)
{
int dx,dy;
float xf1,yf1,xf2,yf2,d,dx1,dy1,ndx1,ndy1,ndx2,ndy2,angle=M_PI/6.;
line(x1,y1,x2,y2,c);
dx=x2-x1; dy=y2-y1;       d=sqrt(dx*dx+dy*dy);
if (d!=0.)
{ dx1=10.*(float)dx/d; dy1=10.*(float)dy/d;
   ndx1=dx1*cos(angle)-dy1*sin(angle);
   ndy1=dx1*sin(angle)+dy1*cos(angle);
   xf1=0.3*x1+0.7*x2; yf1=0.3*y1+0.7*y2;     xf2=xf1-ndx1; yf2=yf1-ndy1;
   line(xf1,yf1,xf2,yf2,c);
   ndx2=dx1*cos(-angle)-dy1*sin(-angle);
   ndy2=dx1*sin(-angle)+dy1*cos(-angle);
   xf2=xf1-ndx2; yf2=yf1-ndy2;    line(xf1,yf1,xf2,yf2,c);
}
else
     {circle(x1+10,y1,10,c); line(x1+20,y1,x1+23,y1-6,c);
      line(x1+20,y1,x1+15,y1-5,c);
     }
}





