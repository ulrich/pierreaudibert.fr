/******                 MOUNTAIN RANGES CLASSIFIED                     *******/
/******    ACCORDING TO NUMBER OF MOUNTAINS    *******/

#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <stdlib.h>
#include <math.h>
#define N 8
#define pas 6
void convert(int nombre,int nchiffres);
void pause(void);
void putpixel(int xe, int ye, Uint32 couleur);
Uint32 getpixel(int xe, int ye);
void line(int x0,int y0, int x1,int y1, Uint32 c);
void linewithwidth(int x1, int y1, int x2, int y2, int epaisseur,Uint32 c);
SDL_Surface * screen; Uint32 white, color[2];
SDL_Surface *texte;  SDL_Rect position;TTF_Font *police=NULL;char chiffre[2000];
int transform(int nombre, int nchiffres);
int a[10][1000],L[1000],n,xorig,yorig,x,y,oldx,oldy;

int main(int argc, char ** argv)
{ int i,j,q,reste[100],ii,jj,s,pospivot;
   SDL_Init(SDL_INIT_VIDEO);
   screen=SDL_SetVideoMode(800,600,32, SDL_HWSURFACE|SDL_DOUBLEBUF);
   white=SDL_MapRGB(screen->format,255,255,255);
   color[0]=SDL_MapRGB(screen->format,0,0,0);
   color[1]=SDL_MapRGB(screen->format,0,0,255);
   SDL_FillRect(screen,0,white);
   TTF_Init();  police=TTF_OpenFont("times.ttf",20); SDL_Color couleurnoire={0,0,0};
   sprintf( chiffre," MOUNTAIN RANGES WITH LENGTH %d",2*N);
   texte=TTF_RenderText_Solid(police,chiffre,couleurnoire);
   position.x=10;position.y=5;
   SDL_BlitSurface(texte,NULL,screen,&position);
   a[1][0]=1;L[1]=1;
   for(n=2;n<=N;n++)
     { for(i=n;i>1;i--)
          { for(j=0;j<L[i-1];j++)
             a[i][j]=a[i-1][j]+pow(2,2*n-2);
             L[i]=L[i-1];
           }
       L[1]=0;
       for(i=n;i>1;i--)
          { for(j=0;j<L[i];j++)
               { a[i-1][L[i-1]+j]=transform(a[i][j],2*n);
               }
             L[i-1]+=L[i];
          }
      }
   yorig=30;
   for(i=N;i>=1;i--)
    { xorig=10;yorig+=pas*N+20;
       sprintf( chiffre,"  %d mountain(s)",i);
       texte=TTF_RenderText_Solid(police,chiffre,couleurnoire);
       position.x=xorig;position.y=yorig-N*pas-20+3*i; if (position.y<0) position.y=5;
       SDL_BlitSurface(texte,NULL,screen,&position);
       for(j=0;j<L[i];j++)
         { x=xorig;y=yorig;
            convert(a[i][j],2*N);
            xorig=xorig+2*N*pas +15; if (xorig>800-N*pas-20) {xorig=10; yorig+=pas*N;}
            if (yorig>600-pas*N) { SDL_Flip(screen);  pause();
                                               SDL_FillRect(screen,0,white);  xorig=10; yorig=pas*N+10;
                                             }
         }
    }
   SDL_Flip(screen);  pause();TTF_CloseFont(police); TTF_Quit();  return 0;
}

void convert(int nombre,int nchiffres)
{ int i,r,q;
   q=nombre;
   for(i=0;i<nchiffres;i++)
     { r= q%2; oldx=x;oldy=y;
        if (r==1) { x+=pas; y-=pas; }
        else  { x+=pas; y+=pas; }
        linewithwidth(oldx,oldy,x,y,1,color[1]);
       q=q/2;
    }
}


int transform(int nombre, int nchiffres)
{ int newnombre,q,reste[100],ii,jj,pospivot,s;
   q=nombre; newnombre=0;
   for(ii=0;ii<nchiffres;ii++)
     { reste[ii]=q%2; if (reste[ii]==0) reste[ii]=-1;
       q=q/2;
     }
   ii=nchiffres-1; s=0;
   do
     { s+=reste[ii];ii--;
     }
   while(s!=0);
   pospivot=ii;
   reste[pospivot]=1;
   for(jj=pospivot+2;jj<nchiffres;jj++)
   reste[jj-1]=reste[jj];
   reste[nchiffres-1]=-1;
   for(ii=0;ii<nchiffres;ii++)
   if (reste[ii]==1) newnombre+=pow(2,ii);
   return (newnombre);
}

void pause(void)
{
    SDL_Event evenement;
    do   SDL_WaitEvent(&evenement);
    while(evenement.type != SDL_QUIT && evenement.type != SDL_KEYDOWN);
}

void putpixel(int xe, int ye, Uint32 couleur)
{ Uint32 * numerocase;
numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;    *numerocase=couleur;
}

Uint32 getpixel(int xe, int ye)
{ Uint32 * numerocase;
   numerocase= (Uint32 *)(screen->pixels)+xe+ye*screen->w;   return (*numerocase);
}

void line(int x0,int y0, int x1,int y1, Uint32 c)
{
int dx,dy,x,y,residu,absdx,absdy,stepx,stepy,i;
dx=x1-x0; dy=y1-y0;  residu=0;       x=x0;y=y0;  putpixel(x,y,c);
if (dx>0) stepx=1;else stepx=-1; if (dy>0) stepy=1; else stepy=-1;
absdx=abs(dx);absdy=abs(dy);
if (dx==0) for(i=0;i<absdy;i++) { y+=stepy;
                                                    putpixel(x,y,c); }
else if(dy==0) for(i=0;i<absdx;i++){ x+=stepx;
                                                         putpixel(x,y,c);  }
else if (absdx==absdy)
   for(i=0;i<absdx;i++) {x+=stepx; y+=stepy;
                                     putpixel(x,y,c);
                                     }
else if (absdx>absdy)
          for(i=0;i<absdx;i++)
			  { x+=stepx; residu+=absdy;
			     if(residu >= absdx) {residu -=absdx; y+=stepy;}
			     putpixel(x,y,c);
			  }
else for(i=0;i<absdy;i++)
             {y+=stepy; residu +=absdx;
              if (residu>=absdy)   {residu -= absdy;x +=stepx;}
              putpixel(x,y,c);
             }
}

void linewithwidth(int x1, int y1, int x2, int y2, int epaisseur,Uint32 c)
{
int dx,dy;
float k,xf1,yf1,xf2,yf2,d,dx1,dy1,ndx1,ndy1,ndx2,ndy2,angle=M_PI/2.;
line(x1,y1,x2,y2,c);
dx=x2-x1; dy=y2-y1;       d=sqrt(dx*dx+dy*dy);
if (d!=0.)      /* si le vecteur n’est pas nul */
{ dx1=(float)epaisseur*(float)dx/d; dy1=(float)epaisseur*(float)dy/d;
   ndx1=dx1*cos(angle)-dy1*sin(angle);
   ndy1=dx1*sin(angle)+dy1*cos(angle);
   ndx2=dx1*cos(-angle)-dy1*sin(-angle);
   ndy2=dx1*sin(-angle)+dy1*cos(-angle);
   for(k=0;k<=1.;k+=0.1/d)
   {
   xf1=(1.-k)*x1+k*x2; yf1=(1.-k)*y1+k*y2;
   xf2=xf1-ndx1; yf2=yf1-ndy1;  line(xf1,yf1,xf2,yf2,c);
   xf2=xf1-ndx2; yf2=yf1-ndy2;    line(xf1,yf1,xf2,yf2,c);
   }
}
}
